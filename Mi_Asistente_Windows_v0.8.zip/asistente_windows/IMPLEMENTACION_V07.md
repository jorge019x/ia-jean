# Jean v0.7 — biblioteca local de tareas

## Study (estudiar)

Se eligió UN repositorio funcional de los 34 del PDF: [Codync](https://github.com/leepokai/Codync/tree/01ac25690e671e6b6a6b3282cdbb566802225b5c), Apache-2.0. HEAD público obtenido de nuevo para esta versión. Se leyeron README, LICENSE y la creación de las tablas bots/entries en host/src/store/schema.rs. Su persistencia de trabajo resulta útil entre sesiones; no se ejecutó el proyecto. No se copia su código ni se incorpora su plataforma. Jean implementa una solución propia y más acotada con la biblioteca estándar.

Como método se aplicó conceptualmente Study → Build → Check → Ready, documentado por [Craft Anything](https://github.com/storytold/craft-anything/tree/75d0fa0b4d96dd8d7d8c1def87b974c86a211833), MIT OR Apache-2.0. Se volvió a obtener HEAD y leer README/Status. No se instaló ni ejecutó Craft Anything; no es un buscador conectado ni una dependencia de Jean. Se usó su flujo para estudiar las referencias del PDF, elegir persistencia, construirla y contrastarla con este contrato.

## Build (construir)

- Biblioteca accesible desde la ventana principal de Jean; editor de título, objetivo e hitos.
- Guardar voluntariamente, actualizar y eliminar con confirmación local.
- Hasta 30 tareas, título 100 caracteres, objetivo 8000, hasta 8 hitos; archivo limitado a 512000 bytes.
- Reabrir rellena el objetivo; al pedir Control supervisado se precargan los hitos para revisión. Cambiar el objetivo descarta esos hitos para esa solicitud.
- Nunca inicia red/control por cargar. No guarda acciones ejecutables, progreso, claves, capturas, conversaciones ni aprobaciones. Objetivos/hitos son texto potencialmente sensible: no escribas secretos en ellos.
- JSON en el perfil del usuario, en texto plano. Escritura mediante archivo temporal y reemplazo atómico, validación estricta; una biblioteca dañada no se reemplaza silenciosamente.
- No incluye sincronización, ACP, bots, relay, voz ni repetición automática de Codync. No afirma equivalencia funcional.

## Check (comprobar)

175 pruebas automatizadas en Linux: 154 heredadas y 21 de biblioteca, con archivos temporales y fallos simulados. Cubren persistencia Unicode, editar/eliminar, límites, esquema cerrado, rechazo de acciones/aprobaciones/claves como campos, corrupción, versión entera exacta, fallo de reemplazo/fsync y limpieza de temporales. Compilación sintáctica y repetición desde el ZIP extraído.

No probado: GUI Tk (este Python carece de Tkinter), Windows, iniciador .bat, UIA/COM, winget, capturas/control reales ni APIs reales. No hay imagen de esta ventana funcionando. Los tests de biblioteca sí realizan E/S real de archivos temporales en Linux; los de automatización/modelos son simulados.

## Ready (entregar con límites)

Prototipo ZIP sin dependencias nuevas para la biblioteca. Sigue exigiendo consentimiento de pantalla y aprobación por acción con caducidad, PARAR y límite de pasos. Una tarea guardada no es una aprobación permanente. PARAR no revierte lo ya enviado. No se instaló ni cambió nada en la PC del usuario.

La eliminación solo retira el registro del JSON actual: no borra copias de seguridad ni garantiza borrado forense. El archivo no está cifrado. La biblioteca es de uso local individual y no incorpora bloqueo transaccional entre varios procesos; evita ejecutar dos instancias de Jean editando tareas a la vez.
