# Jean v0.8 — fuentes locales opcionales y medición de chat

## Study: referencias históricas, no dependencias

Se leyeron README y LICENSE de las copias locales conservadas en `references/pdf-grupo0/`. Los commits siguientes identifican revisiones históricas; no se obtuvo ni se afirma conocer el HEAD público actual. No se instaló ni ejecutó ninguno de estos repositorios:

- [ARahim3/DigUp](https://github.com/ARahim3/DigUp/tree/dc2651ad8299160bbe91e972f857e1a1599a8419), `dc2651ad8299160bbe91e972f857e1a1599a8419`, MIT. Su README describe selección explícita, búsqueda literal y vista previa. Jean toma ese concepto, no su búsqueda semántica, índice, modelos o lectores multimedia.
- [j-hernandez-dev/nova-assistant](https://github.com/j-hernandez-dev/nova-assistant/tree/0bc7e8851790167c13a1be39697f4b136150f73d), `0bc7e8851790167c13a1be39697f4b136150f73d`, MIT. Secciones Features, Projects/sources/context y Permissions and recovery: elección de fuentes para el siguiente mensaje y permisos de un uso. Jean no incorpora el almacenamiento persistente, la memoria, las herramientas, el navegador ni los índices de Nova.
- [zurdoar/optimizer-model-for-claude](https://github.com/zurdoar/optimizer-model-for-claude/tree/cf07ed1773de51a886903efa69893df6604ac332), `cf07ed1773de51a886903efa69893df6604ac332`, MIT. Secciones Qué hace, El panel y Preguntas frecuentes: visibilidad del modelo y tiempos. Jean no copia el plugin, agentes, prompts, ruteo ni cálculos de tokens/precios. Su licencia conserva el aviso MIT de johnnyvizz para los archivos derivados de savvy-flow; esos archivos tampoco se incorporan.

Las tres funciones son implementaciones propias de conceptos. No se copió ni adaptó código externo. Las capacidades y pruebas anunciadas por terceros no certifican Jean. La procedencia y los copyrights se detallan en `THIRD_PARTY_NOTICES.md`. Se conserva el método conceptual estudiar → construir → comprobar → entregar con límites de versiones anteriores, sin instalar el motor de Craft Anything.

## Build: contrato de fuentes locales

- Selección voluntaria de un solo archivo `.txt`, `.md` o `.csv` UTF-8 de hasta 128 KiB (131072 bytes). Seleccionar una carpeta para listados no selecciona documentos. CSV se lee como texto, sin ejecutar fórmulas.
- Vista previa y búsqueda de líneas locales sin petición de modelo ni subida del archivo. Sin indexación, embeddings, exploración recursiva, vigilancia de cambios ni búsqueda universal.
- Extracto de hasta 12000 caracteres para la siguiente consulta de chat únicamente. Leer, previsualizar y buscar no lo envían: exige revisión del extracto, consentimiento específico y la confirmación normal de envío al destino configurado, además de pulsar Preguntar IA con una consulta explícita.
- No se envía por un comando local, no se adjunta a otras preguntas automáticamente y no se incorpora al control supervisado. La selección pendiente se descarta tras el intento de envío, también si falla; no se borra el archivo original. Volver a usarlo exige seleccionarlo y autorizarlo otra vez.
- No hay copia documental persistente, memoria de fuentes, PDF, OCR, importación de URLs ni ejecución de instrucciones del documento.

### Frontera de confianza y privacidad

El contenido de la fuente es **dato no confiable**, nunca una instrucción o una autorización de herramientas. Puede incluir *prompt injection* que intente modificar las reglas, desviar la respuesta o solicitar datos. Separarlo como datos reduce el riesgo, pero no garantiza que el modelo rechace todo ataque. El chat sigue produciendo solo texto, sin ejecutar acciones.

**Filtrar o rechazar ciertos archivos no garantiza que el texto no contenga datos sensibles.** La persona debe revisar el extracto y el destino antes de enviarlo. Un archivo permitido puede contener contraseñas, claves, nombres o información confidencial. El proveedor recibe lo adjuntado bajo sus políticas; HTTPS no evita su acceso. Descartar la fuente tras el intento no retira lo ya enviado ni garantiza borrado seguro de memoria, pantalla, registros del proveedor o copias ajenas.

## Build: contrato de medición de sesión

- Resumen local de llamadas de chat por proveedor y modelo: número de éxitos, número de errores y duración medida.
- Estado de esta sesión, sin persistir mensajes, documentos, claves ni un historial de conversación para calcularlo. No supone telemetría externa adicional.
- Éxito significa que la llamada de chat terminó sin error, no que el contenido sea correcto o la tarea esté resuelta. La duración observada no es tiempo exclusivo de inferencia ni una comparación controlada de rendimiento.
- No inventa ni estima tokens, costes, ahorro, saldo o precios. No cambia modelos, no enruta automáticamente y no mide llamadas de otras aplicaciones. Listar modelos y el control supervisado no son llamadas de chat de este resumen.
- La medición no autoriza envíos ni altera la separación entre chat, comandos locales y control supervisado.

## Salvaguardas conservadas

La biblioteca de tareas de v0.7 se conserva. Una tarea guardada o fuente seleccionada no restaura aprobaciones ni reanuda acciones. El control conserva consentimiento de pantalla, aprobación individual de cada acción que modifica o controla el equipo, caducidad de propuestas, límite de pasos y **PARAR**. No hay aprobación global ni control universal. PARAR no revierte lo ejecutado, no retira peticiones ya enviadas ni cancela un instalador ya lanzado. UAC y escritorio seguro no están soportados ni se evitan.

## Check: estado de verificación

Este documento define alcance, procedencia y límites; **no afirma resultados nuevos de pruebas v0.8**. Los resultados de versiones anteriores son históricos y no certifican las funciones nuevas. Los resultados ejecutados y su entorno se documentarán por separado en el informe de pruebas del paquete; no deben deducirse de este contrato.

No se han ejecutado los repositorios de referencia. Windows, la GUI Tk, el selector y vista previa reales, iniciar.bat, capturas, PyAutoGUI, pywinauto/UIA, winget, APIs reales y Ollama no se han probado como parte de esta revisión documental en Linux. No hay capturas nuevas de funcionamiento aportadas por esta revisión. Las pruebas con archivos temporales o red simulada, cuando se documenten, no demostrarán compatibilidad de Windows, acceso real, saldo, facturación ni comportamiento de modelos reales.

## Ready: beneficios y límites de entrega

El beneficio es aportar contexto textual acotado a una consulta deliberada y observar éxitos, errores y tiempo de las llamadas de chat de la sesión, sin índices ni cálculos de coste ficticios. Sigue siendo un prototipo Python, no un ejecutable independiente ni un asistente universal. No se añaden dependencias por estas referencias conceptuales ni se ha instalado nada en la computadora del usuario. La entrega debe conservar las advertencias y distinguir lo construido, lo probado con simulaciones y lo no verificado en Windows o servicios reales.
