# Jean — asistente personal para Windows, prototipo 0.8

Ventana de chat en español con comandos locales limitados y consultas de texto a **OpenAI, Anthropic, Gemini, DeepSeek o una API compatible con OpenAI**. **Ollama es una alternativa local opcional**. Incluye un modo opcional de **control supervisado de Windows con visión** y soporte opcional de **Windows UI Automation**, mediante Anthropic, OpenAI, Gemini o Compatible OpenAI si su API y modelo admiten imágenes. DeepSeek y Ollama siguen siendo conectores de texto. No es un agente autónomo ni un asistente universal. El paquete contiene código Python, no un `.exe` independiente.

## Novedades v0.8: fuentes locales opcionales y medición de sesión

### Consultar una fuente elegida, sin indexar

Puedes seleccionar explícitamente **un archivo `.txt`, `.md` o `.csv` en UTF-8, de hasta 128 KiB (131072 bytes)**, previsualizarlo y buscar líneas en él de forma local. Un CSV se trata como texto, no se ejecutan fórmulas. La selección de una fuente es independiente de **Elegir carpeta**: no habilita el acceso a otros documentos. No hay índice, búsqueda semántica, vigilancia de carpetas ni carga automática de documentos.

1. Selecciona el archivo mediante el selector de fuentes y revisa su vista previa.
2. Busca las líneas que necesitas; la búsqueda local no hace peticiones al modelo ni envía el archivo.
3. Si quieres consultar al modelo sobre ese contenido, revisa el **extracto de hasta 12000 caracteres**, el mensaje y el destino configurado. Autoriza explícitamente adjuntarlo a la siguiente consulta; seleccionar, previsualizar o buscar no autoriza el envío.
4. Mantén también la autorización normal **Permitir enviar mi mensaje actual al destino indicado** y pulsa **Preguntar IA**. La fuente solo acompaña esa consulta explícita, nunca un comando local ni el control supervisado. Tras el intento de envío se descarta la fuente pendiente de la sesión: para usarla de nuevo debes seleccionarla y autorizarla otra vez. No se borra el archivo original ni se garantiza borrado seguro de memoria, pantalla o copias ajenas.

**El documento es una fuente no confiable.** Puede contener *prompt injection*: instrucciones que intenten cambiar el comportamiento del modelo o pedir revelar datos. Se presenta como datos, no como autoridad; esto reduce confusiones, pero no garantiza que el modelo ignore todos los ataques. El filtrado o rechazo de ciertos archivos **no garantiza que el texto carezca de datos sensibles**. Revisa tú mismo cada extracto antes de enviarlo; no adjuntes contraseñas, claves ni información que no debas compartir con ese destino. Una respuesta basada en un documento puede ser incorrecta y no ejecuta acciones.

El beneficio es aportar contexto documental acotado sin pegar todo el archivo ni indexar el equipo. Los límites son deliberados: un archivo de texto por vez, consulta por líneas y un extracto limitado, sin PDF, OCR, audio, vídeo, URLs importadas, memoria documental persistente ni recuperación automática. DigUp (MIT) inspira la selección explícita y búsqueda local; nova-assistant (MIT), la previsualización y elección de fuentes para el siguiente mensaje. Son referencias conceptuales, no componentes instalados ni código incorporado.

### Medición del chat durante esta sesión

La medición local resume por **proveedor y modelo** el número de consultas de chat terminadas con **éxito o error** y su **duración medida**. Sirve para observar las llamadas realizadas por Jean en esta sesión; no demuestra calidad de respuestas ni disponibilidad futura. Un éxito de la llamada no prueba que la respuesta sea correcta. No es una auditoría del proveedor ni incluye llamadas externas hechas por otras aplicaciones.

No calcula ni inventa tokens, precios, costes o ahorro; la duración observada no equivale a tiempo exclusivo de inferencia. La medición no selecciona modelos automáticamente ni cambia el consentimiento de envío, y no contabiliza el control supervisado como chat. Es estado de sesión, no un historial persistente de mensajes, claves o documentos. El panel de optimizer-model-for-claude (MIT) es solo una referencia conceptual de visibilidad de proveedor/modelo y tiempos; Jean no instala su plugin ni copia su código, ruteo, agentes o estimaciones de costes.

Consulta `IMPLEMENTACION_V08.md` y `THIRD_PARTY_NOTICES.md` para el contrato, la procedencia histórica y las limitaciones de verificación. Las aprobaciones individuales y **PARAR** del control supervisado se conservan sin cambios; las fuentes del chat no se incorporan a ese flujo.

## Funciones conservadas de v0.7: biblioteca local de tareas

**Jean** incorpora el botón **Biblioteca de tareas** en la ventana principal. Permite conservar voluntariamente hasta **30 tareas**, cada una con **título, objetivo y hasta 8 hitos manuales**. Es una biblioteca de definiciones de tareas, no una memoria del chat ni un motor de automatización.

1. Abre **Biblioteca de tareas** y revisa los campos **Título**, **Objetivo** e **Hitos** (uno por línea).
2. Usa **Guardar** solo si aceptas conservar esos textos localmente. No escribas contraseñas, claves ni otros secretos en ellos.
3. Selecciona una tarea y pulsa **Cargar en Jean** para rellenar el objetivo y los hitos del control supervisado. Revisa ambos antes de iniciar: cargar **no ejecuta acciones**, no restaura aprobaciones ni reanuda una ejecución anterior.
4. Para retirar una tarea, selecciónala y pulsa **Eliminar**; se pide confirmación. Eliminar no garantiza borrado seguro ni elimina copias de seguridad.

El archivo se guarda en `%LOCALAPPDATA%\Jean\tasks.json`; si no hay `LOCALAPPDATA`, se usa `~/.jean/tasks.json`, donde `~` es la carpeta personal. El guardado es voluntario y en **texto plano, sin cifrar**: los títulos, objetivos e hitos pueden contener información sensible y otras aplicaciones o personas con acceso al perfil podrían leerlos. La biblioteca no guarda claves, capturas, chat, acciones ejecutadas ni aprobaciones. No incluyas este archivo personal en el ZIP ni en informes de soporte.

Cargar una tarea no envía su contenido al proveedor. Si después inicias el control supervisado, el objetivo y los hitos se incluyen en su contexto de nube como se describe abajo. Cada inicio exige un nuevo consentimiento de envío y conserva la aprobación individual de cada acción y **PARAR**. No hay progreso automático, reproducción de acciones guardadas (*replay*) ni recuperación automática del estado de una aplicación. Los hitos se confirman manualmente; no demuestran por sí mismos que el resultado sea correcto.

Para la persistencia de tareas se eligió **Codync (Apache-2.0)** como única referencia conceptual, no como dependencia: el código de la biblioteca es propio y no se copió código de ese proyecto. **Craft Anything** se usa solo como referencia conceptual del flujo **explorar → diseñar un contrato de tarea → implementar → comprobar con evidencia**; no es un motor instalado ni ejecutado por Jean. En la práctica, concreta el objetivo y los hitos, revisa la propuesta, aprueba cada acción y comprueba su resultado en la aplicación. Estas referencias no implican equivalencia funcional, integración ni respaldo de sus autores; consulta `THIRD_PARTY_NOTICES.md`.

## Funciones conservadas de v0.6: tareas revisables y registro mínimo

Nuevos comandos locales, sin modelo ni envío a la nube:

- `buscar archivos informe`: busca la palabra literal en los nombres de la carpeta elegida con el botón; ignora mayúsculas/minúsculas, sin abrir contenidos ni entrar en subcarpetas. Revisa hasta 1000 entradas y devuelve hasta 100 coincidencias. El orden depende del sistema de archivos y el resultado puede ser parcial. El texto buscado nunca selecciona otra ruta ni se ejecuta. Escribir una ruta en el chat no cambia la carpeta.
- `diagnostico` (también `diagnóstico`): detecta Windows, versión de Python, paquetes opcionales y archivo winget. No importa los paquetes opcionales, no prueba cuentas, no lee claves, no hace red ni instalaciones. Una dependencia detectable puede no funcionar: no lo presenta como verificación funcional.


- En **Control supervisado**, puedes marcar **Usar mis hitos** y escribir de 1 a 8 hitos (uno por línea, hasta 1000 caracteres cada uno). Es una lista manual para esta tarea, no un generador de código ni una importación de agentes externos.
- El modelo recibe el hito actual además del objetivo y del contexto normal. Cuando propone `finish`, la ventana pide confirmar ese hito. Aprueba solo después de comprobar su resultado en la aplicación. Rechazar o PARAR termina el bucle. La confirmación humana no es verificación independiente.
- El presupuesto sigue siendo **12 propuestas en total**, no 12 por hito. Cada clic, tecla y acción conserva su aprobación individual; no se reproducen secuencias guardadas ni se omiten aprobaciones.
- Una aprobación recibida tras más de **90 segundos** desde que se solicita no ejecuta la acción. Se termina la tarea para volver a observar. No detecta todos los cambios de pantalla: si cambió cualquier cosa, rechaza incluso antes de ese plazo.
- Al terminar, **Exportar registro mínimo al terminar** abre un diálogo para elegir el archivo JSON. Solo contiene número de paso, tipo de acción y estado (propuesta, aprobada, rechazada, emitida o hito confirmado). No se guarda automáticamente ni incluye objetivo, clave, motivo, texto introducido, captura o nombres UIA. No es un registro exhaustivo ni permite reproducir acciones. El selector de guardado puede sobrescribir un archivo si tú lo confirmas.
- El contenido de los hitos sí se envía al proveedor junto al objetivo durante el control; no escribas secretos. Los registros mínimos pueden revelar patrones de actividad aunque omitan textos.

Consulta **REVISION_REPOSITORIOS.html** para la revisión del PDF, licencias, decisiones y límites. Las funciones nuevas son implementaciones propias de conceptos, no código trasplantado de los repositorios. Los servicios y las páginas de documentación del PDF no son automáticamente repositorios de código ni se instalan.

## Inicio en Windows

1. Extrae todo el ZIP en una carpeta; no ejecutes el programa desde dentro del ZIP.
2. Instala manualmente **Python 3.10 o posterior** desde [python.org](https://www.python.org/downloads/windows/), con Tcl/Tk (`tkinter`) y la opción de añadir Python al PATH.
3. Haz doble clic en **iniciar.bat**. Comprueba Python 3.10+ y que Tcl/Tk pueda crear una ventana; después ofrece **instalar las dependencias opcionales con pip**, **iniciar sin instalar nada** o **salir**. Como alternativa, abre una consola en la carpeta y ejecuta `py -3 assistant.py` o `python assistant.py`.
4. Escribe `hora` y usa **Comando local**; consulta `ayuda` para ver las funciones locales.
5. Para conversar con IA, configura un proveedor y un modelo como se explica a continuación y usa **Preguntar IA**.

El chat de texto y los comandos locales no necesitan **pip** ni paquetes externos. El control visual necesita **pyautogui** y **Pillow**; la integración opcional de Windows UI Automation necesita **pywinauto**. Ninguno es obligatorio para el chat o los comandos locales. El iniciador solo ejecuta `python -m pip install pyautogui Pillow pywinauto` (con el intérprete comprobado) si eliges explícitamente instalar los tres paquetes opcionales. Si solo necesitas el control visual, puedes instalar manualmente `python -m pip install pyautogui Pillow`; si quieres añadir UI Automation, instala también `python -m pip install pywinauto` con el mismo intérprete que utiliza el programa. Esa opción descarga paquetes de Internet y modifica ese entorno Python; consulta sus condiciones y revisa los errores de pip. No instala Python, no repara Tcl/Tk ni instala automáticamente aplicaciones con winget. Puedes iniciar sin instalar dependencias; en ese caso el control supervisado solo estará disponible si ya están presentes. Si falta Python o Tcl/Tk, modifica manualmente la instalación oficial. No se ha instalado nada en la computadora del usuario para preparar este paquete; úsalo sin privilegios de administrador.

## Configurar la IA desde la interfaz

La configuración ofrece **proveedor**, **URL base**, **modelo libre con sugerencias**, **Listar modelos**, **clave enmascarada**, **Guardar configuración**, una opción explícita para **guardar la clave** y un control para **borrar claves guardadas**. El enmascaramiento solo oculta la clave en pantalla; no equivale a cifrarla.

1. Selecciona un proveedor. El selector muestra los nombres amigables **ChatGPT (OpenAI)**, **Claude (Anthropic)**, **Gemini (Google)** y **DeepSeek**, además de Compatible OpenAI y Ollama local. Son conectores de API: los nombres ChatGPT y Claude no significan que se acceda a tu sesión de suscripción de chat.
2. Comprueba la URL base. Para los servicios integrados utiliza:
   - OpenAI: `https://api.openai.com/v1`
   - Anthropic: `https://api.anthropic.com/v1`
   - Gemini: `https://generativelanguage.googleapis.com/v1beta`
   - DeepSeek: `https://api.deepseek.com`
   - Compatible con OpenAI: URL base HTTPS del servicio elegido, por ejemplo OpenRouter `https://openrouter.ai/api/v1`, Groq `https://api.groq.com/openai/v1` o Mistral `https://api.mistral.ai/v1`. Son ejemplos de formato, no servicios verificados en este entorno ni una garantía de compatibilidad. Comprueba la URL oficial, las condiciones, el formato compatible y los modelos que ofrece tu proveedor.
3. Escribe el **nombre exacto de un modelo al que tu cuenta tenga acceso**. El campo permite texto libre y ofrece sugerencias orientativas, no una lista cerrada. No hay modelo predeterminado: es obligatorio elegirlo. Puedes usar **Listar modelos** para consultar al proveedor y seleccionar un identificador; lee los límites de esa función más abajo. No escribas una URL completa de operación en lugar de la URL base.
4. Proporciona la clave del proveedor mediante su variable de entorno o el campo enmascarado. No pegues claves en el chat.
5. Usa **Guardar configuración** para conservar los ajustes. Guardar la configuración no debe confundirse con consentir el guardado de claves; este último requiere la opción explícita.
6. Activa **Permitir enviar mi mensaje actual al destino indicado**, escribe un mensaje y pulsa **Preguntar IA**. Enter ejecuta solo comandos locales; no envía a la nube. Cambiar proveedor o URL desactiva esa autorización y limpia la clave escrita. Los comandos locales siguen separados de las consultas al modelo.

La configuración se conserva en `%LOCALAPPDATA%\MiAsistente\config.json`. También puedes editar ese archivo con la aplicación cerrada: usa `config.example.json` como referencia, cambia `provider`, `base_url` y `model`, y guarda una copia en esa ubicación del perfil. Los valores exactos de `provider` son `OpenAI`, `Anthropic`, `Google Gemini`, `DeepSeek`, `Compatible OpenAI` y `Ollama local`. Se conservan estos identificadores internos aunque el selector muestre nombres amigables; no escribas `ChatGPT (OpenAI)` o `Claude (Anthropic)` en el JSON. El ejemplo incluido usa DeepSeek; para otro proveedor cambia tanto `provider` como `base_url`. No pongas claves en `config.json`; solo admite esos tres ajustes. La casilla de envío siempre comienza desactivada al abrir la aplicación.

Las conexiones de nube requieren **HTTPS**. HTTP no se permite para proveedores de nube ni para APIs compatibles: la única excepción es Ollama, con su dirección local fija indicada más abajo.

La API puede ser de pago y exige una cuenta, permisos de modelo y saldo o facturación según el proveedor. **Una suscripción a un chat como ChatGPT, Claude o Gemini no equivale a disponer de acceso o crédito para su API**. Consulta precios, límites y condiciones del proveedor antes de enviar mensajes.

## Elegir y listar modelos

**Listar modelos** consulta el catálogo del destino configurado usando su credencial. Es una petición de red, incluso sin enviar un mensaje de chat: el operador recibe la IP de origen y la credencial correspondiente. Verifica primero proveedor y URL. Se consulta únicamente la **primera página, con límite de resultados**; no se recorren automáticamente las páginas siguientes. Un catálogo vacío, incompleto o rechazado no demuestra que no existan otros modelos.

- OpenAI, Anthropic, DeepSeek y Compatible OpenAI: `GET` a la URL base seguida de `/models`.
- Google Gemini: `GET` a la URL base seguida de `/models`.
- Ollama local: `GET http://127.0.0.1:11434/api/tags` para los modelos locales disponibles.

Que un identificador aparezca en el catálogo o entre las sugerencias **no garantiza que admita chat de texto, que tu cuenta pueda utilizarlo ni que tenga saldo o cuota disponible**. El campo sigue siendo editable para introducir un identificador que no aparezca en la primera página. No se promete compatibilidad con cualquier modelo: el chat usa respuestas de texto y el protocolo de chat del conector elegido. El modo separado de control supervisado añade imágenes y propuestas de acciones con Anthropic, OpenAI, Gemini o Compatible OpenAI si su API y modelo admiten visión. No admite audio ni todos los productos o herramientas de los proveedores; aparecer en un catálogo no demuestra capacidad de visión. Las sugerencias pueden quedar desactualizadas; comprueba la documentación y el acceso de tu cuenta.

## Claves: variable de entorno o guardado local voluntario

Variables reconocidas según el proveedor:

- OpenAI: `OPENAI_API_KEY`
- Anthropic: `ANTHROPIC_API_KEY`
- Gemini: `GEMINI_API_KEY`
- DeepSeek: `DEEPSEEK_API_KEY`
- API compatible con OpenAI: `COMPATIBLE_API_KEY`
- Ollama local: no necesita estas claves.

Ejemplo **con marcador de posición**, en PowerShell abierto en la carpeta del programa:

```powershell
$env:OPENAI_API_KEY = 'REEMPLAZA_POR_TU_CLAVE_EN_TU_EQUIPO'
.\iniciar.bat
```

Sustituye el marcador solo en tu equipo; no es una clave real. Esta variable dura en esa sesión de PowerShell y la hereda el programa iniciado desde ella. Un doble clic separado desde el Explorador no hereda una variable establecida únicamente en esa consola. Para otro proveedor usa su variable correspondiente. Ten en cuenta que escribir una clave en una consola puede dejarla en el historial de esa consola.

También puedes introducirla en el campo enmascarado. Si decides activar explícitamente **guardar la clave**, se almacena en `%LOCALAPPDATA%\MiAsistente\api_keys.json` como **texto plano, sin cifrar**, bajo los permisos del perfil de Windows. No es un almacén seguro de credenciales y el enmascaramiento de la interfaz no protege ese archivo. Evita esta opción en equipos o perfiles compartidos. Otras aplicaciones o personas con acceso al perfil podrían leerlo, y una copia de seguridad podría conservarlo.

Precedencia de la clave: campo escrito en esta sesión > variable de entorno del proveedor > clave guardada. Las claves guardadas se vinculan al proveedor y la URL base exactos; las variables de entorno no están vinculadas a una URL. **Si cambias la URL base de un proveedor integrado, también podrías enviar su clave de entorno al nuevo operador** al habilitar las consultas. No cambies destinos sin verificarlos y usa `Compatible OpenAI` con una clave propia de ese servicio para servicios compatibles. La aplicación no usa los proxies del sistema ni sigue redirecciones; una red corporativa que exija proxy puede no funcionar.

El control **borrar claves guardadas** permite retirar las claves persistidas por la aplicación. No borra variables de entorno, historial de PowerShell ni copias de seguridad, y no revoca una clave en el proveedor. Si una clave se expone, revócala allí. **Nunca incluyas `api_keys.json`, claves reales ni copias de tu configuración personal en el ZIP, registros, capturas, informes o mensajes de soporte**. El paquete distribuido no debe contener credenciales.

## Ollama local, opcional

Los comandos locales no necesitan ningún modelo. Para conversar con un modelo local:

1. Instala manualmente [Ollama para Windows](https://ollama.com/download/windows).
2. Descarga un modelo adecuado a la memoria de tu equipo, por ejemplo `ollama pull llama3.2:3b`. La descarga usa Internet y puede ocupar varios GB; consulta requisitos y licencia.
3. Mantén Ollama ejecutándose, elige Ollama en la interfaz y escribe el nombre exacto del modelo descargado.
4. Envía el mensaje mediante **Preguntar IA**.

Ollama utiliza la base fija `http://127.0.0.1:11434`: `/api/chat` para conversar y `/api/tags` para listar modelos. No sirve para configurar servidores remotos ni otros puertos. No se necesita una clave API de nube. Que el servidor sea local no garantiza privacidad absoluta: revisa Ollama, el modelo y el resto del software instalado.

## Qué se envía y qué puede hacer el modelo

En **Preguntar IA** (chat de texto) se envía **el mensaje actual**, junto con la instrucción de funcionamiento de la aplicación y, solo si lo seleccionas y autorizas expresamente para esa consulta, el extracto de la fuente local descrito en v0.8. No se adjuntan automáticamente el historial, documentos, la carpeta seleccionada ni sus listados. Cada pregunta de texto es independiente, sin memoria de conversación. El control supervisado es un flujo distinto que envía capturas y contexto de la tarea en cada paso; cuando UI Automation está disponible, incluye además un inventario limitado de ventanas y controles accesibles, como se explica a continuación. Si copias un listado, una contraseña o un documento dentro del mensaje, ese texto sí se envía.

En modo nube, **el proveedor recibe el mensaje y la IP de origen de la conexión** y puede aplicar sus políticas de conservación, uso y facturación. Con una API compatible, el operador de la URL configurada recibe esos datos y la credencial empleada: verifica cuidadosamente el destino. HTTPS protege el transporte, no evita el acceso del proveedor ni sustituye sus políticas. No introduzcas información sensible sin comprender estos riesgos.

En **Preguntar IA**, el modelo devuelve **solo texto**: sus respuestas no pulsan botones ni ejecutan acciones. Aunque afirme que hizo algo, eso no prueba que lo haya ejecutado. En el modo separado de control supervisado puede proponer las acciones limitadas descritas abajo, sujetas a aprobación individual salvo `finish`, que solo termina el flujo sin modificar el equipo. Puede equivocarse o proponer acciones inseguras; no sigas instrucciones sin entenderlas.

## Control supervisado de Windows con visión y UI Automation (opcional)

Necesita Windows, Python 3.10+ con Tcl/Tk, **pyautogui + Pillow** (y **pywinauto** para UI Automation), un proveedor **Anthropic, OpenAI, Gemini o Compatible OpenAI** y una API y modelo con visión compatibles con su conector. **DeepSeek y Ollama no habilitan este control**; conservan el chat de texto. Compatible OpenAI solo funciona si el servicio y modelo elegidos admiten el formato de imágenes y las propuestas de acciones del conector; no se garantiza compatibilidad universal. No basta con elegir cualquier modelo ni con tener una suscripción de chat.

Pulsa **Control supervisado**, define una tarea concreta y pulsa **Iniciar**. El flujo espera **5 segundos** para que puedas enfocar la aplicación de destino; después procesa un máximo de **12 pasos** por inicio. Hay una ventana flotante **PARAR** durante el proceso. **Se captura la pantalla principal y se envía al proveedor de nube en cada paso**, junto con la tarea y el contexto necesario del proceso. Esas imágenes pueden contener documentos, mensajes, contraseñas visibles, notificaciones o datos de cualquier aplicación abierta; no se limitan a la ventana del asistente ni a la carpeta seleccionada. Cierra o tapa contenido sensible antes de iniciar y durante toda la tarea. No presupongas que una captura excluye secretos porque el asistente no los mencione. Este modo no es local: revisa las políticas de conservación y uso del proveedor. Cada paso puede generar consumo y coste por imágenes, texto y respuestas, incluso si después rechazas la acción propuesta o paras el proceso.

Cuando **pywinauto** está disponible en Windows, el control intenta usar automáticamente **Windows UI Automation**: comparte con el proveedor una lista limitada de ventanas y los controles accesibles de la ventana activa, además de la captura. Esa información puede incluir títulos de ventanas, nombres o etiquetas de controles y datos de aplicaciones abiertas; no es un filtro de privacidad ni se limita a la carpeta elegida. Los identificadores de ventana y elemento son **efímeros**, válidos solo para la observación actual; no son nombres permanentes ni selectores arbitrarios. Si pywinauto falta o la aplicación no expone controles utilizables, el modo visual puede seguir proponiendo acciones por coordenadas, con las mismas aprobaciones. Instalar pywinauto no habilita control universal ni elimina la necesidad de un modelo con visión.

**Todas las acciones que modifican o controlan el equipo, incluidas las de UI Automation, requieren aprobación individual en una ventana no modal**; `finish` es la única excepción, porque termina el flujo sin modificar el equipo. No hay aprobación global ni autorización automática de una secuencia. La aprobación muestra una **vista previa de la captura** y puedes seguir usando la interfaz mientras la propuesta está abierta. Revisa la captura, la acción, sus argumentos y el estado real del escritorio antes de aprobar; el foco o una ventana pueden cambiar entre la captura y la ejecución. **Revisar cada clic y cada tecla es imprescindible**: una coordenada o tecla incorrecta puede afectar a cualquier aplicación, enviar mensajes, modificar documentos o confirmar una operación ajena a tu intención.

Las herramientas admitidas son exclusivamente:

- `click`: proponer un clic en la pantalla principal.
- `move`: mover el puntero.
- `scroll`: desplazar con la rueda.
- `type_text`: escribir texto Unicode mediante Windows `SendInput` en el control que tenga el foco; no utiliza el portapapeles ni admite texto multilínea. No lo uses para escribir comandos en terminales ni contenido sensible.
- `press_key`: pulsar una sola tecla de esta lista: `enter`, `tab`, `escape`, `backspace`, `left`, `right`, `up`, `down` o `space`. No admite combinaciones. Revisa el foco y su efecto antes de aprobar.
- `focus_window(window_id)`: solicitar enfocar una ventana identificada en la observación actual de UI Automation.
- `invoke_element(element_id)`: solicitar la acción de invocación de un control accesible identificado en la observación actual; su efecto depende de la aplicación y puede ser importante.
- `set_value(element_id, text)`: solicitar cambiar el valor de un control accesible identificado en la observación actual; no es autorización para escribir contraseñas o comandos.
- `open_app`: solicitar abrir una aplicación del catálogo permitido, sin shell arbitrario.
- `install_app`: solicitar una instalación interactiva mediante winget, solo del catálogo cerrado indicado abajo.
- `finish`: terminar el flujo sin aprobación, porque no modifica el equipo; no demuestra por sí mismo que el objetivo se haya cumplido.

El catálogo de instalación es cerrado y contiene 14 identificadores: `7zip.7zip` (7-Zip), `VideoLAN.VLC` (VLC), `Notepad++.Notepad++` (Notepad++), `Mozilla.Firefox` (Firefox), `Google.Chrome` (Chrome), `Microsoft.VisualStudioCode` (VS Code), `Python.Python.3.13` (Python 3.13), `Git.Git` (Git), `GIMP.GIMP.3` (GIMP), `Inkscape.Inkscape` (Inkscape), `TheDocumentFoundation.LibreOffice` (LibreOffice), `OBSProject.OBSStudio` (OBS Studio), `Audacity.Audacity` (Audacity) y `SumatraPDF.SumatraPDF` (Sumatra PDF). Es una lista propia del prototipo; no se han verificado esos identificadores ni sus instalaciones contra winget real en este entorno. Requiere winget disponible; no se instala winget automáticamente. La instalación es **interactiva**, sin aceptar licencias automáticamente, sin ejecución silenciosa ni solicitud de elevación por el asistente. Comprueba editor, origen, condiciones y cualquier diálogo del instalador; no se promete que todas las instalaciones puedan completarse sin privilegios. La aprobación de `install_app` autoriza lanzar ese instalador concreto, no elimina sus propios controles ni confirma su resultado. Al lanzar el instalador termina el bucle de control: el asistente no espera ni verifica que la instalación se haya completado.

**Parar** detiene la continuación entre operaciones: no cancela una petición HTTP ya enviada, no retira sus datos ni costes y **no cancela un instalador ya lanzado**. Una operación en curso puede terminar antes de que se observe la parada. Además del máximo de pasos, un detector detiene la tercera repetición de la misma acción con la misma captura. Es una protección limitada contra repeticiones exactas, no una comprobación general de progreso: cambios de imagen o de identificadores UIA pueden impedir que reconozca un bucle. Para el mecanismo de emergencia de PyAutoGUI, mueve el ratón a la **esquina superior izquierda de la pantalla principal** (failsafe); se comprueba al ejecutar operaciones de PyAutoGUI, no interrumpe una petición HTTP ni un instalador independiente. No desactives ese failsafe.

UI Automation no siempre está disponible: controles personalizados, navegadores, contenido remoto o aplicaciones que no expongan los patrones necesarios pueden no admitir estas operaciones. Una ventana puede cerrarse o un control cambiar después de la observación; no reutilices identificadores ni apruebes una propuesta que ya no coincida con la pantalla. La invocación y el cambio de valor también pueden enviar datos o activar operaciones: comprueba el efecto concreto antes de aprobar. La parada no revierte una acción de UI Automation que ya se haya ejecutado.

No hay shell arbitrario, scripts libres ni garantía de control universal. Las herramientas restringidas no convierten el escritorio en un entorno aislado: clics, texto y teclas pueden producir efectos importantes en otras aplicaciones. **UAC, el escritorio seguro y ventanas elevadas no están soportados ni se evitan**; no ejecutes el asistente como administrador. Ventanas movidas, escalado, resolución, varios monitores, aplicaciones sin foco y modelos que interpreten mal una captura pueden causar errores. Verifica visualmente los resultados; ni una respuesta del modelo ni abrir un proceso prueban que la acción haya tenido éxito.

## Funciones locales sin IA

- `hora`: muestra la hora del equipo.
- `abrir calculadora`, `abrir bloc de notas`, `abrir paint`: solicita abrir únicamente esas aplicaciones. Pueden no estar instaladas y la solicitud no prueba que su ventana haya aparecido.
- `listar archivos`: muestra nombres y tipos de hasta 100 entradas de la carpeta elegida, sin leer contenidos ni entrar en subcarpetas. No presupongas orden alfabético.
- `ayuda`: muestra las instrucciones.

Usa **Elegir carpeta** para seleccionar explícitamente la carpeta que se puede listar; escribir una ruta en el chat no la selecciona. **Olvidar carpeta** elimina esa selección de la sesión. Evita unidades de red lentas: el listado puede bloquear temporalmente la interfaz. Los nombres también pueden ser sensibles.

**Comando local** no ejecuta shell arbitrario, scripts, borrados, edición de documentos, compras o envíos. Abrir una aplicación por este botón permite usarla manualmente; no inicia el control supervisado. El control por capturas, clics y teclas pertenece exclusivamente al modo opcional descrito arriba. No hay voz ni integración específica con correo o navegador; esto no impide que un clic o tecla aprobado afecte a esas aplicaciones.

## Límites de privacidad y seguridad

- Es un prototipo, no una barrera de seguridad ni un producto endurecido. No promete privacidad absoluta.
- Python, Windows, Ollama, las aplicaciones locales y los proveedores elegidos forman parte del entorno de confianza. Instalaciones, descargas y actualizaciones pueden usar Internet.
- El chat y los nombres listados quedan visibles en pantalla. Limpiar la ventana no garantiza borrado seguro, no elimina registros ajenos y no equivale a cancelar una solicitud ya enviada.
- Guardar ajustes, tareas y, opcionalmente, claves crea archivos persistentes en el perfil. No confundas estos archivos con un historial de conversación ni con almacenamiento cifrado. La biblioteca de tareas tiene su propia ubicación `Jean`; los ajustes y claves conservan las ubicaciones `MiAsistente` indicadas arriba.
- La carpeta elegida puede cambiar, desaparecer o perder permisos. El listado es una instantánea y no proporciona aislamiento frente a cambios concurrentes del sistema de archivos.
- El proveedor puede seguir procesando una consulta aunque cierres la ventana. No hay garantía de cancelación ni de ausencia de costes tras enviarla.
- No compartas capturas, ZIP ni registros sin revisarlos y retirar datos personales y secretos.

## Pruebas y estado de verificación

Desde la carpeta del programa:

```bat
py -3 -m unittest discover -v
```

También puedes usar `python -m unittest discover -v`. Las pruebas automatizadas usan simulaciones y no deben abrir aplicaciones reales ni enviar mensajes de pago. Consulta el informe de pruebas incluido en el paquete para los comandos ejecutados y sus resultados; esta guía no afirma resultados nuevos de ejecución de v0.8 ni aporta capturas de verificación. Los resultados de v0.7 son históricos y no certifican las funciones nuevas.

**Windows, la interfaz gráfica, `iniciar.bat`, las capturas reales, PyAutoGUI, pywinauto, Windows UI Automation, los instaladores winget y las APIs reales de OpenAI, Anthropic, Gemini, DeepSeek, servicios compatibles y Ollama no se han probado en este entorno Linux.** No se han realizado instalaciones en la computadora del usuario. Las pruebas con HTTP simulado no prueban acceso, facturación, compatibilidad o disponibilidad de modelos reales. El iniciador se ha revisado como texto, no ejecutado en Windows.

## Archivos principales

- `assistant.py`: interfaz, comandos locales y acceso al control supervisado opcional.
- `models.py`: conectores de IA, validación y configuración del perfil.
- `computer_control.py`: herramientas restringidas, capturas y ejecución del control supervisado.
- `control_ui.py`: interfaz del control supervisado, aprobación individual y parada.
- `config.example.json`: ejemplo sin clave; sustituye `TU_MODELO` por tu modelo real.
- `iniciar.bat`: comprueba Python 3.10+ con Tcl/Tk y ofrece instalar explícitamente pyautogui + Pillow + pywinauto con pip, iniciar sin instalar o salir.
- `THIRD_PARTY_NOTICES.md`: avisos sobre dependencias opcionales y referencias de terceros.
- Archivos `test_*.py`: pruebas automatizadas del núcleo y de las fronteras de integración.
- `RESULTADOS_PRUEBAS.txt`, si se incluye: resultados y limitaciones del entorno donde se ejecutaron las pruebas.

La configuración personal, las tareas guardadas y las claves pertenecen al perfil local, **no a la carpeta del paquete distribuible**.
