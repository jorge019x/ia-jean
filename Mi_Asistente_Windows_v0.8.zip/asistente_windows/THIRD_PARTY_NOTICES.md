# Avisos de terceros — Jean 0.8

## Ampliación v0.8: fuentes locales y medición de chat

Se leyeron las copias locales de README y LICENSE de estas tres referencias. Los commits identifican **revisiones históricas conservadas localmente**; no se consultó ni se afirma conocer el HEAD público actual y no se instalaron ni ejecutaron los proyectos:

- **ARahim3/DigUp**, revisión `dc2651ad8299160bbe91e972f857e1a1599a8419`, **MIT**, copyright 2026 Abdur Rahim: <https://github.com/ARahim3/DigUp/tree/dc2651ad8299160bbe91e972f857e1a1599a8419>. README: selección de carpetas, búsqueda literal y vista previa. Jean toma únicamente la idea de selección explícita y consulta local, con un solo `.txt`/`.md`/`.csv` UTF-8 de hasta 128 KiB. No incorpora su índice, embeddings, lectores multimedia, modelos ni dependencias.
- **j-hernandez-dev/nova-assistant**, revisión `0bc7e8851790167c13a1be39697f4b136150f73d`, **MIT**, copyrights 2026 Nova Assistant y 2025 lutelute (contribuciones originales local-cli): <https://github.com/j-hernandez-dev/nova-assistant/tree/0bc7e8851790167c13a1be39697f4b136150f73d>. README: fuentes previsualizables elegidas para el siguiente mensaje y permisos de un uso. Jean no copia fuentes de forma persistente, importa URLs, indexa proyectos ni hereda las capacidades de herramientas, memoria o navegador de Nova.
- **zurdoar/optimizer-model-for-claude**, revisión `cf07ed1773de51a886903efa69893df6604ac332`, **MIT**, copyright 2026 Emanuel (Zurdo): <https://github.com/zurdoar/optimizer-model-for-claude/tree/cf07ed1773de51a886903efa69893df6604ac332>. README: panel de actividad por modelo y tiempo. Su LICENSE conserva también el aviso MIT de johnnyvizz (2026) para `skills/flujo/SKILL.md` y `agents/`, adaptados de savvy-flow. Jean no incorpora esos archivos, su plugin, prompts, ruteo ni agentes. La medición propia registra solo proveedor/modelo, éxitos, errores y duración de llamadas de chat de sesión; no atribuye tokens, costes ni ahorros.

**No se copió ni adaptó código externo, prompts o recursos de estos proyectos para v0.8 y no son dependencias nuevas.** Son referencias conceptuales, no integraciones ni respaldo de sus autores. Las descripciones de sus README no prueban su funcionamiento ni el de Jean. Los límites de 128 KiB y 12000 caracteres son decisiones propias de Jean. No se ha ejecutado ninguno de esos repositorios para esta ampliación. Véase `IMPLEMENTACION_V08.md`.

## Antecedente v0.7: una referencia funcional seleccionada

En la preparación de v0.7 se registró la revisión de **leepokai/Codync**, `01ac25690e671e6b6a6b3282cdbb566802225b5c` (Apache-2.0): README y `host/src/store/schema.rs`. Su almacenamiento de bots y conversaciones inspira la biblioteca local de tareas de Jean. **No se copió ni adaptó código**; Jean usa un JSON limitado, no el motor Rust/SQLite, ACP, relay, bots ni sincronización de Codync. Los textos originales LICENSE y NOTICE se incluyen como referencia en `licenses/Codync-*`.

Para el método de v0.7 se registró la revisión de **storytold/craft-anything**, `75d0fa0b4d96dd8d7d8c1def87b974c86a211833` (MIT OR Apache-2.0), README, sección Status. Se aplicó conceptualmente Study → Build → Check → Ready; no se instaló ni ejecutó su motor, ni se incorporaron sus prompts, recursos o código. Se incluye su licencia MIT como referencia. Véase IMPLEMENTACION_V07.md para el contrato y evidencia. Estas dos lecturas no prueban el funcionamiento de esos productos. Se conservan aquí como antecedentes históricos; no se afirma que esos commits sean el HEAD público actual.


Además, la búsqueda acotada por nombre se implementó desde cero tomando la idea de selección explícita de carpeta de **ARahim3/DigUp** (MIT, `dc2651ad8299160bbe91e972f857e1a1599a8419`), sin índice ni lectura de contenidos. El diagnóstico pasivo se implementó desde cero como idea de inventario de capacidades de **Panniantong/Agent-Reach** (MIT, `c70ae6da5d39bc90e09ad2ae0575ccc89f31e284`), sin canales, cookies ni acceso de cuentas. No se copió código ni texto de estos proyectos. La revisión completa de los 34 repositorios con fuentes/licencias/SHAs y decisiones está en REVISION_REPOSITORIOS.html y .json.

## Dependencias opcionales instaladas por el usuario

El chat de texto y los comandos locales usan la biblioteca estándar de Python. El modo opcional de control de Windows puede utilizar los siguientes proyectos externos:

- **PyAutoGUI**: automatización de ratón, teclado y capturas. Proyecto y avisos: <https://github.com/asweigart/pyautogui>.
- **Pillow**: tratamiento de imágenes. Proyecto y avisos: <https://github.com/python-pillow/Pillow>.
- **pywinauto**: acceso opcional a Windows UI Automation. Proyecto y avisos: <https://github.com/pywinauto/pywinauto>.

El iniciador ofrece descargarlos mediante pip únicamente tras una elección explícita; no se incluyen sus fuentes en este paquete. pip también puede descargar dependencias transitivas, cada una con sus propias condiciones. Revisa la licencia y los avisos de la **versión concreta instalada**, disponibles en su distribución, metadatos y proyecto oficial. Estos enlaces no sustituyen esos textos ni conceden derechos adicionales. No se afirma que esas descargas se hayan realizado o probado en Windows durante la preparación de esta guía.

Python, Tcl/Tk, Windows, winget, Ollama, los modelos y las aplicaciones que el usuario instale conservan sus licencias y condiciones propias. Las APIs y los servicios remotos también tienen condiciones, políticas de datos y posibles costes independientes; este prototipo no los redistribuye ni incluye una suscripción.

## Referencias de diseño revisadas, sin código incorporado

El coordinador revisó en modo de solo lectura estos proyectos y sus licencias en las revisiones indicadas:

- **Microsoft UFO**, revisión `eae3c0a8d168c47cb10df0652e293e092eda1078`, licencia **MIT**: <https://github.com/microsoft/UFO/tree/eae3c0a8d168c47cb10df0652e293e092eda1078>.
- **OpenAdaptAI/OpenAdapt**, revisión `7962352e7c9c047c92973b96585f2e2e5c600b54`, licencia **MIT**: <https://github.com/OpenAdaptAI/OpenAdapt/tree/7962352e7c9c047c92973b96585f2e2e5c600b54>.
- **OpenInterpreter/open-interpreter**, revisión `80d8f55385452457a625dbabc032f3003b9545b4`, licencia **Apache-2.0**: <https://github.com/OpenInterpreter/open-interpreter/tree/80d8f55385452457a625dbabc032f3003b9545b4>.

**No se ha copiado ni adaptado código de esos proyectos en esta entrega.** La integración de UI Automation es una implementación propia, inspirada en la separación entre inspección del escritorio y acciones de UFO. Las observaciones por paso, el historial y el catálogo restringido también son propios. Estas referencias no son dependencias, no requieren instalar esos proyectos y no acreditan equivalencia funcional, compatibilidad verificada ni respaldo de sus autores. Las licencias citadas corresponden a las revisiones revisadas, no a una promesa sobre versiones futuras.

## Revisión de referencias del PDF — v0.6

Esta ampliación se basa en las revisiones documentales registradas en `review_group0.json` y `review_group2.json`. Se leyeron README, licencias y metadatos de clones superficiales de solo lectura; no se instalaron ni ejecutaron los proyectos. Las funciones descritas por sus autores no son pruebas de funcionamiento de este asistente ni de compatibilidad con Windows o con APIs reales.

Las siguientes referencias se utilizaron únicamente como inspiración conceptual para organización de tareas, evidencia y supervisión:

- **storytold/craft-anything**, revisión `75d0fa0b4d96dd8d7d8c1def87b974c86a211833`, **MIT OR Apache-2.0**, a elección: <https://github.com/storytold/craft-anything/tree/75d0fa0b4d96dd8d7d8c1def87b974c86a211833>. Referencia de fases de trabajo, aprobación y presentación de cobertura y límites. Sus recursos y marcas tienen condiciones independientes.
- **Donchitos/Claude-Code-Game-Studios**, revisión `abc0de79d6ceb0b5d7aa693945849b3937afbe6a`, **MIT**: <https://github.com/Donchitos/Claude-Code-Game-Studios/tree/abc0de79d6ceb0b5d7aa693945849b3937afbe6a>. Referencia de hitos, evidencia por requisito y distinción entre construido y comprobado.
- **stablyai/orca**, revisión `58c09251b193dabccdcb489e70ce5c697ec2bde8`, **MIT**: <https://github.com/stablyai/orca/tree/58c09251b193dabccdcb489e70ce5c697ec2bde8>. Referencia de historial y presentación del estado de una tarea.
- **leepokai/Codync**, revisión `01ac25690e671e6b6a6b3282cdbb566802225b5c`, **Apache-2.0**: <https://github.com/leepokai/Codync/tree/01ac25690e671e6b6a6b3282cdbb566802225b5c>. Referencia de estado persistente separado del proveedor y aprobaciones revocables. La disponibilidad de cliente Windows no implica control remoto de pantalla Windows en esa revisión.
- **CopilotKit/OpenDots**, revisión `46eaf96c9e3802adc972ceafd8f20f99bda34e70`, **MIT** para el template: <https://github.com/CopilotKit/OpenDots/tree/46eaf96c9e3802adc972ceafd8f20f99bda34e70>. Referencia de aprobación de una propuesta exacta y revisión de operaciones interrumpidas. OpenDots y OpenBot son proyectos distintos; los servicios asociados conservan sus términos.
- **j-hernandez-dev/nova-assistant**, revisión `0bc7e8851790167c13a1be39697f4b136150f73d`, **MIT**: <https://github.com/j-hernandez-dev/nova-assistant/tree/0bc7e8851790167c13a1be39697f4b136150f73d>. Referencia de permisos de un uso, parada y recuperación sin reproducir automáticamente operaciones pendientes.

**Todos los conceptos nuevos de v0.6 son implementaciones propias:** hitos manuales confirmados por la persona, journal mínimo opcional y caducidad de 90 segundos de las propuestas de acción pendientes. Estos detalles y ese plazo son decisiones de este prototipo; no se atribuyen como una implementación exacta, copiada o adaptada de los proyectos citados. Un hito confirmado no demuestra por sí solo éxito técnico, un journal no equivale a deshacer o reanudar acciones y la caducidad no sustituye la aprobación individual ni garantiza que la pantalla permanezca igual.

**En v0.6 no se incorporaron código, prompts, hooks, recursos ni textos de licencia de los repositorios revisados del PDF. En v0.7 solo se añaden los textos de licencia/NOTICE de referencia indicados arriba, sin código externo.** No son nuevas dependencias del asistente. Salvo los textos de referencia de v0.7 indicados arriba, no se reproducen sus licencias completas porque no se redistribuye material suyo; las identificaciones anteriores documentan únicamente las revisiones consultadas y no relicencian servicios, modelos, recursos de terceros ni marcas.

### Referencias excluidas de copia

- **jossuealcacao-exe/madre**, revisión `ef24e41dd2f979924106b7ac85340472e9bd8981`, **BUSL-1.1 (Business Source License 1.1)**: <https://github.com/jossuealcacao-exe/madre/tree/ef24e41dd2f979924106b7ac85340472e9bd8981>. No se trata como MIT ni como licencia abierta sin restricciones. La revisión documental describe condiciones adicionales y un cambio futuro a AGPL-3.0-only por versión; no se incorpora implementación, texto ni módulos.
- **togg53192-cmd/jailbreaks**, revisión `4c06343e51731f1b45425316b1abd308b2262855`, **licencia desconocida**: <https://github.com/togg53192-cmd/jailbreaks/tree/4c06343e51731f1b45425316b1abd308b2262855>. Solo se revisaron README y nombres de archivos de licencia; no se leyeron ni importaron sus archivos de prompts. No se incorpora material ni evasión de salvaguardas.
- **miguelrobles2002/JARVIS**, revisión `1ebbd31a065389f07a7be3dc4e58359e3a70ccbb`, **licencia desconocida**: <https://github.com/miguelrobles2002/JARVIS/tree/1ebbd31a065389f07a7be3dc4e58359e3a70ccbb>. La visibilidad pública y las funciones anunciadas no conceden permiso de copia.

Los demás proyectos de esos dos informes son referencias documentales, no componentes incorporados. Sus descripciones, reservas de licencia y descartes permanecen en los informes; esta selección no implica adopción de sus funciones ni auditoría completa de sus dependencias.

Antes de redistribuir material de un tercero en una revisión posterior, identifica qué archivos se incorporan y conserva los textos de licencia y avisos que exijan sus versiones concretas. Este documento no sustituye los textos originales de licencia ni concede derechos adicionales.
