"""Jean v0.8. Chat con fuentes explícitas y control supervisado separado."""
from __future__ import annotations

import datetime as dt
import itertools
import json
import os
from pathlib import Path
import queue
import subprocess
import sys
import threading
import unicodedata
import urllib.error
import urllib.request

from models import (PROVIDERS, PROVIDER_LABELS, MODEL_SUGGESTIONS, list_models,
                    ask_model, delete_keys, load_settings, resolve_key,
                    save_key, save_settings, validate_settings)

APPS = {"notepad": "notepad.exe", "calculator": "calc.exe", "paint": "mspaint.exe"}
OLLAMA_ENDPOINT = "http://127.0.0.1:11434/api/chat"
HELP = (
    "Comandos locales (sin IA):\n"
    "• hora\n• abrir calculadora\n• abrir bloc de notas\n• abrir paint\n"
    "• listar archivos (elige antes una carpeta con el botón)\n"
    "• buscar archivos PALABRA (solo nombres en la carpeta elegida)\n• diagnostico\n• ayuda\n\n"
    "Fuentes locales: vista previa y búsqueda de texto UTF-8, con extracto opcional para el chat. "
    "Uso de chat: llamadas y duración de esta sesión, sin estimar precios.\n\n"
    "Para conversar, configura un proveedor y activa las consultas; pulsa «Preguntar IA». "
    "Preguntar IA solo responde texto. Control supervisado es un modo aparte: comparte pantalla "
    "y puede realizar acciones únicamente tras aprobar cada paso. Lee la guía antes de activarlo."
)


def normalize(text: str) -> str:
    return " ".join("".join(c for c in unicodedata.normalize("NFD", text.casefold())
                            if unicodedata.category(c) != "Mn").split()).rstrip("?!¿¡.")


def open_known_app(key: str) -> None:
    if key not in APPS:
        raise ValueError("Programa no permitido")
    if sys.platform != "win32":
        raise OSError("Abrir programas solo está disponible en Windows")
    # La ubicación del sistema se obtiene de Windows, no del PATH ni del chat.
    import ctypes
    buffer = ctypes.create_unicode_buffer(32768)
    length = ctypes.windll.kernel32.GetSystemDirectoryW(buffer, len(buffer))
    if not length or length >= len(buffer):
        raise OSError("No se pudo localizar la carpeta del sistema")
    executable = Path(buffer.value) / APPS[key]
    subprocess.Popen([str(executable)], shell=False, cwd=buffer.value)


class AssistantCore:
    def __init__(self, folder=None, opener=None, clock=None):
        self.folder = None
        self.opener = opener or open_known_app
        self.clock = clock or dt.datetime.now
        if folder is not None:
            self.set_folder(folder)

    def set_folder(self, path):
        selected = Path(path).expanduser().resolve(strict=True)
        if not selected.is_dir():
            raise ValueError("Selecciona una carpeta, no un archivo")
        self.folder = selected

    def respond(self, text: str) -> str:
        command = normalize(text)
        if command in ("ayuda", "hola", "comandos"):
            return HELP
        if command in ("hora", "que hora es", "dime la hora"):
            return "Son las " + self.clock().strftime("%H:%M:%S") + " (hora de esta computadora)."
        apps = {"abrir calculadora": "calculator", "abrir bloc de notas": "notepad",
                "abrir paint": "paint"}
        if command in apps:
            try:
                self.opener(apps[command])
                return "Se solicitó abrir el programa. Comprueba su ventana; no puedo verificar que haya aparecido."
            except (OSError, ValueError):
                return "No se pudo abrir el programa. Esta función requiere Windows y la aplicación instalada."
        if command == "listar archivos":
            return self.list_files()
        if command == "diagnostico":
            from diagnostics import local_diagnostics
            return local_diagnostics()
        if command.startswith("buscar archivos "):
            return self.search_files(text.strip().split(None, 2)[2].strip())
        return "No reconozco ese comando local. Escribe «ayuda» o usa «Preguntar IA» para conversar sin ejecutar acciones."

    def search_files(self, query):
        if self.folder is None:
            return "Primero elige una carpeta con «Elegir carpeta». No acepto rutas del chat."
        if not isinstance(query, str) or not 1 <= len(query.strip()) <= 100 or any(ord(c) < 32 for c in query):
            return "Escribe una búsqueda de nombre de 1 a 100 caracteres, sin saltos de línea."
        try:
            rows = []
            count = 0
            truncated = False
            with os.scandir(self.folder) as entries:
                for entry in entries:
                    count += 1
                    if count > 1000:
                        truncated = True
                        break
                    if query.strip().casefold() in entry.name.casefold():
                        rows.append(json.dumps(entry.name, ensure_ascii=False))
                        if len(rows) == 100:
                            truncated = True
                            break
            return ("Coincidencias por nombre (sin leer contenidos ni subcarpetas):\n" +
                    ("\n".join(rows) or "No se encontraron coincidencias en las entradas revisadas.") +
                    ("\nLímite alcanzado: máximo 1000 entradas o 100 coincidencias; puede haber más." if truncated else ""))
        except OSError:
            return "No se pudo buscar en la carpeta; selecciónala de nuevo."

    def list_files(self):
        if self.folder is None:
            return "Primero elige una carpeta con «Elegir carpeta». No acepto rutas escritas en el chat."
        try:
            with os.scandir(self.folder) as entries:
                batch = list(itertools.islice(entries, 101))
            rows = []
            for entry in batch[:100]:
                kind = "enlace" if entry.is_symlink() else ("carpeta" if entry.is_dir(follow_symlinks=False) else "archivo")
                # Escapa saltos de línea y controles en nombres, sin abrir archivos.
                name = json.dumps(entry.name, ensure_ascii=False)
                rows.append(f"[{kind}] {name}")
            result = "Nombres de la carpeta elegida (sin leer contenidos):\n" + ("\n".join(rows) or "Carpeta vacía.")
            if len(batch) > 100:
                result += "\nSe muestran solo las primeras 100 entradas; no se recorren subcarpetas."
            return result
        except OSError:
            return "No se pudo listar la carpeta: puede haber cambiado o no tener permiso. Elige otra carpeta."


def ask_ollama(prompt: str, model: str, endpoint: str = OLLAMA_ENDPOINT) -> str:
    if endpoint != OLLAMA_ENDPOINT:
        raise ValueError("Solo se permite el endpoint local fijo de Ollama")
    try:
        return ask_model(prompt, {"provider": "Ollama local", "base_url": PROVIDERS["Ollama local"][0], "model": model})
    except ValueError:
        raise ValueError("No se pudo consultar Ollama local. Comprueba el mensaje, el modelo y la conexión.") from None


def main():
    try:
        import tkinter as tk
        from tkinter import filedialog, messagebox, scrolledtext, ttk
    except ImportError:
        print("Se necesita Python con Tcl/Tk. En Windows usa el instalador oficial con Tcl/Tk habilitado.")
        return 1
    root = tk.Tk()
    root.title("Jean · prototipo 0.8")
    root.geometry("900x850")
    root.minsize(720, 680)
    root.configure(padx=18, pady=16)
    from source_context import PendingSource
    from usage_meter import UsageMeter
    pending_source = PendingSource()
    meter = UsageMeter()
    core = AssistantCore()
    results = queue.Queue()
    confirmed_destinations = set()
    ttk.Label(root, text="Jean · asistente personal", font=("Segoe UI", 20, "bold")).pack(anchor="w")
    ttk.Label(root, text="Acciones locales limitadas · IA opcional, solo texto").pack(anchor="w", pady=(2, 12))
    folder_text = tk.StringVar(value="Sin carpeta elegida. No se leerán contenidos de archivos.")
    def choose_folder():
        selected = filedialog.askdirectory(title="Elige la única carpeta que quieres listar", mustexist=True)
        if selected:
            try:
                core.set_folder(selected)
                folder_text.set(str(core.folder))
            except (OSError, ValueError):
                messagebox.showerror("Carpeta no válida", "No se pudo seleccionar esa carpeta.")
    folder_bar = ttk.Frame(root)
    folder_bar.pack(fill="x")
    ttk.Button(folder_bar, text="Elegir carpeta", command=choose_folder).pack(side="left")
    ttk.Button(folder_bar, text="Olvidar carpeta", command=lambda: (setattr(core, "folder", None), folder_text.set("Sin carpeta elegida."))).pack(side="left", padx=8)
    ttk.Label(root, textvariable=folder_text, wraplength=780).pack(anchor="w", pady=8)
    transcript = scrolledtext.ScrolledText(root, wrap="word", font=("Segoe UI", 11), state="disabled", height=15)
    transcript.pack(fill="both", expand=True)
    def append(who, text):
        transcript.configure(state="normal")
        transcript.insert("end", f"{who}\n{text}\n\n")
        transcript.configure(state="disabled")
        transcript.see("end")
    append("Asistente", HELP)
    options = ttk.LabelFrame(root, text="Modelo de nube u Ollama · chat de texto / control supervisado aparte", padding=8)
    options.pack(fill="x", pady=8)
    try:
        initial = load_settings()
    except (ValueError, TypeError, AttributeError):
        initial = {"provider": "OpenAI", "base_url": PROVIDERS["OpenAI"][0], "model": ""}
        messagebox.showwarning("Configuración", "No se pudo leer la configuración del perfil; se usarán valores iniciales.")
    provider = tk.StringVar(value=initial["provider"])
    base_url = tk.StringVar(value=initial["base_url"])
    model = tk.StringVar(value=initial["model"])
    api_key = tk.StringVar(value="")
    enabled = tk.BooleanVar(value=False)
    persist_key = tk.BooleanVar(value=False)
    options.columnconfigure(1, weight=1)
    ttk.Label(options, text="Proveedor:").grid(row=0, column=0, sticky="w")
    provider_label = tk.StringVar(value=PROVIDER_LABELS[provider.get()])
    selector = ttk.Combobox(options, textvariable=provider_label, values=list(PROVIDER_LABELS.values()), state="readonly")
    selector.grid(row=0, column=1, sticky="ew", padx=6)
    for row, label, variable in [(1, "URL base:", base_url), (2, "Modelo exacto:", model), (3, "Clave API:", api_key)]:
        ttk.Label(options, text=label).grid(row=row, column=0, sticky="w", pady=3)
        if row == 2:
            model_selector = ttk.Combobox(options, textvariable=model, values=MODEL_SUGGESTIONS[provider.get()])
            model_selector.grid(row=row, column=1, sticky="ew", padx=6)
        else:
            ttk.Entry(options, textvariable=variable, show="*" if row == 3 else "").grid(row=row, column=1, sticky="ew", padx=6)
    hint = tk.StringVar()
    def update_hint():
        env = PROVIDERS[provider.get()][1]
        hint.set(f"Clave: campo actual > {env} > guardada para este destino." if env else "Ollama local no necesita clave. Modelo instalado por separado.")
    def provider_changed(event=None):
        provider.set(next(key for key, label in PROVIDER_LABELS.items() if label == provider_label.get()))
        model_selector.configure(values=MODEL_SUGGESTIONS[provider.get()])
        base_url.set(PROVIDERS[provider.get()][0])
        model.set("")
        api_key.set("")
        persist_key.set(False)
        enabled.set(False)
        update_hint()
    selector.bind("<<ComboboxSelected>>", provider_changed)
    # Cambiar un destino requiere habilitar de nuevo el envío y borra la clave escrita.
    def destination_changed(*args):
        enabled.set(False)
        api_key.set("")
        persist_key.set(False)
    base_url.trace_add("write", destination_changed)
    update_hint()
    ttk.Label(options, textvariable=hint, wraplength=800).grid(row=4, column=0, columnspan=2, sticky="w")
    ttk.Checkbutton(options, text="Permitir enviar mi mensaje actual al destino indicado (puede tener coste)", variable=enabled).grid(row=5, column=0, columnspan=2, sticky="w", pady=3)
    ttk.Checkbutton(options, text="Guardar también la clave escrita en el perfil (texto plano, NO cifrado)", variable=persist_key).grid(row=6, column=0, columnspan=2, sticky="w")
    def current_settings():
        return validate_settings(provider.get(), base_url.get(), model.get())
    def store():
        try:
            settings = current_settings()
            if persist_key.get():
                if not messagebox.askyesno("Clave sin cifrar", "La clave escrita se guardará en texto plano en tu perfil. No se recomienda en equipos compartidos. ¿Guardarla?"):
                    return
                save_key(settings, api_key.get())
            save_settings(settings)
            persist_key.set(False)
            messagebox.showinfo("Guardado", "Configuración guardada en tu perfil. La autorización de envío no se guarda.")
        except (ValueError, OSError) as exc:
            messagebox.showerror("No se pudo guardar", str(exc) if isinstance(exc, ValueError) else "No se pudo escribir en el perfil.")
    def forget_keys():
        try:
            delete_keys()
            api_key.set("")
            persist_key.set(False)
            messagebox.showinfo("Claves borradas", "Se borró el archivo local de claves. Las variables de entorno no se modifican; no es un borrado seguro del disco.")
        except ValueError as exc:
            messagebox.showerror("Error", str(exc))
    settings_buttons = ttk.Frame(options)
    settings_buttons.grid(row=7, column=0, columnspan=2, sticky="w", pady=4)
    ttk.Button(settings_buttons, text="Guardar configuración", command=store).pack(side="left")
    ttk.Button(settings_buttons, text="Borrar claves guardadas", command=forget_keys).pack(side="left", padx=8)
    ttk.Label(options, text="Modelo libre: sugerencias orientativas, no garantía de acceso. Requiere API y cuota propias, no basta una suscripción de chat. Chat: mensaje actual + extracto si lo apruebas. Control: captura completa y pasos, con consentimiento aparte.", wraplength=800).grid(row=8, column=0, columnspan=2, sticky="w")
    entry = ttk.Entry(root, font=("Segoe UI", 11))
    entry.pack(fill="x", pady=(0, 8))
    status = tk.StringVar(value="Listo · Enter ejecuta solo comandos locales")
    def get_text():
        text = entry.get().strip()
        if not text:
            return None
        if len(text) > 8000:
            messagebox.showwarning("Mensaje largo", "Usa como máximo 8000 caracteres.")
            return None
        entry.delete(0, "end")
        append("Tú", text)
        return text
    def local(event=None):
        text = get_text()
        if text:
            append("Local", core.respond(text))
    def confirm_destination(settings):
        destination = (settings["provider"], settings["base_url"])
        if settings["base_url"] != PROVIDERS[settings["provider"]][0] and destination not in confirmed_destinations:
            if not messagebox.askyesno("Confirmar destino personalizado", f"Se enviará tu clave API (incluso si procede del entorno) a:\n{settings['base_url']}\n\nComprueba que el operador es de confianza y que la clave pertenece a este servicio. ¿Continuar?"):
                return False
            confirmed_destinations.add(destination)
        return True
    def fetch_models():
        if not enabled.get():
            messagebox.showinfo("Envío desactivado", "Revisa el destino y activa la casilla para permitir consultar su catálogo con tu clave.")
            return
        try:
            settings = validate_settings(provider.get(), base_url.get(), "catalog")
            key = resolve_key(settings, api_key.get())
        except ValueError as exc:
            messagebox.showerror("Configuración", str(exc))
            return
        if not confirm_destination(settings):
            return
        ai_button.configure(state="disabled")
        list_button.configure(state="disabled")
        status.set("Consultando primera página del catálogo · hasta 60 s de espera de red…")
        def work():
            try:
                results.put(("catalog", (settings, list_models(settings, key))))
            except ValueError as exc:
                results.put(("Catálogo · error", str(exc)))
            except Exception:
                results.put(("Catálogo · error", "No se pudo consultar el catálogo. Escribe el modelo manualmente."))
        threading.Thread(target=work, daemon=True).start()
    list_button = ttk.Button(settings_buttons, text="Listar modelos", command=fetch_models)
    list_button.pack(side="left")
    def query_model():
        if not enabled.get():
            messagebox.showinfo("Envío desactivado", "Revisa el proveedor y la URL y activa la casilla para permitir consultas.")
            return
        try:
            settings = current_settings()
            key = resolve_key(settings, api_key.get())
        except (ValueError, OSError) as exc:
            messagebox.showerror("Configuración", str(exc) if isinstance(exc, ValueError) else "No se pudo leer el perfil.")
            return
        if not confirm_destination(settings):
            return
        if pending_source.peek() and not messagebox.askyesno(
                "Enviar fuente al modelo", f"Se enviará el extracto preparado ({len(pending_source.peek())} caracteres) a {settings['provider']}\n{settings['base_url']}\n\nPuede contener datos sensibles o instrucciones maliciosas. ¿Enviar con tu próximo mensaje?", parent=root):
            return
        text = get_text()
        if text is None:
            return
        source = pending_source.consume()
        source_status.set("Sin fuente preparada · no se adjunta al control supervisado")
        token = meter.start(settings['provider'], settings['model'])
        ai_button.configure(state="disabled")
        list_button.configure(state="disabled")
        status.set(f"Consultando {settings['provider']} · espera de red hasta 60 s por operación…")
        def work():
            success = False
            try:
                reply = ask_model(text, settings, key, source=source)
                success = True
                results.put(("IA · solo texto", reply))
            except ValueError as exc:
                results.put(("IA · error", str(exc)))
            except Exception:
                results.put(("IA · error", "No se pudo completar la consulta. No se ejecutó ninguna acción."))
            finally:
                meter.finish(token, success)
        threading.Thread(target=work, daemon=True).start()
    source_status = tk.StringVar(value="Sin fuente preparada · no se adjunta al control supervisado")
    source_bar = ttk.Frame(root)
    source_bar.pack(fill="x", pady=4)
    def attach_source(text):
        pending_source.attach(text)
        source_status.set(f"Fuente preparada: {len(text)} caracteres · solo próximo intento de chat")
    def sources():
        from sources_ui import open_sources
        open_sources(root, attach_source)
    def forget_source():
        pending_source.clear()
        source_status.set("Sin fuente preparada · no se adjunta al control supervisado")
    ttk.Button(source_bar, text="Fuentes locales", command=sources).pack(side="left")
    ttk.Button(source_bar, text="Quitar fuente", command=forget_source).pack(side="left", padx=4)
    ttk.Button(source_bar, text="Uso de chat", command=lambda: messagebox.showinfo("Uso de esta sesión", meter.summary(), parent=root)).pack(side="left")
    ttk.Label(root, textvariable=source_status, wraplength=800).pack(anchor="w")
    buttons = ttk.Frame(root)
    buttons.pack(fill="x")
    ttk.Button(buttons, text="Comando local", command=local).pack(side="left")
    ai_button = ttk.Button(buttons, text="Preguntar IA", command=query_model)
    ai_button.pack(side="left", padx=8)
    loaded_task = {"goal": "", "checkpoints": ""}
    def load_task(goal, checkpoints):
        entry.delete(0, "end")
        entry.insert(0, goal)
        loaded_task.update(goal=goal, checkpoints=checkpoints)
        append("Jean · tarea cargada", "Objetivo e hitos preparados. No se ejecutó ni envió nada. Revisa el objetivo; cambiarlo descarta los hitos cargados para el próximo control.")
    def library():
        from library_ui import open_library
        open_library(root, load_task, entry.get())
    ttk.Button(buttons, text="Biblioteca de tareas", command=library).pack(side="left", padx=4)
    def computer_task():
        if not enabled.get():
            messagebox.showinfo("Envío desactivado", "Revisa proveedor y destino y permite el envío antes de usar visión.")
            return
        try:
            settings = current_settings()
            key = resolve_key(settings, api_key.get())
        except (ValueError, OSError):
            messagebox.showerror("Configuración", "Revisa modelo, destino y clave API.")
            return
        if not confirm_destination(settings):
            return
        text = get_text()
        if text:
            from control_ui import open_control
            checkpoints = loaded_task["checkpoints"] if text == loaded_task["goal"] else ""
            open_control(root, settings, key, text, initial_checkpoints=checkpoints)
    ttk.Button(buttons, text="Control supervisado", command=computer_task).pack(side="left")
    def clear():
        forget_source()
        transcript.configure(state="normal")
        transcript.delete("1.0", "end")
        transcript.configure(state="disabled")
    ttk.Button(buttons, text="Limpiar chat", command=clear).pack(side="right")
    ttk.Label(root, textvariable=status).pack(anchor="w", pady=(8, 0))
    entry.bind("<Return>", local)
    entry.focus_set()
    def poll():
        try:
            who, text = results.get_nowait()
        except queue.Empty:
            pass
        else:
            if who == "catalog":
                settings, names = text
                if (settings["provider"], settings["base_url"]) == (provider.get(), base_url.get().strip().rstrip("/")):
                    model_selector.configure(values=names)
                    append("Catálogo", f"{len(names)} modelos en la primera página (máximo 500). Abre el desplegable o escribe un ID. La lista no garantiza compatibilidad con chat ni acceso. No se cambió el modelo elegido.")
                else:
                    append("Catálogo", "Destino cambiado durante la consulta; se descartó la lista anterior.")
            else:
                append(who, text)
            status.set("Listo · Enter ejecuta solo comandos locales")
            ai_button.configure(state="normal")
            list_button.configure(state="normal")
        root.after(100, poll)
    root.after(100, poll)
    root.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
