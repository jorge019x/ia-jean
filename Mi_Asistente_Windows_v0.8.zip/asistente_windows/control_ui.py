"""Ventana de aprobación no modal. Todas las llamadas Tk quedan en su hilo."""
import base64
import json
import math
import queue
import threading
import time


def open_control(root, settings, key, goal, initial_checkpoints=""):
    import tkinter as tk
    from tkinter import filedialog, messagebox, scrolledtext, ttk
    from task_tools import MinimalJournal, parse_checkpoints
    from computer_control import WindowsDesktop, VISION_PROVIDERS, run_control
    if getattr(root, "_control_active", False):
        messagebox.showinfo("Control activo", "Detén la tarea anterior antes de iniciar otra.")
        return
    if settings["provider"] not in VISION_PROVIDERS:
        messagebox.showerror("Modelo sin visión configurada", "Elige Claude, Gemini, OpenAI o una API compatible con visión y herramientas. DeepSeek y Ollama mantienen chat de texto.")
        return
    if not messagebox.askyesno("Compartir pantalla y controlar Windows", "Se enviará una captura completa del monitor principal en CADA paso al proveedor configurado. También se enviarán títulos de ventanas y nombres/tipos de controles accesibles si UI Automation está disponible. Puede revelar contraseñas visibles, mensajes y datos personales y generar costes.\n\nRevisa cada clic y tecla: pueden borrar, enviar o comprar aunque la explicación del modelo diga otra cosa. No autorices terminales ni comandos. No hay garantía de seguridad o éxito.\n\nToda acción requiere aprobación individual. Parar no cancela consultas ni instaladores ya enviados. ¿Activar para esta tarea?"):
        return
    try:
        desktop = WindowsDesktop()
    except ValueError as exc:
        messagebox.showerror("Control no disponible", str(exc))
        return
    root._control_active = True
    stop = threading.Event()
    events = queue.Queue()
    pending = []
    pending_deadline = [None]
    journal = MinimalJournal()
    selected_plan = [None]
    win = tk.Toplevel(root)
    win.title("Jean · Control supervisado · v0.7")
    win.geometry("820x900")
    win.minsize(760, 700)
    preview = ttk.Label(win, text="Aquí aparecerá la captura enviada al modelo.")
    preview.pack(pady=4)
    text = scrolledtext.ScrolledText(win, height=10, wrap="word", state="disabled")
    text.pack(fill="both", expand=True, padx=12, pady=12)
    def show(value):
        text.configure(state="normal")
        text.delete("1.0", "end")
        text.insert("end", value)
        text.configure(state="disabled")
    show("Al iniciar se minimizará el asistente. Tienes 5 segundos para enfocar la aplicación destino.\n\nCada acción mostrará esta ventana: comprueba coordenadas, texto y consecuencias antes de aprobar. Si hay duda, rechaza. No muevas ventanas mientras la propuesta espera.\n\nParada de emergencia adicional: lleva el ratón a la esquina superior izquierda. No se permite UAC ni ventanas elevadas.")
    plan_enabled = tk.BooleanVar(value=bool(initial_checkpoints))
    ttk.Checkbutton(win, text="Usar mis hitos (1–8 líneas; confirmaré cada hito antes de avanzar)", variable=plan_enabled).pack(anchor="w", padx=12)
    plan_text = tk.Text(win, height=3, wrap="word")
    plan_text.pack(fill="x", padx=12)
    plan_text.insert("1.0", initial_checkpoints)
    state = tk.StringVar(value="Preparado")
    ttk.Label(win, textvariable=state, wraplength=610).pack(pady=4)
    row = ttk.Frame(win)
    row.pack(pady=12)
    def decide(allowed):
        if pending:
            event, result = pending.pop()
            result.append(allowed)
            win.withdraw()
            event.set()
    approve_button = ttk.Button(row, text="Aprobar ESTA acción", command=lambda: decide(True), state="disabled")
    approve_button.pack(side="left")
    reject_button = ttk.Button(row, text="Rechazar", command=lambda: decide(False), state="disabled")
    reject_button.pack(side="left", padx=8)
    def halt():
        stop.set()
        decide(False)
        state.set("Parada solicitada; la red puede tardar hasta 60 s. No cancela lo ya enviado.")
    ttk.Button(row, text="PARAR", command=halt).pack(side="left")
    stop_win = tk.Toplevel(root)
    stop_win.title("PARAR control IA")
    stop_win.geometry("190x70+20+20")
    stop_win.attributes("-topmost", True)
    ttk.Button(stop_win, text="PARAR CONTROL", command=halt).pack(fill="both", expand=True)
    stop_win.protocol("WM_DELETE_WINDOW", halt)
    stop_win.withdraw()
    def export_journal():
        destination = filedialog.asksaveasfilename(parent=win, title="Guardar registro mínimo (sin textos ni capturas)", defaultextension=".json", filetypes=[("JSON", "*.json")])
        if destination:
            try:
                with open(destination, "w", encoding="utf-8") as stream:
                    stream.write(journal.export())
            except OSError:
                messagebox.showerror("Registro", "No se pudo guardar el registro", parent=win)
    export_button = ttk.Button(win, text="Exportar registro mínimo al terminar", command=export_journal, state="disabled")
    export_button.pack(pady=4)
    running = [False]
    finished = [False]
    def close():
        halt()
        if finished[0] or not running[0]:
            root._control_active = False
            stop_win.destroy()
            win.destroy()
            root.deiconify()
        else:
            win.withdraw()
    win.protocol("WM_DELETE_WINDOW", close)
    def approve(action, step):
        event, result = threading.Event(), []
        deadline = time.monotonic() + 90
        pending_deadline[0] = deadline
        events.put(("approve", (action, step, event, result)))
        while not event.wait(0.1):
            if stop.is_set() or time.monotonic() >= deadline:
                return False
        return bool(result and result[0]) and not stop.is_set()
    def work():
        try:
            if stop.wait(5):
                result = "Detenido antes de capturar"
            else:
                result = run_control(goal, settings, key, desktop, approve, stop, lambda value: events.put(("status", value)), checkpoints=selected_plan[0], journal=journal)
        except ValueError as exc:
            result = str(exc)
        except Exception:
            result = "Control interrumpido (fallo de pantalla, permisos o parada de emergencia). Revisa el equipo; no se reintentó."
        finally:
            uia = getattr(desktop, "uia", None)
            if uia is not None:
                try:
                    uia.close()
                except Exception:
                    pass  # La tarea ya terminó; no mostrar detalles internos ni reintentar acciones.
        events.put(("done", result))
    def start():
        if plan_enabled.get():
            try:
                raw_plan = plan_text.get("1.0", "end").strip()
                parse_checkpoints(raw_plan)
            except ValueError as exc:
                messagebox.showerror("Hitos", str(exc), parent=win)
                return
            selected_plan[0] = raw_plan
        plan_text.configure(state="disabled")
        start_button.configure(state="disabled")
        running[0] = True
        root.iconify()
        win.withdraw()
        stop_win.deiconify()
        threading.Thread(target=work, daemon=True).start()
    start_button = ttk.Button(win, text="Iniciar · enfocar destino en 5 s", command=start)
    start_button.pack(pady=8)
    def poll():
        if not win.winfo_exists():
            return
        if pending and pending_deadline[0] is not None and time.monotonic() >= pending_deadline[0]:
            decide(False)
            approve_button.configure(state="disabled")
            reject_button.configure(state="disabled")
            state.set("Propuesta caducada; no se ejecutará. Vuelve a iniciar para observar de nuevo.")
        try:
            kind, data = events.get_nowait()
        except queue.Empty:
            pass
        else:
            if kind == "approve":
                action, step, event, result = data
                if stop.is_set():
                    result.append(False)
                    event.set()
                else:
                    pending.append((event, result))
                    raw_image = getattr(desktop, "last_image", None)
                    if raw_image:
                        image = tk.PhotoImage(data=base64.b64encode(raw_image))
                        scale = max(1, math.ceil(image.width() / 720), math.ceil(image.height() / 300))
                        preview.image = image.subsample(scale)
                        preview.configure(image=preview.image, text="")
                    show((str(getattr(desktop, "current_checkpoint", "")) + "\n\n") + ("El modelo propone completar el hito: aprueba SOLO si comprobaste su resultado.\n\n" if action["action"] == "finish" else "") + f"Paso {step} · aprobación válida por 90 s; si la pantalla cambia, rechaza\n\n" + json.dumps(action, ensure_ascii=False, indent=2) + "\n\nObservación UIA actual (IDs, ventanas y controles):\n" + json.dumps(getattr(desktop, "last_observation", {}), ensure_ascii=False, indent=2) + "\n\nTODO clic/tecla puede enviar, comprar, borrar o instalar. No apruebes si no entiendes el efecto. Las coordenadas se refieren a la captura anterior; si la pantalla cambió, RECHAZA.")
                    approve_button.configure(state="normal")
                    reject_button.configure(state="normal")
                    win.deiconify()
                    win.lift()
            elif kind == "status":
                state.set(data)
            elif kind == "done":
                finished[0] = True
                export_button.configure(state="normal")
                stop_win.withdraw()
                root._control_active = False
                show(data)
                approve_button.configure(state="disabled")
                reject_button.configure(state="disabled")
                win.deiconify()
                root.deiconify()
        win.after(100, poll)
    win.after(100, poll)
