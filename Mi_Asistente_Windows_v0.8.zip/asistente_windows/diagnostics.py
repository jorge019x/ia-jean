"""Diagnóstico local pasivo: no importa paquetes opcionales ni prueba conexiones."""
import importlib.util
import os
from pathlib import Path
import sys


def local_diagnostics():
    lines = ["Diagnóstico local (detección, NO prueba funcional):",
             "Windows: " + ("detectado" if sys.platform == "win32" else "no; control real Windows no disponible"),
             "Python 3.10+: " + ("sí" if sys.version_info >= (3, 10) else "no")]
    for module, label in (("tkinter", "Tcl/Tk"), ("pyautogui", "PyAutoGUI"), ("PIL", "Pillow"), ("pywinauto", "UI Automation / pywinauto")):
        try:
            found = importlib.util.find_spec(module) is not None
        except (ImportError, ValueError, AttributeError):
            found = False
        lines.append(label + ": " + ("paquete detectable; funcionamiento sin comprobar" if found else "no detectable"))
    local = os.environ.get("LOCALAPPDATA")
    winget_found = sys.platform == "win32" and bool(local) and (Path(local) / "Microsoft/WindowsApps/winget.exe").is_file()
    lines.append("winget: " + ("archivo detectable; no ejecutado" if winget_found else "no detectado en la ubicación prevista"))
    lines.append("Sin red, instalaciones, lectura de claves ni comprobación de cuota/modelos. La detección no garantiza compatibilidad.")
    return "\n".join(lines)
