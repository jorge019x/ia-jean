@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 goto python_fallback
py -3 -c "import sys; assert sys.version_info >= (3,10); import tkinter; root=tkinter.Tk(); root.withdraw(); root.destroy()" >nul 2>nul
if errorlevel 1 goto python_fallback
set "PYTHON_CMD=py -3"
goto options
:python_fallback
where python >nul 2>nul
if errorlevel 1 goto missing
python -c "import sys; assert sys.version_info >= (3,10); import tkinter; root=tkinter.Tk(); root.withdraw(); root.destroy()" >nul 2>nul
if errorlevel 1 goto missing
set "PYTHON_CMD=python"
:options
echo.
echo Jean - asistente personal para Windows - v0.8
echo El chat de texto y los comandos locales no requieren paquetes externos.
echo El control visual usa pyautogui y Pillow opcionales.
echo UI Automation de Windows usa pywinauto opcional.
echo 1. Instalar los tres paquetes opcionales con pip y despues iniciar
echo 2. Iniciar sin instalar nada
echo 3. Salir
echo La opcion 1 descarga paquetes de Internet y modifica este entorno Python.
echo No ejecutes este archivo como administrador.
choice /c 123 /n /m "Elige 1, 2 o 3: "
if errorlevel 3 exit /b 0
if errorlevel 2 goto start
if errorlevel 1 goto install
goto options
:install
%PYTHON_CMD% -m pip install pyautogui Pillow pywinauto
if errorlevel 1 goto install_failed
goto start
:install_failed
echo No se completaron las dependencias. Revisa el error de pip.
echo Puedes iniciar sin instalarlas o salir desde el menu.
goto options
:start
%PYTHON_CMD% assistant.py
set "APP_EXIT=%ERRORLEVEL%"
if not "%APP_EXIT%"=="0" pause
exit /b %APP_EXIT%
:missing
echo Se necesita Python 3.10 o posterior con Tcl/Tk funcional.
echo Lee README.md para instalarlo o reparar Tcl/Tk manualmente.
echo No se ha instalado ni descargado nada.
pause
exit /b 1
