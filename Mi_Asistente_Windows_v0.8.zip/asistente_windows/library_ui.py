"""Editor voluntario de tareas; cargar no ejecuta ni inicia una consulta."""
def open_library(root, on_load, initial_goal=""):
    import tkinter as tk
    from tkinter import messagebox, scrolledtext, ttk
    from task_library import TaskLibrary
    library = TaskLibrary()
    win = tk.Toplevel(root)
    win.title("Jean · Biblioteca local de tareas")
    win.geometry("700x680")
    win.minsize(580, 580)
    win.configure(padx=16, pady=16)
    ttk.Label(win, text="Biblioteca local de Jean", font=("Segoe UI", 17, "bold")).pack(anchor="w")
    ttk.Label(win, text="Guardado voluntario en texto plano. No incluyas claves ni datos sensibles.\nSolo título, objetivo e hitos; nunca acciones, aprobaciones ni capturas.", wraplength=650).pack(anchor="w", pady=8)
    selector = ttk.Combobox(win, state="readonly")
    selector.pack(fill="x")
    title = tk.StringVar()
    ttk.Label(win, text="Título (hasta 100 caracteres)").pack(anchor="w", pady=(8, 0))
    ttk.Entry(win, textvariable=title).pack(fill="x")
    ttk.Label(win, text="Objetivo").pack(anchor="w", pady=(8, 0))
    goal = scrolledtext.ScrolledText(win, height=5, wrap="word")
    goal.pack(fill="both", expand=True)
    goal.insert("1.0", initial_goal)
    ttk.Label(win, text="Hitos opcionales (1–8 líneas)").pack(anchor="w", pady=(8, 0))
    checkpoints = scrolledtext.ScrolledText(win, height=5, wrap="word")
    checkpoints.pack(fill="both", expand=True)
    status = tk.StringVar(value="Nueva tarea sin guardar")
    ttk.Label(win, textvariable=status, wraplength=650).pack(anchor="w", pady=8)
    rows, selected = [], [None]
    def failure():
        messagebox.showerror("Biblioteca", "No se pudo leer o guardar. Revisa permisos, espacio y formato. No se borró la biblioteca para repararla.", parent=win)
    def refresh(task_id=None):
        try:
            rows[:] = library.list_tasks()
        except (OSError, ValueError):
            failure()
            return
        selector.configure(values=[row["title"] for row in rows])
        for index, row in enumerate(rows):
            if row["id"] == task_id:
                selector.current(index)
                return
        selector.set("")
    def new():
        selected[0] = None
        selector.set("")
        title.set("")
        goal.delete("1.0", "end")
        checkpoints.delete("1.0", "end")
        status.set("Nueva tarea sin guardar")
    def choose(event=None):
        index = selector.current()
        if index < 0 or index >= len(rows):
            return
        row = rows[index]
        selected[0] = row["id"]
        title.set(row["title"])
        for field, value in ((goal, row["goal"]), (checkpoints, row["checkpoints"])):
            field.delete("1.0", "end")
            field.insert("1.0", value)
        status.set("Tarea abierta para editar; ninguna acción se ejecutó")
    selector.bind("<<ComboboxSelected>>", choose)
    def save():
        if not messagebox.askyesno("Guardar texto local", "¿Guardar título, objetivo e hitos en tu perfil, en texto plano? No incluyas secretos. Se sustituirá esta tarea si ya estaba guardada.", parent=win):
            return
        try:
            row = library.save(title.get(), goal.get("1.0", "end").strip(), checkpoints.get("1.0", "end").strip(), selected[0])
        except ValueError as exc:
            messagebox.showerror("Tarea no guardada", str(exc), parent=win)
            return
        except OSError:
            failure()
            return
        selected[0] = row["id"]
        refresh(row["id"])
        status.set("Guardada localmente; no se ejecutó ninguna acción")
    def load():
        from task_library import validate_task
        import uuid
        try:
            row = validate_task({"id": selected[0] or str(uuid.uuid4()), "title": title.get(), "goal": goal.get("1.0", "end").strip(), "checkpoints": checkpoints.get("1.0", "end").strip()})
        except ValueError as exc:
            messagebox.showerror("Tarea", str(exc), parent=win)
            return
        on_load(row["goal"], row["checkpoints"])
        status.set("Cargada en Jean, sin ejecutar. Revisa objetivo y solicita Control supervisado aparte.")
    def delete():
        if selected[0] is None:
            return
        if not messagebox.askyesno("Eliminar tarea local", "¿Eliminar únicamente esta tarea guardada? No modifica aplicaciones ni documentos.", parent=win):
            return
        try:
            library.delete(selected[0])
        except (ValueError, OSError):
            failure()
            return
        new()
        refresh()
    actions = ttk.Frame(win)
    actions.pack(fill="x", pady=8)
    for label, command in (("Nueva", new), ("Guardar", save), ("Cargar en Jean", load), ("Eliminar", delete)):
        ttk.Button(actions, text=label, command=command).pack(side="left", padx=3)
    ttk.Label(win, text="Reabrir no restaura aprobaciones ni progreso. No hay sincronización ni ejecución en segundo plano.", wraplength=650).pack(anchor="w")
    refresh()
