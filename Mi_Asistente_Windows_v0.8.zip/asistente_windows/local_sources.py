"""Fuentes de texto elegidas explícitamente; sin red, índices ni ejecución.

Implementación propia. Inspiración conceptual histórica: DigUp (MIT), revisión
local dc2651ad8299160bbe91e972f857e1a1599a8419, y Nova (MIT), revisión local
0bc7e8851790167c13a1be39697f4b136150f73d. No contiene código de esos proyectos.
El llamador debe tratar todo texto devuelto como datos no confiables, no órdenes.
"""
from dataclasses import dataclass
import os
from pathlib import Path
import stat

MAX_FILE_BYTES = 128 * 1024
MAX_EXCERPT_CHARS = 12_000
MAX_RESULTS = 100
ALLOWED_EXTENSIONS = frozenset({".txt", ".md", ".csv"})
_SENSITIVE_EXTENSIONS = frozenset({
    ".env", ".key", ".pem", ".p12", ".pfx", ".crt", ".cer", ".der",
    ".kdbx", ".keystore", ".jks", ".sqlite", ".db", ".exe", ".bat",
    ".cmd", ".ps1", ".py", ".sh", ".lnk", ".url",
})
_SENSITIVE_NAMES = frozenset({
    "credentials", "credential", "password", "passwords", "secrets", "secret",
    "id_rsa", "id_ed25519", "id_ecdsa", "id_dsa", "authorized_keys",
})


@dataclass(frozen=True)
class LocalSource:
    name: str
    text: str
    byte_count: int


@dataclass(frozen=True)
class LineMatch:
    line_number: int
    text: str


def _checked_path(path):
    raw = os.fspath(path)
    if not isinstance(raw, str) or not raw or "\x00" in raw:
        raise ValueError("Selecciona un único archivo de texto local")
    # No UNC/device paths, NTFS alternate streams, or URL imports.
    if raw.startswith(("\\\\", "//")) or "://" in raw:
        raise ValueError("Solo se permiten archivos locales; no rutas de red ni URL")
    candidate = Path(os.path.abspath(raw))
    if ":" in str(candidate)[len(candidate.drive):]:
        raise ValueError("No se permiten flujos alternativos ni rutas especiales")
    name = candidate.name.lower()
    parts = name.split(".")
    if (candidate.suffix.lower() not in ALLOWED_EXTENSIONS
            or any("." + part in _SENSITIVE_EXTENSIONS for part in parts)
            or any(part in _SENSITIVE_NAMES for part in parts)
            or name.startswith(".")):
        raise ValueError("Usa .txt, .md o .csv; no archivos sensibles ni ejecutables")
    return candidate


def _check_components(path):
    """Rechaza enlaces y reparse points, también en directorios ascendientes."""
    for component in (*reversed(path.parents), path):
        info = component.lstat()
        if (stat.S_ISLNK(info.st_mode)
                or getattr(info, "st_file_attributes", 0) & 0x400):
            raise ValueError("No se permiten enlaces simbólicos ni puntos de redirección")
    return info


def _same_file(left, right):
    return (left.st_dev, left.st_ino) == (right.st_dev, right.st_ino)


def _check_regular(info):
    if not stat.S_ISREG(info.st_mode):
        raise ValueError("La fuente debe ser un archivo regular")
    if info.st_size > MAX_FILE_BYTES:
        raise ValueError("El archivo supera el máximo de 128 KiB")


def read_source(path):
    """Lee UN .txt/.md/.csv UTF-8 con máximo físico de 128 KiB + 1 byte.

    Rechaza enlaces/reparse points observables antes y después de abrir. Usa
    O_NOFOLLOW donde existe y comprueba identidad del descriptor. Estas defensas
    no sustituyen el aislamiento frente a otro proceso que modifica directorios
    concurrentemente, especialmente en Windows. No guarda una copia persistente.
    Lanza ValueError por contenido/ruta no admitidos y OSError por fallos de E/S.
    """
    candidate = _checked_path(path)
    before = _check_components(candidate)
    _check_regular(before)
    flags = os.O_RDONLY | getattr(os, "O_BINARY", 0)
    flags |= getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0)
    descriptor = os.open(candidate, flags)
    try:
        opened = os.fstat(descriptor)
        _check_regular(opened)
        if not _same_file(before, opened):
            raise ValueError("El archivo cambió al abrirse; vuelve a seleccionarlo")
        # Unbuffered: do not let read-ahead exceed the explicit bound.
        with os.fdopen(descriptor, "rb", buffering=0, closefd=False) as stream:
            raw = stream.read(MAX_FILE_BYTES + 1)
        after = os.fstat(descriptor)
        final = _check_components(candidate)
        if (not _same_file(opened, final) or len(raw) < opened.st_size
                or (opened.st_size, opened.st_mtime_ns, opened.st_ctime_ns)
                != (after.st_size, after.st_mtime_ns, after.st_ctime_ns)):
            raise ValueError("El archivo cambió durante la lectura; vuelve a seleccionarlo")
    finally:
        os.close(descriptor)
    if len(raw) > MAX_FILE_BYTES:
        raise ValueError("El archivo supera el máximo de 128 KiB")
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeError:
        raise ValueError("El archivo debe estar codificado en UTF-8") from None
    if any(ord(char) < 32 and char not in "\n\r\t" for char in text):
        raise ValueError("El archivo contiene datos binarios o controles no admitidos")
    # Normalized line endings keep search line numbers aligned with Tk's preview.
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    return LocalSource(candidate.name, text, len(raw))


def search_lines(text, query, limit=50):
    """Coincidencia literal sensible a mayúsculas, por líneas (números desde 1).

    No regex, embeddings, comandos ni lectura adicional del disco. Un resultado
    por línea; máximo 100 resultados. La consulta vacía no devuelve todo el texto.
    """
    if not isinstance(text, str) or not isinstance(query, str):
        raise ValueError("La búsqueda requiere texto")
    if type(limit) is not int or not 1 <= limit <= MAX_RESULTS:
        raise ValueError("El límite de resultados debe estar entre 1 y 100")
    if len(text) > MAX_FILE_BYTES or len(query) > 500 or "\n" in query or "\r" in query:
        raise ValueError("Consulta de una sola línea (hasta 500 caracteres)")
    if not query:
        return []
    matches = []
    for number, line in enumerate(text.split("\n"), 1):
        if query in line:
            matches.append(LineMatch(number, line))
            if len(matches) == limit:
                break
    return matches


def prepare_excerpt(text):
    """Valida un extracto explícito sin enviarlo ni truncarlo silenciosamente."""
    if not isinstance(text, str) or not text.strip():
        raise ValueError("Selecciona texto no vacío para preparar un extracto")
    if len(text) > MAX_EXCERPT_CHARS:
        raise ValueError("El extracto supera 12000 caracteres; selecciona una parte menor")
    if any(ord(char) < 32 and char not in "\n\r\t" for char in text):
        raise ValueError("El extracto contiene controles no admitidos")
    return text
