"""Fuente de un solo intento, nunca persistida ni conectada al ejecutor."""
class PendingSource:
    def __init__(self):
        self._text = ""

    def attach(self, text):
        if not isinstance(text, str) or not text.strip() or len(text) > 12000:
            raise ValueError("El extracto debe tener entre 1 y 12000 caracteres")
        self._text = text

    def peek(self):
        return self._text

    def clear(self):
        self._text = ""

    def consume(self):
        text = self._text
        self.clear()
        return text
