"""Ventana opcional de fuentes. Importar este módulo no carga Tk ni abre archivos."""


def open_sources(parent, on_attach):
    """Abre Tk de forma lazy; on_attach(text) prepara UNA fuente, nunca envía.

    El anfitrión debe delimitar ese texto como datos no confiables y esperar el
    envío explícito del usuario. No se guardan rutas, copias ni un índice local.
    """
    import tkinter as tk
    from tkinter import filedialog, messagebox, scrolledtext, ttk
    from local_sources import read_source, search_lines, prepare_excerpt

    win = tk.Toplevel(parent)
    win.title("Jean · Fuentes locales")
    win.geometry("820x720")
    win.minsize(640, 600)
    win.configure(padx=14, pady=14)
    ttk.Label(win, text="Una fuente local, elegida por ti", font=("Segoe UI", 16, "bold")).pack(anchor="w")
    ttk.Label(win, text=(
        "Solo .txt, .md o .csv UTF-8, hasta 128 KiB. Sin enlaces ni archivos sensibles.\n"
        "Vista previa y búsqueda locales: no se envía nada ni se siguen instrucciones del archivo.\n"
        "Preparar un extracto no envía el mensaje. Revisa que no contenga datos privados."
    ), wraplength=760).pack(anchor="w", pady=8)
    selected = [None]
    status = tk.StringVar(value="Ningún archivo seleccionado")
    ttk.Label(win, textvariable=status, wraplength=760).pack(anchor="w", pady=4)
    preview = scrolledtext.ScrolledText(win, wrap="none", height=16, state="disabled", exportselection=False)
    preview.pack(fill="both", expand=True, pady=8)
    search_bar = ttk.Frame(win)
    search_bar.pack(fill="x")
    ttk.Label(search_bar, text="Buscar literal (distingue mayúsculas):").pack(side="left")
    query = tk.StringVar()
    search_entry = ttk.Entry(search_bar, textvariable=query)
    search_entry.pack(side="left", fill="x", expand=True, padx=6)
    results = tk.Listbox(win, height=5, exportselection=False)
    results.pack(fill="x", pady=6)
    matches = []
    search_status = tk.StringVar(value="Hasta 50 líneas por búsqueda; no expresiones regulares")
    ttk.Label(win, textvariable=search_status).pack(anchor="w")

    def replace_preview(text):
        preview.configure(state="normal")
        preview.delete("1.0", "end")
        preview.insert("1.0", text)
        preview.configure(state="disabled")

    def choose():
        path = filedialog.askopenfilename(
            parent=win, title="Seleccionar UN archivo local (UTF-8, hasta 128 KiB)",
            filetypes=[("Texto UTF-8", "*.txt *.md *.csv")])
        if not path:
            return
        # A failed replacement cannot accidentally attach the previous source.
        selected[0] = None
        replace_preview("")
        results.delete(0, "end")
        matches.clear()
        query.set("")
        search_status.set("Hasta 50 líneas por búsqueda; no expresiones regulares")
        status.set("Ningún archivo seleccionado")
        for button in attach_buttons:
            button.configure(state="disabled")
        try:
            source = read_source(path)
        except ValueError as exc:
            messagebox.showerror("Fuente no admitida", str(exc), parent=win)
            return
        except OSError:
            messagebox.showerror("Fuente no disponible", "No se pudo leer el archivo. Revisa permisos y vuelve a seleccionarlo.", parent=win)
            return
        selected[0] = source
        replace_preview(source.text)
        status.set(f"{source.name} · {source.byte_count} bytes · solo en memoria; sin enviar")
        for button in attach_buttons:
            button.configure(state="normal")

    def search(event=None):
        results.delete(0, "end")
        matches.clear()
        if selected[0] is None:
            search_status.set("Selecciona primero un archivo")
            return
        try:
            matches.extend(search_lines(selected[0].text, query.get(), limit=50))
        except ValueError as exc:
            search_status.set(str(exc))
            return
        for match in matches:
            # Full lines remain in preview, avoiding an oversized result widget.
            results.insert("end", f"Línea {match.line_number}: {match.text[:180]}")
        search_status.set(f"{len(matches)} líneas mostradas (máximo 50); selecciona una para verla")

    def show_match(event=None):
        indexes = results.curselection()
        if not indexes or indexes[0] >= len(matches):
            return
        number = matches[indexes[0]].line_number
        preview.tag_remove("sel", "1.0", "end")
        preview.tag_add("sel", f"{number}.0", f"{number}.end")
        preview.see(f"{number}.0")
        preview.focus_set()

    def attach(whole=False):
        if selected[0] is None:
            return
        if whole:
            text = selected[0].text
        else:
            try:
                text = preview.get("sel.first", "sel.last")
            except tk.TclError:
                messagebox.showinfo("Selecciona un extracto", "Selecciona texto en la vista previa o usa «Preparar texto completo».", parent=win)
                return
        try:
            excerpt = prepare_excerpt(text)
        except ValueError as exc:
            messagebox.showerror("Extracto no preparado", str(exc), parent=win)
            return
        kind = "el texto completo" if whole else "la selección"
        if not messagebox.askyesno("Preparar fuente, sin enviar", (
            f"¿Preparar {kind} ({len(excerpt)} caracteres) como fuente del siguiente mensaje?\n\n"
            "El contenido se tratará como datos, no como instrucciones. No se ejecutará ni enviará ahora. "
            "Si luego envías el mensaje, la fuente llegará al proveedor/modelo configurado. "
            "Comprueba antes que no contenga secretos o datos privados."
        ), parent=win):
            return
        on_attach(excerpt)
        win.destroy()

    picker = ttk.Button(win, text="Seleccionar otro archivo…", command=choose)
    picker.pack(anchor="w", pady=8)
    ttk.Button(search_bar, text="Buscar", command=search).pack(side="left")
    search_entry.bind("<Return>", search)
    results.bind("<<ListboxSelect>>", show_match)
    actions = ttk.Frame(win)
    actions.pack(fill="x", pady=6)
    attach_buttons = [
        ttk.Button(actions, text="Preparar selección", command=attach, state="disabled"),
        ttk.Button(actions, text="Preparar texto completo", command=lambda: attach(True), state="disabled"),
    ]
    for button in attach_buttons:
        button.pack(side="left", padx=3)
    ttk.Button(actions, text="Cerrar sin preparar", command=win.destroy).pack(side="right")
    ttk.Label(win, text="Máximo 12000 caracteres por extracto. Sin copia persistente ni indexación de carpetas.", wraplength=760).pack(anchor="w", pady=6)
    return win
