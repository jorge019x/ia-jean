"""Biblioteca local propia de Jean. Nunca almacena ni reproduce acciones."""
import json
import os
from pathlib import Path
import tempfile
import uuid

from task_tools import parse_checkpoints

MAX_BYTES = 512_000


def default_path():
    base = os.environ.get("LOCALAPPDATA")
    return (Path(base) / "Jean" if base else Path.home() / ".jean") / "tasks.json"


def validate_task(row):
    if not isinstance(row, dict) or set(row) != {"id", "title", "goal", "checkpoints"}:
        raise ValueError("Formato de tarea no válido")
    try:
        if str(uuid.UUID(row["id"])) != row["id"]:
            raise ValueError()
    except (ValueError, TypeError, AttributeError):
        raise ValueError("Identificador de tarea no válido") from None
    for field, limit in (("title", 100), ("goal", 8000), ("checkpoints", 8000)):
        value = row[field]
        if not isinstance(value, str) or len(value) > limit or any(ord(c) < 32 and c not in "\n\t" for c in value):
            raise ValueError("Texto de tarea no válido")
    if not row["title"].strip() or not row["goal"].strip() or "\n" in row["title"]:
        raise ValueError("Escribe título y objetivo; título en una sola línea")
    if row["checkpoints"].strip():
        parse_checkpoints(row["checkpoints"])
    return dict(row)


class TaskLibrary:
    """JSON limitado con escritura atómica. Sin historial de acciones ni aprobaciones."""
    def __init__(self, path=None):
        self.path = Path(path) if path is not None else default_path()

    def list_tasks(self):
        try:
            with self.path.open("rb") as stream:
                raw = stream.read(MAX_BYTES + 1)
        except FileNotFoundError:
            return []
        if len(raw) > MAX_BYTES:
            raise ValueError("Biblioteca demasiado grande")
        try:
            data = json.loads(raw)
            if not isinstance(data, dict) or set(data) != {"version", "tasks"} or type(data["version"]) is not int or data["version"] != 1:
                raise ValueError()
            rows = data["tasks"]
            if not isinstance(rows, list) or len(rows) > 30:
                raise ValueError()
            checked = [validate_task(row) for row in rows]
            if len({row["id"] for row in checked}) != len(checked):
                raise ValueError()
            return checked
        except (ValueError, TypeError, KeyError, UnicodeError):
            raise ValueError("Biblioteca dañada o no compatible; no se sobrescribió") from None

    def _write(self, rows):
        raw = json.dumps({"version": 1, "tasks": rows}, ensure_ascii=False, indent=2).encode("utf-8")
        if len(raw) > MAX_BYTES:
            raise ValueError("Biblioteca demasiado grande; acorta las tareas")
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = None
        try:
            with tempfile.NamedTemporaryFile(dir=self.path.parent, prefix=".tasks-", delete=False) as stream:
                temporary = Path(stream.name)
                stream.write(raw)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, self.path)
        finally:
            if temporary is not None:
                temporary.unlink(missing_ok=True)

    def save(self, title, goal, checkpoints="", task_id=None):
        rows = self.list_tasks()
        row = validate_task({"id": task_id or str(uuid.uuid4()), "title": title.strip(),
                             "goal": goal.strip(), "checkpoints": checkpoints.strip()})
        matches = [index for index, item in enumerate(rows) if item["id"] == row["id"]]
        if task_id and not matches:
            raise ValueError("La tarea ya no existe; recarga la biblioteca")
        if matches:
            rows[matches[0]] = row
        elif len(rows) < 30:
            rows.append(row)
        else:
            raise ValueError("Máximo 30 tareas; elimina una antes de guardar")
        self._write(rows)
        return dict(row)

    def delete(self, task_id):
        rows = self.list_tasks()
        remaining = [row for row in rows if row["id"] != task_id]
        if len(rows) == len(remaining):
            raise ValueError("La tarea ya no existe")
        self._write(remaining)
