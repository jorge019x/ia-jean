"""Utilidades propias: lista de hitos y registro mínimo, solo en memoria."""
import json


def parse_checkpoints(text):
    if not isinstance(text, str) or len(text) > 8000:
        raise ValueError("La lista debe ser texto de hasta 8000 caracteres")
    rows = [line.strip() for line in text.splitlines() if line.strip()]
    if not 1 <= len(rows) <= 8 or any(len(row) > 1000 for row in rows):
        raise ValueError("Escribe entre 1 y 8 hitos, uno por línea, hasta 1000 caracteres cada uno")
    return rows


class MinimalJournal:
    """No recibe objetivos, claves, texto escrito, capturas ni metadatos UIA."""
    ACTIONS = frozenset(("click", "move", "scroll", "type_text", "press_key", "open_app",
                         "install_app", "focus_window", "invoke_element", "set_value", "finish"))
    STATUSES = frozenset(("propuesta", "aprobada", "rechazada", "emitida", "hito_confirmado"))

    def __init__(self):
        self.rows = []

    def record(self, step, action, status):
        if type(step) is not int or not 1 <= step <= 100 or action not in self.ACTIONS or status not in self.STATUSES:
            raise ValueError("Evento no válido")
        self.rows.append({"paso": step, "accion": action, "estado": status})
        self.rows = self.rows[-100:]

    def export(self):
        return json.dumps({"version": "0.6", "nota": "Acción emitida no equivale a éxito; sin capturas ni textos. No permite reproducir acciones.",
                           "eventos": list(self.rows)}, ensure_ascii=False, indent=2)
