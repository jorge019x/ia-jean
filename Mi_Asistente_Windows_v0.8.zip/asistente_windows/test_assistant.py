"""Pruebas sin GUI, red ni ejecución real de programas."""
from datetime import datetime
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock
from assistant import AssistantCore


class AssistantCoreTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.folder = Path(self.temp.name)
        self.opener = Mock()
        self.clock = Mock(return_value=datetime(2026, 6, 15, 14, 37, 42))
        self.core = AssistantCore(opener=self.opener, clock=self.clock)

    def assert_reply(self, text):
        reply = self.core.respond(text)
        self.assertIsInstance(reply, str)
        self.assertTrue(reply.strip())
        return reply

    def test_help_returns_text_without_opening_apps(self):
        self.assert_reply('ayuda')
        self.opener.assert_not_called()

    def test_time_uses_injected_clock(self):
        self.assertIn('14:37', self.assert_reply('hora'))
        self.clock.assert_called()
        self.opener.assert_not_called()

    def test_only_fixed_application_keys_are_passed_to_opener(self):
        for command, expected in [('abrir calculadora', 'calculator'), ('abrir bloc de notas', 'notepad'), ('abrir paint', 'paint')]:
            with self.subTest(command=command):
                self.opener.reset_mock()
                self.assert_reply(command)
                self.opener.assert_called_once_with(expected)

    def test_arbitrary_commands_do_not_launch_programs(self):
        for command in ['abrir powershell', 'abrir cmd', 'abrir calculadora & whoami', "python -c print('no ejecutar')"]:
            self.assert_reply(command)
            self.opener.assert_not_called()

    def test_folder_is_initially_unselected(self):
        self.assertIsNone(self.core.folder)
        self.assert_reply('listar archivos')
        self.assertIsNone(self.core.folder)
        self.opener.assert_not_called()

    def test_set_folder_resolves_directory(self):
        child = self.folder / 'subcarpeta'
        child.mkdir()
        self.core.set_folder(child / '..')
        self.assertEqual(self.core.folder, self.folder.resolve())

    def test_constructor_accepts_a_selected_folder(self):
        core = AssistantCore(folder=self.folder, opener=self.opener, clock=self.clock)
        self.assertEqual(core.folder, self.folder.resolve())

    def test_invalid_folder_is_rejected(self):
        regular_file = self.folder / 'archivo.txt'
        regular_file.write_text('contenido', encoding='utf-8')
        self.core.set_folder(self.folder)
        for invalid in (regular_file, self.folder / 'inexistente'):
            with self.assertRaises((ValueError, OSError)):
                self.core.set_folder(invalid)
            self.assertEqual(self.core.folder, self.folder.resolve())

    def test_chat_cannot_select_a_folder(self):
        for command in [f'seleccionar carpeta {self.folder}', f'carpeta {self.folder}', f'listar archivos {self.folder}']:
            self.assert_reply(command)
            self.assertIsNone(self.core.folder)
        self.opener.assert_not_called()

    def test_listing_contains_names_but_not_contents_or_descendants(self):
        (self.folder / 'nota_publica.txt').write_text('CONTENIDO_SECRETO_7dc9', encoding='utf-8')
        nested = self.folder / 'carpeta_visible'
        nested.mkdir()
        (nested / 'descendiente_oculto.txt').write_text('privado', encoding='utf-8')
        self.core.set_folder(self.folder)
        reply = self.assert_reply('listar archivos')
        self.assertIn('nota_publica.txt', reply)
        self.assertIn('carpeta_visible', reply)
        self.assertNotIn('CONTENIDO_SECRETO_7dc9', reply)
        self.assertNotIn('descendiente_oculto.txt', reply)
        self.opener.assert_not_called()

    def test_listing_is_limited_to_100_entries(self):
        names = [f'entrada_{number:03d}.txt' for number in range(125)]
        for name in names:
            (self.folder / name).touch()
        self.core.set_folder(self.folder)
        reply = self.assert_reply('listar archivos')
        listed = sum(name in reply for name in names)
        self.assertEqual(listed, 100)

    def test_empty_folder_returns_text(self):
        self.core.set_folder(self.folder)
        self.assert_reply('listar archivos')
        self.opener.assert_not_called()


if __name__ == '__main__':
    unittest.main()
