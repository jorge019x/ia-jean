"""Pruebas de v0.3: catálogo simulado y perfiles, sin solicitudes reales."""
import io
import json
import unittest
from unittest.mock import Mock, patch
import urllib.error

import models


class CatalogTests(unittest.TestCase):
    def settings(self, provider, model=""):
        return {"provider": provider, "base_url": models.PROVIDERS[provider][0] or "https://example.test/v1", "model": model}

    def transport(self, data=None, raw=None):
        opener = Mock()
        opener.open.return_value = io.BytesIO(raw if raw is not None else json.dumps(data).encode())
        return opener

    def test_all_catalog_protocols(self):
        for provider in models.PROVIDERS:
            with self.subTest(provider=provider):
                if provider == "Google Gemini":
                    data = {"models": [{"name": "models/my-model", "supportedGenerationMethods": ["generateContent"]}, {"name": "models/embedding", "supportedGenerationMethods": ["embedContent"]}], "nextPageToken": "ignored"}
                elif provider == "Ollama local":
                    data = {"models": [{"name": "my-model"}]}
                else:
                    data = {"data": [{"id": "my-model"}], "has_more": True}
                opener = self.transport(data)
                settings = self.settings(provider)
                self.assertEqual(models.list_models(settings, "test-key", opener), ["my-model"])
                opener.open.assert_called_once()
                req = opener.open.call_args.args[0]
                self.assertEqual(req.method, "GET")
                self.assertIsNone(req.data)
                self.assertEqual(req.full_url, settings["base_url"] + ("/api/tags" if provider == "Ollama local" else "/models"))
                self.assertNotIn("test-key", req.full_url)
                headers = {k.lower(): v for k, v in req.header_items()}
                if provider == "Anthropic":
                    self.assertEqual(headers["x-api-key"], "test-key")
                    self.assertEqual(headers["anthropic-version"], "2023-06-01")
                elif provider == "Google Gemini":
                    self.assertEqual(headers["x-goog-api-key"], "test-key")
                elif provider != "Ollama local":
                    self.assertEqual(headers["authorization"], "Bearer test-key")
                else:
                    self.assertNotIn("authorization", headers)

    def test_catalog_limit_sorted_dedup_and_invalid_ids(self):
        rows = [{"id": "z"}, {"id": "z"}, {"id": "bad\nvalue"}] + [{"id": f"model-{n:04}"} for n in range(505)]
        result = models.list_models(self.settings("OpenAI"), "dummy", self.transport({"data": rows}))
        self.assertEqual(len(result), 500)
        self.assertEqual(result, sorted(set(result)))
        self.assertNotIn("bad\nvalue", result)

    def test_catalog_malformed_and_size_limits(self):
        for raw in [b"not-json", b"{}", b'{"data":{}}', b'{"data":[null]}', b"x" * (models.MAX_RESPONSE + 1)]:
            with self.subTest(raw_length=len(raw)), self.assertRaises(ValueError):
                models.list_models(self.settings("OpenAI"), "dummy", self.transport(raw=raw))

    def test_errors_no_secrets_no_retry(self):
        for error in [urllib.error.HTTPError("https://example.test", 401, "secret-marker", {}, io.BytesIO(b"secret-marker")), urllib.error.URLError("secret-marker"), TimeoutError("secret-marker")]:
            opener = Mock()
            opener.open.side_effect = error
            with self.assertRaises(ValueError) as caught:
                models.list_models(self.settings("DeepSeek"), "secret-marker", opener)
            self.assertNotIn("secret-marker", str(caught.exception))
            opener.open.assert_called_once()

    def test_catalog_validation_before_network(self):
        opener = Mock()
        settings = self.settings("DeepSeek")
        with self.assertRaises(ValueError):
            models.list_models(settings, "", opener)
        settings["base_url"] = "http://example.test"
        with self.assertRaises(ValueError):
            models.list_models(settings, "dummy", opener)
        opener.open.assert_not_called()

    def test_transport_protection(self):
        opener = self.transport({"data": []})
        with patch.object(models.urllib.request, "build_opener", return_value=opener) as build:
            self.assertEqual(models.list_models(self.settings("DeepSeek"), "dummy"), [])
        self.assertEqual(build.call_args.args[0].proxies, {})
        self.assertIsNone(build.call_args.args[1].redirect_request(None, None, 302, "", {}, "https://elsewhere.test"))

    def test_deepseek_profile_and_free_model(self):
        self.assertEqual(models.PROVIDERS["DeepSeek"], ("https://api.deepseek.com", "DEEPSEEK_API_KEY"))
        settings = self.settings("DeepSeek", "future-model-2099")
        self.assertEqual(models.validate_settings(**settings), settings)
        with patch.dict(models.os.environ, {"DEEPSEEK_API_KEY": "dummy"}, clear=True):
            self.assertEqual(models.resolve_key(settings), "dummy")

    def test_suggestions_are_optional_and_valid(self):
        self.assertEqual(set(models.PROVIDERS), set(models.PROVIDER_LABELS))
        self.assertEqual(len(set(models.PROVIDER_LABELS.values())), len(models.PROVIDERS))
        for provider, suggestions in models.MODEL_SUGGESTIONS.items():
            for model in suggestions:
                settings = self.settings(provider, model)
                self.assertEqual(models.validate_settings(**settings), settings)


if __name__ == "__main__":
    unittest.main()
