"""Pruebas aisladas: sin red, ventanas Tk, dependencias gráficas ni Windows."""
import base64
import io
import json
import sys
import unittest
from pathlib import Path
from unittest.mock import Mock, patch
import urllib.error

# Permite tanto discovery como ejecución directa desde la raíz del proyecto.
sys.path.insert(0, str(Path(__file__).resolve().parent))
import computer_control as control
import control_ui
from models import PROVIDERS


ACTION = {"action": "click", "reason": "Elegir el botón", "x": 12, "y": 34}
KEY = "test-key-not-a-real-secret"
IMAGE = b"synthetic-png-bytes"


def settings(provider="OpenAI"):
    return {"provider": provider, "base_url": PROVIDERS[provider][0] or "https://compatible.example/v1", "model": "vision-test"}


def response_for(provider, action=None):
    action = dict(ACTION if action is None else action)
    if provider == "Anthropic":
        return {"content": [{"type": "tool_use", "name": "propose_action", "input": action}]}
    if provider == "Google Gemini":
        return {"candidates": [{"content": {"parts": [{"functionCall": {"name": "propose_action", "args": action}}]}}]}
    return {"choices": [{"message": {"tool_calls": [{"type": "function", "function": {"name": "propose_action", "arguments": json.dumps(action)}}]}}]}


class FakeResponse(io.BytesIO):
    pass


class FakeTransport:
    def __init__(self, data=None, raw=None, error=None):
        self.raw = json.dumps(data).encode() if raw is None else raw
        self.error = error
        self.requests = []

    def open(self, request, timeout):
        self.requests.append((request, timeout))
        if self.error:
            raise self.error
        return FakeResponse(self.raw)


class TransportTests(unittest.TestCase):
    def setUp(self):
        # Un fallo en la inyección nunca debe acabar en una petición real.
        guard = patch.object(control.urllib.request, "build_opener", side_effect=AssertionError("Red real prohibida"))
        guard.start()
        self.addCleanup(guard.stop)

    def propose(self, provider="OpenAI", data=None, raw=None, error=None, history=None, config=None):
        transport = FakeTransport(response_for(provider) if data is None else data, raw, error)
        result = control.propose_action("Abrir una nota", config or settings(provider), KEY, IMAGE, history or [], opener=transport)
        request, timeout = transport.requests[0]
        self.assertEqual(timeout, 60)
        self.assertEqual(request.method, "POST")
        self.assertEqual(request.get_header("Content-type"), "application/json")
        self.assertEqual(len(transport.requests), 1)
        return result, request, json.loads(request.data)

    def test_openai_and_compatible_vision_and_forced_single_tool(self):
        for provider in ("OpenAI", "Compatible OpenAI"):
            with self.subTest(provider=provider):
                result, request, body = self.propose(provider)
                self.assertEqual(result, ACTION)
                self.assertEqual(request.full_url, settings(provider)["base_url"] + "/chat/completions")
                self.assertEqual(request.get_header("Authorization"), "Bearer " + KEY)
                self.assertEqual(body["model"], "vision-test")
                self.assertEqual(body["messages"][0], {"role": "system", "content": control.INSTRUCTION})
                parts = body["messages"][1]["content"]
                self.assertIn("Abrir una nota", parts[0]["text"])
                self.assertEqual(parts[1]["image_url"]["url"], "data:image/png;base64," + base64.b64encode(IMAGE).decode())
                self.assertEqual(body["tools"][0]["function"]["parameters"], control.PARAMS)
                self.assertEqual(body["tool_choice"], {"type": "function", "function": {"name": "propose_action"}})
                self.assertIs(body["parallel_tool_calls"], False)

    def test_claude_vision_and_tool_calling(self):
        result, request, body = self.propose("Anthropic")
        self.assertEqual(result, ACTION)
        self.assertEqual(request.full_url, "https://api.anthropic.com/v1/messages")
        self.assertEqual(request.get_header("X-api-key"), KEY)
        self.assertEqual(request.get_header("Anthropic-version"), "2023-06-01")
        self.assertEqual(body["system"], control.INSTRUCTION)
        self.assertEqual(body["max_tokens"], 1024)
        source = body["messages"][0]["content"][0]["source"]
        self.assertEqual(source, {"type": "base64", "media_type": "image/png", "data": base64.b64encode(IMAGE).decode()})
        self.assertEqual(body["tools"][0]["input_schema"], control.PARAMS)
        self.assertEqual(body["tool_choice"], {"type": "tool", "name": "propose_action"})

    def test_gemini_vision_and_function_calling(self):
        config = settings("Google Gemini")
        config["model"] = "models/gemini-test"
        result, request, body = self.propose("Google Gemini", config=config)
        self.assertEqual(result, ACTION)
        self.assertEqual(request.full_url, config["base_url"] + "/models/gemini-test:generateContent")
        self.assertEqual(request.get_header("X-goog-api-key"), KEY)
        self.assertNotIn(KEY, request.full_url)
        self.assertEqual(body["systemInstruction"]["parts"][0]["text"], control.INSTRUCTION)
        self.assertEqual(body["contents"][0]["parts"][1]["inlineData"], {"mimeType": "image/png", "data": base64.b64encode(IMAGE).decode()})
        schema = body["tools"][0]["functionDeclarations"][0]["parameters"]
        self.assertEqual(schema, {key: value for key, value in control.PARAMS.items() if key != "additionalProperties"})
        self.assertNotIn("additionalProperties", schema)  # Gemini admite un subconjunto de JSON Schema.
        self.assertEqual(body["toolConfig"]["functionCallingConfig"], {"mode": "ANY", "allowedFunctionNames": ["propose_action"]})

    def test_history_is_data_limited_to_last_twelve(self):
        history = [{"result": "resultado-%02d" % n} for n in range(20)]
        for provider in control.VISION_PROVIDERS:
            with self.subTest(provider=provider):
                _, _, body = self.propose(provider, history=history)
                text = json.dumps(body, ensure_ascii=False)
                self.assertNotIn("resultado-07", text)
                self.assertIn("resultado-08", text)
                self.assertIn("resultado-19", text)

    def test_text_only_providers_rejected_without_transport(self):
        for provider in ("DeepSeek", "Ollama local"):
            transport = FakeTransport({})
            with self.subTest(provider=provider), self.assertRaisesRegex(ValueError, "control requiere"):
                control.propose_action("objetivo", settings(provider), KEY, IMAGE, [], transport)
            self.assertEqual(transport.requests, [])

    def test_invalid_goal_or_key_never_sends_request(self):
        for goal, key in (("", KEY), ("x" * 8001, KEY), (None, KEY), ("ok", ""), ("ok", "secret\nheader")):
            transport = FakeTransport({})
            with self.subTest(goal_type=type(goal), key_valid=key == KEY), self.assertRaises(ValueError):
                control.propose_action(goal, settings(), key, IMAGE, [], transport)
            self.assertEqual(transport.requests, [])

    def test_http_error_does_not_disclose_body_url_or_key(self):
        error = urllib.error.HTTPError("https://example.test/" + KEY, 401, KEY, {}, io.BytesIO(KEY.encode()))
        with self.assertRaises(ValueError) as caught:
            self.propose(error=error)
        self.assertIn("HTTP 401", str(caught.exception))
        self.assertNotIn(KEY, str(caught.exception))
        self.assertTrue(error.fp.closed)
        self.assertTrue(caught.exception.__suppress_context__)

    def test_connection_errors_are_sanitized_without_retry(self):
        for error in (urllib.error.URLError(KEY), OSError(KEY), TimeoutError(KEY)):
            transport = FakeTransport(error=error)
            with self.subTest(error=type(error)), self.assertRaises(ValueError) as caught:
                control.propose_action("objetivo", settings(), KEY, IMAGE, [], transport)
            self.assertNotIn(KEY, str(caught.exception))
            self.assertIn("No se reintentó", str(caught.exception))
            self.assertEqual(len(transport.requests), 1)
            self.assertTrue(caught.exception.__suppress_context__)

    def test_malformed_response_does_not_disclose_content(self):
        for provider in control.VISION_PROVIDERS:
            for raw in (KEY.encode(), b"\xff", json.dumps({"error": KEY}).encode(), b"[]", b"null"):
                with self.subTest(provider=provider, raw_type=raw[:1]), self.assertRaises(ValueError) as caught:
                    self.propose(provider, raw=raw)
                self.assertNotIn(KEY, str(caught.exception))

    def test_oversized_response_rejected(self):
        with self.assertRaisesRegex(ValueError, "demasiado grande"):
            self.propose(raw=b"x" * 262145)

    def test_no_multiple_wrong_or_non_object_tools(self):
        for provider in control.VISION_PROVIDERS:
            for variant in ("none", "multiple", "wrong", "nonobject"):
                body = response_for(provider)
                if provider == "Anthropic":
                    calls = body["content"]
                    call = calls[0]
                    args_key = "input"
                elif provider == "Google Gemini":
                    calls = body["candidates"][0]["content"]["parts"]
                    call = calls[0]["functionCall"]
                    args_key = "args"
                else:
                    calls = body["choices"][0]["message"]["tool_calls"]
                    call = calls[0]["function"]
                    args_key = "arguments"
                if variant == "none":
                    calls.clear()
                elif variant == "multiple":
                    calls.append(calls[0])
                elif variant == "wrong":
                    call["name"] = "execute_shell"
                else:
                    call[args_key] = "[]" if args_key == "arguments" else []
                with self.subTest(provider=provider, variant=variant), self.assertRaises(ValueError):
                    self.propose(provider, data=body)


class ActionValidationTests(unittest.TestCase):
    def validate(self, name, **params):
        return control.validate_action({"action": name, "reason": "Revisión humana", **params}, 100, 80)

    def test_all_supported_actions_and_catalog_entries(self):
        cases = [("click", {"x": 0, "y": 0}), ("move", {"x": 99, "y": 79}), ("scroll", {"amount": -10}), ("scroll", {"amount": 10}), ("type_text", {"text": "Hola, español 日本語 😀"}), ("finish", {})]
        cases += [("focus_window", {"window_id": "window_1"}), ("invoke_element", {"element_id": "element-1"}), ("set_value", {"element_id": "edit_1", "text": "Español 日本語"})]
        cases += [("press_key", {"key": key}) for key in ("enter", "tab", "escape", "backspace", "left", "right", "up", "down", "space")]
        cases += [("open_app", {"app": app}) for app in ("notepad", "calculator", "paint")]
        cases += [("install_app", {"package": package}) for package in control.INSTALL_APPS]
        for name, params in cases:
            with self.subTest(name=name, params=params):
                self.assertEqual(self.validate(name, **params)["action"], name)

    def test_returns_a_copy(self):
        self.assertEqual(control.validate_action(ACTION, 100, 80), ACTION)
        self.assertIsNot(control.validate_action(ACTION, 100, 80), ACTION)

    def test_coordinates_exact_integers_inside_capture(self):
        for name in ("click", "move"):
            for x, y in ((-1, 0), (0, -1), (100, 0), (0, 80), (True, 1), (1, False), (1.0, 2), ("1", 2), (None, 0)):
                with self.subTest(name=name, x=x, y=y), self.assertRaises(ValueError):
                    self.validate(name, x=x, y=y)

    def test_scroll_limits_and_type(self):
        for amount in (-11, 11, True, 1.0, "2", None):
            with self.subTest(amount=amount), self.assertRaises(ValueError):
                self.validate("scroll", amount=amount)

    def test_text_requires_nonempty_single_line_and_length_limit(self):
        self.validate("type_text", text="a" * 500)
        for text in ("", "a" * 501, "line\nbreak", "line\rbreak", "tab\tstop", "\x00", "\x1b", "\x7f", 42, None):
            with self.subTest(text_type=type(text), length=len(text) if isinstance(text, str) else None), self.assertRaises(ValueError):
                self.validate("type_text", text=text)

    def test_uia_ids_must_be_nonempty_opaque_tokens(self):
        for action, field in (("focus_window", "window_id"), ("invoke_element", "element_id"), ("set_value", "element_id")):
            for value in ("", "a" * 101, "handle:42", "../edit", "id with spaces", "\n", 42, None, [], {}):
                params = {field: value}
                if action == "set_value":
                    params["text"] = "Hola"
                with self.subTest(action=action, value=value), self.assertRaises(ValueError):
                    self.validate(action, **params)

    def test_set_value_has_same_single_line_text_boundary_as_typing(self):
        self.validate("set_value", element_id="edit_1", text="a" * 500)
        for text in ("", "a" * 501, "line\nbreak", "tab\tstop", "\x00", "\x7f", 42, None):
            with self.subTest(text=text), self.assertRaises(ValueError):
                self.validate("set_value", element_id="edit_1", text=text)

    def test_keys_apps_and_packages_are_allowlisted(self):
        for name, parameter, values in (("press_key", "key", ("win", "ctrl+r", "Return", "f1", "")), ("open_app", "app", ("powershell", "cmd", "https://example.test", "")), ("install_app", "package", ("unknown", "7zip.7zip --silent", "", None, [], {}))):
            for value in values:
                with self.subTest(name=name, value=value), self.assertRaises(ValueError):
                    self.validate(name, **{parameter: value})

    def test_structure_reason_and_extra_fields_rejected(self):
        invalid = [None, [], "click", {}, {"action": "shell", "reason": "no"}, {"action": "finish", "reason": ""}, {"action": "finish", "reason": "a" * 1001}, {"action": "finish", "reason": 1}, {"action": "click", "reason": "no", "x": 1}, {"action": "finish", "reason": "no", "text": "extra"}, {**ACTION, "command": "cmd"}]
        for action in invalid:
            with self.subTest(action_type=type(action)), self.assertRaises(ValueError):
                control.validate_action(action, 100, 80)


class FakeStop:
    def __init__(self):
        self.stopped = False
        self.waits = []
        self.on_wait = None

    def set(self):
        self.stopped = True

    def is_set(self):
        return self.stopped

    def wait(self, seconds):
        self.waits.append(seconds)
        if self.on_wait:
            self.on_wait()
        return self.stopped


class ControlLoopTests(unittest.TestCase):
    def setUp(self):
        self.desktop = Mock()
        self.desktop.capture.return_value = (IMAGE, 100, 80)
        self.desktop.observe.return_value = None
        self.desktop.execute.return_value = "Acción emitida"
        self.approve = Mock(return_value=True)
        self.planner = Mock(return_value=dict(ACTION))
        self.stop = FakeStop()
        self.report = Mock()

    def run_loop(self, **kwargs):
        return control.run_control("objetivo", settings(), KEY, self.desktop, self.approve, self.stop, self.report, planner=self.planner, **kwargs)

    def assert_no_execution(self):
        self.desktop.execute.assert_not_called()
        self.report.assert_not_called()

    def test_rejected_proposal_never_executes_or_continues(self):
        self.approve.return_value = False
        self.assertIn("rechazada", self.run_loop())
        self.assert_no_execution()
        self.planner.assert_called_once()
        self.approve.assert_called_once_with(ACTION, 1)

    def test_execution_occurs_strictly_after_explicit_approval(self):
        order = []
        self.desktop.capture.side_effect = lambda: (order.append("capture") or (IMAGE, 100, 80))
        self.planner.side_effect = lambda *args: (order.append("propose") or dict(ACTION))
        self.approve.side_effect = lambda *args: (order.append("approve") or True)
        self.desktop.execute.side_effect = lambda action: (order.append("execute") or "emitida")
        self.run_loop(max_steps=1)
        self.assertEqual(order, ["capture", "propose", "approve", "execute"])

    def test_stop_before_capture(self):
        self.stop.set()
        self.assertEqual(self.run_loop(), "Detenido")
        self.desktop.capture.assert_not_called()
        self.planner.assert_not_called()
        self.approve.assert_not_called()
        self.assert_no_execution()

    def test_stop_after_capture_before_proposal(self):
        def capture():
            self.stop.set()
            return IMAGE, 100, 80
        self.desktop.capture.side_effect = capture
        self.assertEqual(self.run_loop(), "Detenido")
        self.planner.assert_not_called()
        self.approve.assert_not_called()
        self.assert_no_execution()

    def test_stop_during_observation_prevents_proposal_and_execution(self):
        def observe():
            self.stop.set()
            return {"available": False}
        self.desktop.observe.side_effect = observe
        self.assertEqual(self.run_loop(), "Detenido")
        self.desktop.capture.assert_called_once()
        self.desktop.observe.assert_called_once()
        self.planner.assert_not_called()
        self.approve.assert_not_called()
        self.assert_no_execution()

    def test_stop_after_proposal_before_approval(self):
        def planner(*args):
            self.stop.set()
            return dict(ACTION)
        self.planner.side_effect = planner
        self.assertEqual(self.run_loop(), "Detenido")
        self.approve.assert_not_called()
        self.assert_no_execution()

    def test_stop_during_approval_prevents_even_approved_execution(self):
        def approve(*args):
            self.stop.set()
            return True
        self.approve.side_effect = approve
        self.assertIn("Detenido", self.run_loop())
        self.assert_no_execution()

    def test_stop_with_rejection_during_approval_never_executes(self):
        def approve(*args):
            self.stop.set()
            return False
        self.approve.side_effect = approve
        self.run_loop()
        self.assert_no_execution()
        self.desktop.capture.assert_called_once()

    def test_stop_after_execution_prevents_next_capture(self):
        self.stop.on_wait = self.stop.set
        self.assertEqual(self.run_loop(), "Detenido")
        self.desktop.execute.assert_called_once_with(ACTION)
        self.desktop.capture.assert_called_once()
        self.assertEqual(self.stop.waits, [0.8])

    def test_invalid_action_cannot_reach_approval(self):
        self.planner.return_value = {**ACTION, "x": 100}
        with self.assertRaises(ValueError):
            self.run_loop()
        self.approve.assert_not_called()
        self.assert_no_execution()

    def test_planner_failure_does_not_approve_execute_or_retry(self):
        self.planner.side_effect = ValueError("fallo seguro")
        with self.assertRaisesRegex(ValueError, "fallo seguro"):
            self.run_loop()
        self.approve.assert_not_called()
        self.planner.assert_called_once()
        self.assert_no_execution()

    def test_execution_failure_is_not_retried(self):
        self.desktop.execute.side_effect = ValueError("fallo de escritorio")
        with self.assertRaisesRegex(ValueError, "fallo de escritorio"):
            self.run_loop()
        self.desktop.execute.assert_called_once_with(ACTION)
        self.planner.assert_called_once()
        self.report.assert_not_called()

    def test_every_step_needs_new_approval_and_receives_history(self):
        history_snapshots = []
        def planner(goal, config, key, image, history):
            history_snapshots.append(list(history))
            return dict(ACTION)
        self.planner.side_effect = planner
        self.approve.side_effect = [True, False]
        self.assertIn("rechazada", self.run_loop())
        self.assertEqual(self.approve.call_count, 2)
        self.desktop.execute.assert_called_once_with(ACTION)
        self.assertEqual(history_snapshots, [[], [{"action": ACTION, "result": "Acción emitida"}]])
        self.report.assert_called_once_with("Paso 1: Acción emitida")

    def test_default_twelve_step_limit(self):
        self.desktop.capture.side_effect = [(IMAGE + bytes([n]), 100, 80) for n in range(12)]
        self.assertIn("Límite de 12 pasos", self.run_loop())
        self.assertEqual(self.desktop.capture.call_count, 12)
        self.assertEqual(self.planner.call_count, 12)
        self.assertEqual(self.desktop.execute.call_count, 12)
        self.assertEqual(self.approve.call_args_list[-1].args, (ACTION, 12))

    def test_third_identical_capture_and_action_stops_before_approval(self):
        self.planner.side_effect = [{**ACTION, "reason": "Intento %d" % n} for n in range(3)]
        self.assertIn("Sin progreso visible", self.run_loop())
        self.assertEqual(self.desktop.capture.call_count, 3)
        self.assertEqual(self.desktop.observe.call_count, 3)
        self.assertEqual(self.planner.call_count, 3)
        self.assertEqual(self.approve.call_count, 2)
        self.assertEqual(self.desktop.execute.call_count, 2)
        self.assertEqual(self.report.call_count, 2)

    def test_changed_action_resets_no_progress_counter(self):
        actions = [ACTION, ACTION, {**ACTION, "x": 13}, ACTION, ACTION]
        self.planner.side_effect = actions
        self.assertIn("Límite de 5 pasos", self.run_loop(max_steps=5))
        self.assertEqual(self.desktop.execute.call_count, 5)
        self.assertEqual(self.approve.call_count, 5)

    def test_custom_limit_stops_execution(self):
        self.assertIn("Límite", self.run_loop(max_steps=2))
        self.assertEqual(self.desktop.execute.call_count, 2)
        self.assertEqual(self.approve.call_count, 2)

    def test_install_ends_loop_without_waiting_or_claiming_success(self):
        action = {"action": "install_app", "reason": "Instalar VLC", "package": "VideoLAN.VLC"}
        self.planner.return_value = action
        self.desktop.execute.return_value = "Instalador iniciado; NO se ha comprobado instalación."
        result = self.run_loop()
        self.assertIn("NO se ha comprobado", result)
        self.assertIn("Bucle finalizado", result)
        self.desktop.execute.assert_called_once_with(action)
        self.approve.assert_called_once_with(action, 1)
        self.planner.assert_called_once()
        self.assertEqual(self.stop.waits, [])

    def test_finish_neither_approves_nor_executes(self):
        self.planner.return_value = {"action": "finish", "reason": "Objetivo terminado según la imagen"}
        result = self.run_loop()
        self.assertIn("no verificación independiente", result)
        self.approve.assert_not_called()
        self.assert_no_execution()
        self.assertEqual(self.stop.waits, [])


class PlatformTests(unittest.TestCase):
    def test_linux_desktop_rejected_without_importing_pyautogui(self):
        with patch.object(control.sys, "platform", "linux"), patch.dict(sys.modules, {"pyautogui": None}):
            with self.assertRaisesRegex(ValueError, "solo en Windows"):
                control.WindowsDesktop()

    def test_control_ui_import_does_not_require_tk_windows_or_display(self):
        # tkinter se importa dentro de open_control, nunca al importar el módulo.
        with patch.dict(sys.modules, {"tkinter": None, "pyautogui": None}):
            import importlib
            self.assertTrue(callable(importlib.reload(control_ui).open_control))


if __name__ == "__main__":
    unittest.main()
