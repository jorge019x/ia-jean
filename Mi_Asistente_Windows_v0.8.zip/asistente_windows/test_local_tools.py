import tempfile
from pathlib import Path
import unittest
from unittest.mock import patch
from assistant import AssistantCore
from diagnostics import local_diagnostics


class LocalToolsTests(unittest.TestCase):
    def test_search_requires_explicit_folder(self):
        self.assertIn("elige una carpeta", AssistantCore().respond("buscar archivos informe"))

    def test_search_only_names_never_contents_or_subfolders(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "Informe.txt").write_text("private content")
            (root / "otro.txt").write_text("Informe hidden")
            (root / "sub").mkdir()
            (root / "sub" / "InformeSecreto.txt").touch()
            core = AssistantCore(root)
            with patch.object(Path, "read_text", side_effect=AssertionError("No contenidos")):
                result = core.respond("buscar   archivos informe")
            self.assertIn('"Informe.txt"', result)
            for hidden in ("private content", "otro.txt", "InformeSecreto"):
                self.assertNotIn(hidden, result)

    def test_search_is_literal_not_path_selection(self):
        with tempfile.TemporaryDirectory() as tmp:
            core = AssistantCore(tmp)
            self.assertIn("No se encontraron", core.search_files("../../"))
            self.assertEqual(core.folder, Path(tmp).resolve())

    def test_invalid_search(self):
        with tempfile.TemporaryDirectory() as tmp:
            core = AssistantCore(tmp)
            for query in (None, "", "x" * 101, "a\nb"):
                self.assertIn("1 a 100", core.search_files(query))

    def test_search_caps_matches(self):
        with tempfile.TemporaryDirectory() as tmp:
            for i in range(102):
                (Path(tmp) / f"match{i}.txt").touch()
            result = AssistantCore(tmp).search_files("match")
            self.assertEqual(result.count('.txt"'), 100)
            self.assertIn("Límite", result)

    def test_search_permission_error(self):
        with tempfile.TemporaryDirectory() as tmp:
            core = AssistantCore(tmp)
            with patch("assistant.os.scandir", side_effect=PermissionError):
                self.assertIn("No se pudo", core.search_files("x"))

    def test_diagnostics_no_optional_imports_or_network(self):
        with patch("diagnostics.importlib.util.find_spec", return_value=None), patch("diagnostics.sys.platform", "linux"):
            result = local_diagnostics()
            self.assertIn("no; control real", result)
            self.assertIn("no detectable", result)
            self.assertIn("Sin red", result)

    def test_diagnostics_spec_failure_is_safe(self):
        with patch("diagnostics.importlib.util.find_spec", side_effect=ValueError("internal path")):
            result = AssistantCore().respond("diagnóstico")
            self.assertIn("no detectable", result)
            self.assertNotIn("internal path", result)


if __name__ == '__main__':
    unittest.main()
