"""Pruebas sin red de conectores y configuración; solo biblioteca estándar."""
import io
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock, patch
import urllib.error
import urllib.request

import models


class ModelTests(unittest.TestCase):
    def settings(self, provider="OpenAI", base=None, model="example-model"):
        return models.validate_settings(provider, base if base is not None else models.PROVIDERS[provider][0], model)

    def transport(self, data=None, raw=None):
        response = Mock()
        response.read.return_value = raw if raw is not None else json.dumps(data).encode()
        response.__enter__ = Mock(return_value=response)
        response.__exit__ = Mock(return_value=False)
        opener = Mock()
        opener.open.return_value = response
        return opener, response

    def test_requests_and_parse_all_providers(self):
        cases = [
            ("OpenAI", None, {"choices": [{"message": {"content": "respuesta"}}]}, "/chat/completions", "authorization"),
            ("DeepSeek", None, {"choices": [{"message": {"content": "respuesta"}}]}, "/chat/completions", "authorization"),
            ("Compatible OpenAI", "https://example.test/v1", {"choices": [{"message": {"content": "respuesta"}}]}, "/chat/completions", "authorization"),
            ("Anthropic", None, {"content": [{"type": "thinking", "text": "oculto"}, {"type": "text", "text": "respuesta"}]}, "/messages", "x-api-key"),
            ("Google Gemini", None, {"candidates": [{"content": {"parts": [{"thought": True, "text": "oculto"}, {"text": "respuesta"}]}}]}, ":generateContent", "x-goog-api-key"),
            ("Ollama local", None, {"message": {"content": "respuesta"}}, "/api/chat", None),
        ]
        for provider, base, data, suffix, auth in cases:
            with self.subTest(provider=provider):
                settings = self.settings(provider, base)
                opener, response = self.transport(data)
                self.assertEqual(models.ask_model("Mensaje actual", settings, "dummy-test-key", opener), "respuesta")
                opener.open.assert_called_once()
                request = opener.open.call_args.args[0]
                self.assertEqual(opener.open.call_args.kwargs, {"timeout": 60})
                self.assertEqual(request.method, "POST")
                self.assertTrue(request.full_url.endswith(suffix))
                self.assertNotIn("dummy-test-key", request.full_url)
                headers = {k.lower(): v for k, v in request.header_items()}
                if auth:
                    self.assertEqual(headers[auth], "Bearer dummy-test-key" if auth == "authorization" else "dummy-test-key")
                else:
                    self.assertNotIn("authorization", headers)
                payload = json.loads(request.data)
                self.assertNotIn("tools", payload)
                self.assertNotIn("functions", payload)
                if provider == "Google Gemini":
                    self.assertEqual(payload["contents"], [{"role": "user", "parts": [{"text": "Mensaje actual"}]}])
                    self.assertEqual(payload["generationConfig"]["maxOutputTokens"], 512)
                else:
                    self.assertEqual(payload["messages"][-1], {"role": "user", "content": "Mensaje actual"})
                    self.assertEqual(len(payload["messages"]), 1 if provider == "Anthropic" else 2)
                if provider == "DeepSeek":
                    self.assertEqual(request.full_url, "https://api.deepseek.com/chat/completions")
                    self.assertEqual(payload["max_tokens"], 1024)
                    self.assertEqual(settings["base_url"], models.PROVIDERS["DeepSeek"][0])
                if provider == "Anthropic":
                    self.assertEqual(headers["anthropic-version"], "2023-06-01")
                    self.assertEqual(payload["max_tokens"], 512)
                if provider == "Ollama local":
                    self.assertFalse(payload["stream"])
                response.read.assert_called_once_with(models.MAX_RESPONSE + 1)

    def test_gemini_model_encoded_and_prefix_removed(self):
        opener, _ = self.transport({"candidates": [{"content": {"parts": [{"text": "ok"}]}}]})
        models.ask_model("hola", self.settings("Google Gemini", model="models/team/model"), "dummy", opener)
        self.assertIn("/models/team%2Fmodel:generateContent", opener.open.call_args.args[0].full_url)

    def test_cloud_url_validation(self):
        invalid = ["http://example.test/v1", "https://user:pass@example.test", "https://example.test?key=x", "https://example.test/#x", "https://example.test/a b", "https://example.test\\x", "https://example.test:0", "https://example.test:bad", "https:///missing", "https://[bad"]
        for base in invalid:
            with self.subTest(base=base), self.assertRaises(ValueError):
                self.settings("Compatible OpenAI", base)
        result = self.settings("Compatible OpenAI", " https://example.test:8443/v1/ ")
        self.assertEqual(result["base_url"], "https://example.test:8443/v1")

    def test_ollama_endpoint_is_fixed(self):
        for base in ["http://localhost:11434", "http://127.0.0.1:11434/api/chat", "https://example.test", "http://127.0.0.1:11435"]:
            with self.subTest(base=base), self.assertRaises(ValueError):
                self.settings("Ollama local", base)

    def test_provider_and_model_validation(self):
        with self.assertRaises(ValueError):
            self.settings("Unknown", "https://example.test")
        for model in ["", " ", "model name", "x" * 201, "../bad?key=x", "modelo\n"]:
            # Los espacios exteriores se normalizan; salto final con nombre válido sí se admite.
            if model == "modelo\n":
                self.assertEqual(self.settings(model=model)["model"], "modelo")
                continue
            with self.subTest(model=model), self.assertRaises(ValueError):
                self.settings(model=model)
        self.assertEqual(self.settings(model=" org/model:tag@v+1 ")["model"], "org/model:tag@v+1")

    def test_invalid_inputs_never_open_transport(self):
        opener = Mock()
        for prompt in ["", " ", None, "x" * 8001]:
            with self.subTest(prompt_type=type(prompt).__name__), self.assertRaises(ValueError):
                models.ask_model(prompt, self.settings(), "dummy", opener)
        for key in ["", "bad key", "bad\nkey", "é", "x" * 4097]:
            with self.subTest(key_length=len(key)), self.assertRaises(ValueError):
                models.ask_model("hola", self.settings(), key, opener)
        opener.open.assert_not_called()

    def test_http_errors_hide_body_and_credentials(self):
        for code in [301, 302, 307, 308, 401, 403, 404, 429, 500]:
            with self.subTest(code=code):
                opener = Mock()
                opener.open.side_effect = urllib.error.HTTPError("https://example.test", code, "dummy-sensitive", {}, io.BytesIO(b"dummy-sensitive"))
                with self.assertRaises(ValueError) as error:
                    models.ask_model("hola", self.settings(), "dummy-sensitive", opener)
                self.assertIn(str(code), str(error.exception))
                self.assertNotIn("dummy-sensitive", str(error.exception))
                opener.open.assert_called_once()

    def test_network_errors_no_retry_or_details(self):
        for failure in [urllib.error.URLError("dummy-sensitive"), TimeoutError("dummy-sensitive"), OSError("dummy-sensitive")]:
            with self.subTest(error=type(failure).__name__):
                opener = Mock()
                opener.open.side_effect = failure
                with self.assertRaises(ValueError) as error:
                    models.ask_model("hola", self.settings(), "dummy", opener)
                self.assertNotIn("dummy-sensitive", str(error.exception))
                opener.open.assert_called_once()

    def test_redirects_and_system_proxies_disabled(self):
        handler = models.NoRedirect()
        self.assertIsNone(handler.redirect_request(None, None, 302, "redirect", {}, "https://elsewhere.test"))
        opener, _ = self.transport({"choices": [{"message": {"content": "ok"}}]})
        with patch.object(models.urllib.request, "build_opener", return_value=opener) as build:
            models.ask_model("hola", self.settings(), "dummy")
        handlers = build.call_args.args
        self.assertIsInstance(handlers[0], urllib.request.ProxyHandler)
        self.assertEqual(handlers[0].proxies, {})
        self.assertIsInstance(handlers[1], models.NoRedirect)

    def test_response_size_limit(self):
        opener, _ = self.transport(raw=b"x" * (models.MAX_RESPONSE + 1))
        with self.assertRaisesRegex(ValueError, "demasiado grande"):
            models.ask_model("hola", self.settings(), "dummy", opener)

    def test_malformed_or_empty_responses(self):
        for raw in [b"not json", b"\xff", b"{}", b"[]", b'{"choices":[]}', b'{"choices":[{"message":{"content":null}}]}', b'{"choices":[{"message":{"content":" "}}]}']:
            with self.subTest(raw=raw):
                opener, _ = self.transport(raw=raw)
                with self.assertRaises(ValueError):
                    models.ask_model("hola", self.settings(), "dummy", opener)
        for provider, data in [("Anthropic", {"content": []}), ("Google Gemini", {"candidates": []}), ("Ollama local", {"message": {}})]:
            with self.subTest(provider=provider):
                opener, _ = self.transport(data)
                with self.assertRaises(ValueError):
                    models.ask_model("hola", self.settings(provider), "dummy", opener)


class ConfigurationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.directory = Path(self.temp.name) / "profile"
        self.environment = patch.dict(os.environ, {}, clear=True)
        self.environment.start()
        self.addCleanup(self.environment.stop)
        self.settings = models.validate_settings("OpenAI", "https://api.openai.com/v1", "example-model")

    def test_profile_directory_uses_localappdata(self):
        with patch.dict(os.environ, {"LOCALAPPDATA": self.temp.name}):
            self.assertEqual(models.profile_dir(), Path(self.temp.name) / "MiAsistente")

    def test_missing_config_has_no_default_model(self):
        loaded = models.load_settings(self.directory)
        self.assertEqual(loaded["provider"], "OpenAI")
        self.assertEqual(loaded["model"], "")

    def test_config_roundtrip_excludes_secrets_and_extra_fields(self):
        settings = dict(self.settings, api_key="dummy-sensitive", arbitrary="ignored")
        models.save_settings(settings, self.directory)
        self.assertEqual(models.load_settings(self.directory), self.settings)
        data = json.loads((self.directory / "config.json").read_text(encoding="utf-8"))
        self.assertEqual(set(data), {"provider", "base_url", "model"})
        self.assertNotIn("dummy-sensitive", json.dumps(data))
        self.assertFalse((self.directory / "api_keys.json").exists())
        self.assertEqual(list(self.directory.glob(".config-*")), [])

    def test_invalid_config_files_rejected(self):
        self.directory.mkdir()
        for raw in [b"not json", b"[]", b"\xff", b"x" * 65537, b'{"provider":"unknown"}']:
            with self.subTest(raw_length=len(raw)):
                (self.directory / "config.json").write_bytes(raw)
                with self.assertRaises(ValueError):
                    models.load_settings(self.directory)

    def test_typed_environment_saved_precedence(self):
        models.save_key(self.settings, "saved-dummy", self.directory)
        self.assertEqual(models.resolve_key(self.settings, directory=self.directory), "saved-dummy")
        with patch.dict(os.environ, {"OPENAI_API_KEY": "env-dummy"}):
            self.assertEqual(models.resolve_key(self.settings, directory=self.directory), "env-dummy")
            self.assertEqual(models.resolve_key(self.settings, " typed-dummy ", self.directory), "typed-dummy")
            self.assertEqual(models.resolve_key(self.settings, "  ", self.directory), "env-dummy")

    def test_each_provider_environment_name(self):
        for provider, (_, variable) in models.PROVIDERS.items():
            if not variable:
                continue
            base = models.PROVIDERS[provider][0] or "https://example.test/v1"
            settings = models.validate_settings(provider, base, "example")
            with self.subTest(provider=provider), patch.dict(os.environ, {variable: "env-dummy"}):
                self.assertEqual(models.resolve_key(settings, directory=self.directory), "env-dummy")

    def test_saved_keys_bound_to_provider_and_exact_destination(self):
        models.save_key(self.settings, "saved-dummy", self.directory)
        for changed in [dict(self.settings, base_url="https://other.test/v1"), dict(self.settings, base_url="https://api.openai.com/v2"), dict(self.settings, provider="Compatible OpenAI")]:
            with self.subTest(changed=changed), self.assertRaises(ValueError):
                models.resolve_key(changed, directory=self.directory)
        self.assertEqual(models.resolve_key(dict(self.settings, model="another"), directory=self.directory), "saved-dummy")

    def test_saved_key_opt_in_and_delete(self):
        models.save_settings(self.settings, self.directory)
        with self.assertRaises(ValueError):
            models.resolve_key(self.settings, directory=self.directory)
        models.save_key(self.settings, "saved-dummy", self.directory)
        self.assertTrue((self.directory / "api_keys.json").exists())
        self.assertNotIn("saved-dummy", (self.directory / "config.json").read_text())
        models.delete_keys(self.directory)
        models.delete_keys(self.directory)
        self.assertFalse((self.directory / "api_keys.json").exists())

    def test_ollama_needs_no_key_and_refuses_saving_one(self):
        settings = models.validate_settings("Ollama local", "http://127.0.0.1:11434", "example")
        self.assertEqual(models.resolve_key(settings, "ignored", self.directory), "")
        with self.assertRaises(ValueError):
            models.save_key(settings, "dummy", self.directory)


if __name__ == "__main__":
    unittest.main()
