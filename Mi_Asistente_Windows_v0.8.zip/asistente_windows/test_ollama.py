"""Pruebas sin conexión de la frontera con Ollama y del abridor."""
import io
import json
import unittest
from unittest.mock import patch
import urllib.error

from assistant import ask_ollama, open_known_app, OLLAMA_ENDPOINT


class OllamaTests(unittest.TestCase):
    def fake_response(self, data):
        return io.BytesIO(json.dumps(data).encode())

    @patch('assistant.urllib.request.build_opener')
    def test_only_current_prompt_and_no_tools(self, build):
        build.return_value.open.return_value = self.fake_response({'message': {'content': 'Hola'}})
        self.assertEqual(ask_ollama('Hola', 'modelo-local'), 'Hola')
        request = build.return_value.open.call_args.args[0]
        body = json.loads(request.data)
        self.assertEqual(request.full_url, OLLAMA_ENDPOINT)
        self.assertEqual(body['messages'][-1], {'role': 'user', 'content': 'Hola'})
        self.assertEqual(len(body['messages']), 2)
        self.assertNotIn('tools', body)
        self.assertFalse(body['stream'])
        self.assertEqual(build.call_args.args[0].proxies, {})
        redirect = build.call_args.args[1]
        self.assertIsNone(redirect.redirect_request(None, None, 302, '', {}, 'https://example.org'))

    @patch('assistant.urllib.request.build_opener')
    def test_reject_remote_endpoint_before_network(self, build):
        for endpoint in ['https://example.org/api/chat', 'http://localhost:11434/api/chat',
                         'http://127.0.0.1:11434/api/chat?x=1']:
            with self.assertRaises(ValueError):
                ask_ollama('hola', 'modelo', endpoint)
        build.assert_not_called()

    def test_input_validation(self):
        for prompt, model in [('', 'm'), ('hola', ''), ('x' * 8001, 'm')]:
            with self.assertRaises(ValueError):
                ask_ollama(prompt, model)

    @patch('assistant.urllib.request.build_opener')
    def test_connection_failure(self, build):
        build.return_value.open.side_effect = urllib.error.URLError('offline')
        with self.assertRaisesRegex(ValueError, 'Ollama local'):
            ask_ollama('hola', 'm')

    @patch('assistant.urllib.request.build_opener')
    def test_bad_response(self, build):
        for data in [b'not json', b'{}', b'{"message":{"content":4}}', b'x' * 262145]:
            build.return_value.open.return_value = io.BytesIO(data)
            with self.assertRaises(ValueError):
                ask_ollama('hola', 'm')

    @patch('assistant.subprocess.Popen')
    def test_unknown_executable_never_starts(self, popen):
        with self.assertRaises(ValueError):
            open_known_app('cmd.exe /c del *')
        popen.assert_not_called()

    @patch('assistant.sys.platform', 'linux')
    @patch('assistant.subprocess.Popen')
    def test_windows_action_refused_on_linux(self, popen):
        with self.assertRaises(OSError):
            open_known_app('notepad')
        popen.assert_not_called()


if __name__ == '__main__':
    unittest.main()
