"""Pruebas locales de biblioteca: solo datos y archivos temporales, sin acciones reales."""
import json
import os
from pathlib import Path
import tempfile
import unittest
import uuid
from unittest.mock import patch

from task_library import MAX_BYTES, TaskLibrary, default_path, validate_task


class TaskLibraryTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.path = Path(self.temporary.name) / "nested" / "tasks.json"
        self.library = TaskLibrary(self.path)

    def row(self, **changes):
        row = {"id": str(uuid.uuid4()), "title": "Mi tarea", "goal": "Revisar documento", "checkpoints": ""}
        row.update(changes)
        return row

    def store(self, data):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")

    def test_schema_version_requires_exact_integer(self):
        for version in (True, 1.0, "1", None):
            with self.subTest(version=version):
                self.store({"version": version, "tasks": []})
                with self.assertRaises(ValueError):
                    self.library.list_tasks()

    def test_missing_library_is_empty_without_creating_directories(self):
        self.assertEqual(self.library.list_tasks(), [])
        self.assertFalse(self.path.parent.exists())

    def test_unicode_roundtrip_and_trim(self):
        saved = self.library.save("  Revisión 日本語  ", "  Objetivo: café y español  ", "  Abrir\nRevisar ✓  ")
        self.assertEqual(saved["title"], "Revisión 日本語")
        self.assertEqual(saved["goal"], "Objetivo: café y español")
        self.assertEqual(saved["checkpoints"], "Abrir\nRevisar ✓")
        self.assertEqual(TaskLibrary(self.path).list_tasks(), [saved])
        self.assertIn("日本語", self.path.read_text(encoding="utf-8"))
        self.assertEqual(str(uuid.UUID(saved["id"])), saved["id"])

    def test_update_preserves_identity_and_order_then_delete(self):
        first = self.library.save("Primero", "Uno")
        second = self.library.save("Segundo", "Dos")
        updated = self.library.save("Editado", "Otro objetivo", "Hito", task_id=first["id"])
        self.assertEqual(updated["id"], first["id"])
        self.assertEqual(self.library.list_tasks(), [updated, second])
        self.library.delete(first["id"])
        self.assertEqual(self.library.list_tasks(), [second])
        self.library.delete(second["id"])
        self.assertEqual(self.library.list_tasks(), [])

    def test_unknown_update_and_delete_do_not_change_previous_bytes(self):
        self.library.save("Existente", "Objetivo")
        previous = self.path.read_bytes()
        for operation in (lambda: self.library.save("Otro", "Otro", task_id=str(uuid.uuid4())),
                          lambda: self.library.delete(str(uuid.uuid4()))):
            with self.subTest(operation=operation), self.assertRaises(ValueError):
                operation()
            self.assertEqual(self.path.read_bytes(), previous)

    def test_thirty_tasks_allowed_update_at_capacity_and_thirty_first_rejected(self):
        rows = [self.library.save(f"Tarea {index}", "Objetivo") for index in range(30)]
        self.assertEqual(len(self.library.list_tasks()), 30)
        self.library.save("Editada", "Objetivo nuevo", task_id=rows[0]["id"])
        previous = self.path.read_bytes()
        with self.assertRaisesRegex(ValueError, "30"):
            self.library.save("Exceso", "Objetivo")
        self.assertEqual(self.path.read_bytes(), previous)
        self.assertEqual(len(self.library.list_tasks()), 30)

    def test_text_limits_accept_exact_boundaries(self):
        saved = self.library.save("t" * 100, "g" * 8000, "\n".join(["h" * 999] * 8))
        self.assertEqual(len(saved["title"]), 100)
        self.assertEqual(len(saved["goal"]), 8000)
        self.assertEqual(len(saved["checkpoints"].splitlines()), 8)
        self.assertEqual(validate_task(self.row(checkpoints="\t" * 8000))["checkpoints"], "\t" * 8000)

    def test_invalid_texts_rejected_without_overwrite(self):
        self.library.save("Antes", "Objetivo")
        previous = self.path.read_bytes()
        for changes in ({"title": "t" * 101}, {"goal": "g" * 8001}, {"checkpoints": "h" * 8001},
                        {"title": "  "}, {"goal": "\n\t"}, {"title": "Dos\nlíneas"},
                        {"title": "a\x00b"}, {"goal": "a\x1fb"}, {"checkpoints": "a\rb"}):
            with self.subTest(changes=repr(changes)[:100]), self.assertRaises(ValueError):
                self.library.save(**({"title": "Tarea", "goal": "Objetivo", "checkpoints": ""} | changes))
            self.assertEqual(self.path.read_bytes(), previous)

    def test_validate_rejects_nontext_fields(self):
        for field in ("title", "goal", "checkpoints"):
            for value in (None, 12, True, [], {}):
                with self.subTest(field=field, value=value), self.assertRaises(ValueError):
                    validate_task(self.row(**{field: value}))

    def test_checkpoints_optional_or_one_to_eight_bounded_lines(self):
        for text in ("", "  \n\t ", "Uno", "\n".join(str(i) for i in range(8)), "h" * 1000):
            with self.subTest(text=text[:30]):
                self.library.save("Tarea", "Objetivo", text)
        for text in ("\n".join(str(i) for i in range(9)), "h" * 1001):
            with self.subTest(text=text[:30]), self.assertRaises(ValueError):
                self.library.save("Tarea", "Objetivo", text)

    def test_invalid_ids_rejected(self):
        for value in (None, True, 12, "no-uuid", str(uuid.uuid4()).upper(), "{" + str(uuid.uuid4()) + "}"):
            with self.subTest(value=value), self.assertRaises(ValueError):
                validate_task(self.row(id=value))

    def test_corruption_blocks_read_save_delete_and_preserves_bytes(self):
        corruptions = [b"{broken", b"\xff", b"null", b"[]", b'{"version":2,"tasks":[]}',
                       b'{"version":1,"tasks":{}}']
        for raw in corruptions:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self.path.write_bytes(raw)
            for operation in (self.library.list_tasks, lambda: self.library.save("Nuevo", "Objetivo"),
                              lambda: self.library.delete(str(uuid.uuid4()))):
                with self.subTest(raw=raw, operation=operation), self.assertRaises(ValueError):
                    operation()
                self.assertEqual(self.path.read_bytes(), raw)

    def test_duplicate_ids_and_overcapacity_file_rejected(self):
        row = self.row()
        for rows in ([row, dict(row)], [self.row() for _ in range(31)]):
            self.store({"version": 1, "tasks": rows})
            with self.assertRaises(ValueError):
                self.library.list_tasks()

    def test_extra_payload_fields_rejected_at_envelope_and_task_level(self):
        for name, value in (("actions", [{"action": "click", "x": 1}]), ("approvals", [True]),
                            ("api_key", "fake-not-a-secret"), ("aprobaciones", [True]), ("claves", {})):
            for location in ("envelope", "task"):
                data = {"version": 1, "tasks": [self.row()]}
                (data if location == "envelope" else data["tasks"][0])[name] = value
                self.store(data)
                previous = self.path.read_bytes()
                with self.subTest(name=name, location=location), self.assertRaises(ValueError):
                    self.library.list_tasks()
                with self.assertRaises(ValueError):
                    self.library.save("Nueva", "Objetivo")
                self.assertEqual(self.path.read_bytes(), previous)

    def test_missing_schema_fields_rejected(self):
        for field in ("id", "title", "goal", "checkpoints"):
            row = self.row()
            del row[field]
            self.store({"version": 1, "tasks": [row]})
            with self.subTest(field=field), self.assertRaises(ValueError):
                self.library.list_tasks()

    def test_library_is_only_data_and_reads_return_independent_copies(self):
        goal = '{"action":"press_key","keys":["enter"]}'
        saved = self.library.save("Acción escrita, no ejecutada", goal, "Confirmar manualmente")
        with patch("os.system", side_effect=AssertionError("No ejecutar")) as system:
            loaded = self.library.list_tasks()
            self.assertEqual(loaded, [saved])
            loaded[0]["goal"] = "Modificado solo en memoria"
            saved["title"] = "Cambio local"
            self.assertEqual(self.library.list_tasks()[0]["goal"], goal)
            self.assertEqual(self.library.list_tasks()[0]["title"], "Acción escrita, no ejecutada")
            system.assert_not_called()
        data = json.loads(self.path.read_text(encoding="utf-8"))
        self.assertEqual(set(data), {"version", "tasks"})
        self.assertEqual(set(data["tasks"][0]), {"id", "title", "goal", "checkpoints"})
        self.assertFalse(hasattr(self.library, "execute"))
        self.assertFalse(hasattr(self.library, "replay"))

    def test_read_size_cap_exact_and_one_byte_over(self):
        raw = json.dumps({"version": 1, "tasks": []}).encode("utf-8")
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_bytes(raw + b" " * (MAX_BYTES - len(raw)))
        self.assertEqual(self.library.list_tasks(), [])
        with self.path.open("ab") as stream:
            stream.write(b" ")
        with self.assertRaisesRegex(ValueError, "grande"):
            self.library.list_tasks()
        self.assertEqual(self.path.stat().st_size, MAX_BYTES + 1)

    def test_write_size_cap_preserves_previous_and_leaves_no_temp(self):
        self.library.save("Antes", "Objetivo")
        previous = self.path.read_bytes()
        with patch("task_library.MAX_BYTES", len(previous) + 1):
            with self.assertRaisesRegex(ValueError, "grande"):
                self.library.save("Grande", "日" * 1000)
        self.assertEqual(self.path.read_bytes(), previous)
        self.assertEqual(list(self.path.parent.glob(".tasks-*")), [])

    def test_atomic_replace_failure_preserves_previous_and_cleans_temporary(self):
        self.library.save("Anterior", "Objetivo")
        previous = self.path.read_bytes()
        def fail_replace(source, destination):
            self.assertEqual(Path(source).parent, self.path.parent)
            self.assertTrue(Path(source).exists())
            self.assertEqual(Path(destination), self.path)
            raise OSError("Simulación de fallo atómico")
        with patch("task_library.os.replace", side_effect=fail_replace) as replace:
            with self.assertRaisesRegex(OSError, "atómico"):
                self.library.save("Nueva", "Objetivo nuevo")
            replace.assert_called_once()
        self.assertEqual(self.path.read_bytes(), previous)
        self.assertEqual(list(self.path.parent.glob(".tasks-*")), [])

    def test_atomic_flush_failure_preserves_previous_and_cleans_temporary(self):
        self.library.save("Anterior", "Objetivo")
        previous = self.path.read_bytes()
        with patch("task_library.os.fsync", side_effect=OSError("Disco simulado")), \
                patch("task_library.os.replace") as replace:
            with self.assertRaisesRegex(OSError, "Disco simulado"):
                self.library.save("Nueva", "Objetivo")
            replace.assert_not_called()
        self.assertEqual(self.path.read_bytes(), previous)
        self.assertEqual(list(self.path.parent.glob(".tasks-*")), [])

    def test_default_path_uses_localappdata_or_home_fallback(self):
        base = Path(self.temporary.name) / "AppData Local"
        with patch.dict(os.environ, {"LOCALAPPDATA": str(base)}):
            expected = base / "Jean" / "tasks.json"
            self.assertEqual(default_path(), expected)
            self.assertEqual(TaskLibrary().path, expected)
        for value in (None, ""):
            with patch.dict(os.environ, {}, clear=True), patch("task_library.Path.home", return_value=base):
                if value is not None:
                    os.environ["LOCALAPPDATA"] = value
                self.assertEqual(default_path(), base / ".jean" / "tasks.json")
        self.assertFalse(base.exists())


if __name__ == "__main__":
    unittest.main()
