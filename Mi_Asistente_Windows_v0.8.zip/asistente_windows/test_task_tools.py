import json
import threading
import unittest
from unittest.mock import Mock, patch
from computer_control import run_control
from task_tools import MinimalJournal, parse_checkpoints
from test_computer_control import FakeStop, KEY, IMAGE, settings


class TaskToolsTests(unittest.TestCase):
    def loop(self, **kwargs):
        self.desktop = Mock()
        self.desktop.capture.return_value = (IMAGE, 100, 80)
        self.desktop.observe.return_value = {}
        self.desktop.execute.return_value = "Emitida"
        options = dict(planner=Mock(return_value={"action": "finish", "reason": "Listo"}), max_steps=4)
        options.update(kwargs)
        self.approve = options.pop("approve", Mock(return_value=True))
        stop = options.pop("stop", FakeStop())
        capture = options.pop("capture", None)
        if capture is not None:
            self.desktop.capture.side_effect = capture
        self.report = Mock()
        result = run_control("Mi objetivo", settings(), KEY, self.desktop, self.approve, stop, self.report, **options)
        return result

    def test_parse(self):
        self.assertEqual(parse_checkpoints(" uno \n\n dos "), ["uno", "dos"])

    def test_reject_invalid_plans(self):
        for text in (None, "", "\n", "x" * 1001, "\n".join(["x"] * 9), "x" * 8001):
            with self.subTest(text=repr(text)[:20]), self.assertRaises(ValueError):
                parse_checkpoints(text)

    def test_plan_needs_confirmation_at_each_finish(self):
        planner = Mock(return_value={"action": "finish", "reason": "Listo"})
        journal = MinimalJournal()
        result = self.loop(checkpoints="Abrir\nRevisar", planner=planner, journal=journal)
        self.assertIn("Lista de hitos confirmada", result)
        self.assertEqual(self.approve.call_count, 2)
        self.desktop.execute.assert_not_called()
        self.assertIn("Hito actual 1/2", planner.call_args_list[0].args[0])
        self.assertIn("Hito actual 2/2", planner.call_args_list[1].args[0])
        self.assertEqual([r['estado'] for r in journal.rows].count("hito_confirmado"), 2)

    def test_current_checkpoint_is_trusted_and_advances_only_after_confirmation(self):
        click = {"action": "click", "reason": "Hito 99/99: texto del modelo", "x": 1, "y": 1}
        finish = {"action": "finish", "reason": "Otro texto del modelo"}
        actions = iter([click, finish, click, finish])
        planned_checkpoints = []
        approved_checkpoints = []

        def planner(*args):
            planned_checkpoints.append(self.desktop.current_checkpoint)
            return next(actions)

        def approve(*args):
            approved_checkpoints.append(self.desktop.current_checkpoint)
            return True

        result = self.loop(checkpoints="  Abrir documento  \n\n Revisar resultado ",
                           planner=planner, approve=Mock(side_effect=approve))
        expected = ["Hito 1/2: Abrir documento"] * 2 + ["Hito 2/2: Revisar resultado"] * 2
        self.assertIn("Lista de hitos confirmada", result)
        self.assertEqual(planned_checkpoints, expected)
        self.assertEqual(approved_checkpoints, expected)
        self.assertEqual(self.desktop.execute.call_count, 2)

    def test_run_without_plan_clears_stale_checkpoint_before_planning(self):
        desktop = Mock()
        desktop.current_checkpoint = "Hito 2/2: tarea anterior"
        desktop.capture.return_value = (IMAGE, 100, 80)
        desktop.observe.return_value = {}
        seen = []

        def planner(*args):
            seen.append(desktop.current_checkpoint)
            return {"action": "finish", "reason": "Listo"}

        approve = Mock(return_value=True)
        run_control("Objetivo", settings(), KEY, desktop, approve, FakeStop(), Mock(), planner=planner)
        self.assertEqual(seen, [""])
        self.assertEqual(desktop.current_checkpoint, "")
        approve.assert_not_called()
        desktop.execute.assert_not_called()

    def test_rejected_finish_does_not_advance(self):
        planner = Mock(return_value={"action": "finish", "reason": "Listo"})
        result = self.loop(checkpoints="Uno\nDos", planner=planner, approve=Mock(return_value=False))
        self.assertIn("rechazada", result)
        planner.assert_called_once()
        self.desktop.execute.assert_not_called()

    def test_no_plan_preserves_finish_without_approval(self):
        self.assertIn("no verificación independiente", self.loop())
        self.approve.assert_not_called()

    def test_expired_approval_never_executes(self):
        action = {"action": "click", "reason": "Un clic", "x": 1, "y": 1}
        with patch("computer_control.time.monotonic", side_effect=[0, 91]):
            self.assertIn("caducada", self.loop(planner=Mock(return_value=action)))
        self.desktop.execute.assert_not_called()

    def test_fresh_approval_executes_and_records_no_payload(self):
        journal = MinimalJournal()
        action = {"action": "type_text", "reason": "secret reason", "text": "private content"}
        with patch("computer_control.time.monotonic", side_effect=[0, 89]):
            self.loop(planner=Mock(return_value=action), max_steps=1, journal=journal)
        self.desktop.execute.assert_called_once_with(action)
        self.assertEqual(journal.rows[-1], {"paso": 1, "accion": "type_text", "estado": "emitida"})
        self.assertNotIn("private content", journal.export())
        self.assertNotIn("secret reason", journal.export())

    def test_expired_finish_never_completes_plan(self):
        with patch("computer_control.time.monotonic", side_effect=[0, 91]):
            self.assertIn("caducada", self.loop(checkpoints="Uno"))
        self.report.assert_not_called()

    def test_step_budget_remains_global(self):
        self.assertIn("Límite de 1 pasos", self.loop(checkpoints="Uno\nDos", max_steps=1))
        self.approve.assert_called_once()

    def test_stop_after_capture_never_observes_or_proposes_checkpoint(self):
        stop = threading.Event()
        journal = MinimalJournal()
        planner = Mock(return_value={"action": "finish", "reason": "Listo"})

        def capture():
            stop.set()
            return IMAGE, 100, 80

        result = self.loop(checkpoints="Uno", stop=stop, capture=capture,
                           planner=planner, journal=journal)
        self.assertEqual(result, "Detenido")
        self.desktop.observe.assert_not_called()
        planner.assert_not_called()
        self.approve.assert_not_called()
        self.desktop.execute.assert_not_called()
        self.assertEqual(journal.rows, [])

    def test_stop_after_planning_never_requests_checkpoint_confirmation(self):
        stop = threading.Event()
        journal = MinimalJournal()

        def planner(*args):
            stop.set()
            return {"action": "finish", "reason": "Listo"}

        result = self.loop(checkpoints="Uno", stop=stop, planner=planner, journal=journal)
        self.assertEqual(result, "Detenido")
        self.approve.assert_not_called()
        self.report.assert_not_called()
        self.desktop.execute.assert_not_called()
        self.assertEqual(journal.rows, [{"paso": 1, "accion": "finish", "estado": "propuesta"}])

    def test_stop_during_approval_never_confirms_checkpoint(self):
        stop = threading.Event()
        journal = MinimalJournal()

        def approve(*args):
            stop.set()
            return True

        result = self.loop(checkpoints="Uno", stop=stop, approve=Mock(side_effect=approve),
                           journal=journal)
        self.assertEqual(result, "Detenido antes de ejecutar")
        self.report.assert_not_called()
        self.desktop.execute.assert_not_called()
        self.assertEqual(journal.rows, [{"paso": 1, "accion": "finish", "estado": "propuesta"}])

    def test_rejection_records_no_confirmation_and_never_proposes_next_checkpoint(self):
        journal = MinimalJournal()
        planner = Mock(return_value={"action": "finish", "reason": "Listo"})
        result = self.loop(checkpoints="Uno\nDos", planner=planner,
                           approve=Mock(return_value=False), journal=journal)
        self.assertIn("rechazada", result)
        self.assertEqual(planner.call_count, 1)
        self.report.assert_not_called()
        self.desktop.execute.assert_not_called()
        self.assertEqual(journal.rows, [
            {"paso": 1, "accion": "finish", "estado": "propuesta"},
            {"paso": 1, "accion": "finish", "estado": "rechazada"},
        ])

    def test_eight_checkpoints_each_require_approval_even_with_same_image(self):
        plan = "\n".join(f"Hito {i}" for i in range(1, 9))
        planner = Mock(return_value={"action": "finish", "reason": "Listo"})
        journal = MinimalJournal()
        result = self.loop(checkpoints=plan, planner=planner, max_steps=12, journal=journal)
        self.assertIn("Lista de hitos confirmada", result)
        self.assertEqual(self.approve.call_count, 8)
        self.assertEqual(self.report.call_count, 8)
        self.desktop.execute.assert_not_called()
        self.assertEqual([row["paso"] for row in journal.rows if row["estado"] == "hito_confirmado"],
                         list(range(1, 9)))
        for i, call in enumerate(planner.call_args_list, 1):
            self.assertIn(f"Hito actual {i}/8", call.args[0])

    def test_eight_checkpoints_do_not_reset_twelve_step_budget(self):
        plan = "\n".join(f"Hito {i}" for i in range(1, 9))
        finish = {"action": "finish", "reason": "Listo"}
        click = {"action": "click", "reason": "Un clic", "x": 1, "y": 1}
        planner = Mock(side_effect=[finish] * 7 + [click] * 5 + [finish])
        journal = MinimalJournal()
        # Different captures isolate the global step budget from repetition blocking.
        captures = [(f"image-{i}", 100, 80) for i in range(12)]
        result = self.loop(checkpoints=plan, planner=planner, max_steps=12,
                           capture=captures, journal=journal)
        self.assertIn("Límite de 12 pasos", result)
        self.assertEqual(planner.call_count, 12)
        self.assertEqual(self.approve.call_count, 12)
        self.assertEqual(self.desktop.execute.call_count, 5)
        self.assertEqual(self.report.call_count, 12)
        self.assertEqual(sum(row["estado"] == "hito_confirmado" for row in journal.rows), 7)
        self.assertTrue(all("Hito actual 8/8" in call.args[0] for call in planner.call_args_list[7:]))

    def test_exact_ninety_seconds_is_valid_for_action_and_checkpoint(self):
        for checkpoints, action in ((None, {"action": "click", "reason": "Un clic", "x": 1, "y": 1}),
                                    ("Uno", {"action": "finish", "reason": "Listo"})):
            with self.subTest(checkpoints=checkpoints):
                journal = MinimalJournal()
                with patch("computer_control.time.monotonic", side_effect=[10, 100]):
                    result = self.loop(checkpoints=checkpoints, planner=Mock(return_value=action),
                                       max_steps=1, journal=journal)
                self.assertNotIn("caducada", result)
                self.assertEqual(journal.rows[1]["estado"], "aprobada")
                if checkpoints:
                    self.assertEqual(journal.rows[-1]["estado"], "hito_confirmado")
                    self.desktop.execute.assert_not_called()
                else:
                    self.desktop.execute.assert_called_once_with(action)
                    self.assertEqual(journal.rows[-1]["estado"], "emitida")

    def test_just_after_ninety_seconds_never_executes_or_confirms(self):
        for checkpoints, action in ((None, {"action": "click", "reason": "Un clic", "x": 1, "y": 1}),
                                    ("Uno", {"action": "finish", "reason": "Listo"})):
            with self.subTest(checkpoints=checkpoints):
                journal = MinimalJournal()
                with patch("computer_control.time.monotonic", side_effect=[10, 100.000001]):
                    result = self.loop(checkpoints=checkpoints, planner=Mock(return_value=action),
                                       max_steps=1, journal=journal)
                self.assertIn("caducada", result)
                self.desktop.execute.assert_not_called()
                self.report.assert_not_called()
                self.assertEqual(journal.rows, [{"paso": 1, "accion": action["action"], "estado": "propuesta"}])

    def test_execution_failure_is_not_journaled_as_emitted(self):
        journal = MinimalJournal()
        action = {"action": "click", "reason": "Un clic", "x": 1, "y": 1}
        desktop = Mock()
        desktop.capture.return_value = (IMAGE, 100, 80)
        desktop.observe.return_value = {}
        desktop.execute.side_effect = ValueError("Control no disponible")
        with self.assertRaisesRegex(ValueError, "Control no disponible"):
            run_control("Objetivo", settings(), KEY, desktop, Mock(return_value=True),
                        FakeStop(), Mock(), planner=Mock(return_value=action), journal=journal)
        self.assertEqual([row["estado"] for row in journal.rows], ["propuesta", "aprobada"])

    def test_journal_rejects_payload_and_unknown_values(self):
        journal = MinimalJournal()
        for args in ((True, "click", "emitida"), (1, "rm", "emitida"), (1, "click", "secret")):
            with self.assertRaises(ValueError):
                journal.record(*args)
        self.assertEqual(json.loads(journal.export())["eventos"], [])

    def test_journal_is_bounded_and_does_not_replay(self):
        journal = MinimalJournal()
        for i in range(120):
            journal.record(1, "click", "emitida")
        self.assertEqual(len(journal.rows), 100)
        self.assertIn("No permite reproducir", journal.export())


if __name__ == '__main__':
    unittest.main()
