"""Integración simulada planner → aprobación → WindowsDesktop → UIA.

No abre ventanas, no usa Win32, no contacta proveedores y no ejecuta programas.
Los wrappers UIA son dobles; se ejercita el backend real con sus seams de test.
"""
import copy
import json
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

sys.path.insert(0, str(Path(__file__).resolve().parent))
import computer_control as control
from windows_uia import WindowsUIA
from test_computer_control import FakeStop, FakeTransport, KEY, IMAGE, response_for, settings


class FakeWrapper:
    def __init__(self, name, handle, control_type, *, invoke=False, value=False):
        self.element_info = SimpleNamespace(
            runtime_id=(handle,), process_id=123, handle=handle,
            control_type=control_type, class_name="TestControl", automation_id=name,
            name=name, rectangle=SimpleNamespace(left=0, top=0, right=100, bottom=80),
            is_password=False,
        )
        self.is_visible = Mock(return_value=True)
        self.is_enabled = Mock(return_value=True)
        self.children = Mock(return_value=[])
        self.iface_invoke = SimpleNamespace(Invoke=Mock()) if invoke else None
        self.iface_value = SimpleNamespace(CurrentIsReadOnly=False, SetValue=Mock()) if value else None
        self.set_focus = Mock()


class UIAIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.window = FakeWrapper("Notas", 42, "Window")
        self.button = FakeWrapper("Guardar", 43, "Button", invoke=True)
        self.edit = FakeWrapper("Contenido", 44, "Edit", value=True)
        self.window.children.return_value = [self.button, self.edit]
        provider = Mock()
        provider.windows.return_value = [self.window]
        provider.window.return_value.wrapper_object.return_value = self.window
        self.desktop = control.WindowsDesktop.__new__(control.WindowsDesktop)
        self.desktop.gui = Mock()
        self.desktop.gui.size.return_value = (100, 80)
        self.desktop.user32 = Mock()
        self.desktop.user32.GetForegroundWindow.return_value = 42
        self.desktop.foreground = 42
        self.desktop.uia = WindowsUIA(
            _desktop=provider,
            _foreground=self.desktop.user32.GetForegroundWindow,
        )
        self.desktop._uia_attempted = True
        self.desktop.last_observation = {}
        self.desktop.capture = Mock(return_value=(IMAGE, 100, 80))
        self.approve = Mock(return_value=True)
        self.report = Mock()
        self.stop = FakeStop()
        for target in ("computer_control.subprocess.Popen", "computer_control.urllib.request.build_opener"):
            guard = patch(target, side_effect=AssertionError("Operación real prohibida"))
            guard.start()
            self.addCleanup(guard.stop)

    def run_loop(self, planner, max_steps=1):
        return control.run_control("Guardar una nota", settings(), KEY, self.desktop,
                                   self.approve, self.stop, self.report,
                                   planner=planner, max_steps=max_steps)

    def planner_for(self, action, *, text="Hola 日本語"):
        def planner(goal, config, key, image, history):
            observation = history[-1]["current_uia_observation"]
            if action == "focus_window":
                params = {"window_id": observation["windows"][0]["id"]}
            else:
                name = "Contenido" if action == "set_value" else "Guardar"
                target = next(e for e in observation["elements"] if e["name"] == name)
                params = {"element_id": target["id"]}
                if action == "set_value":
                    params["text"] = text
            return {"action": action, "reason": "Objetivo aprobado", **params}
        return planner

    def assert_no_coordinate_fallback(self):
        for method in ("moveTo", "click", "press", "scroll", "write"):
            getattr(self.desktop.gui, method).assert_not_called()

    def test_real_uia_routes_each_action_only_after_approval(self):
        order = []
        self.approve.side_effect = lambda *args: order.append("approve") or True
        self.edit.iface_value.SetValue.side_effect = lambda text: order.append(("set_value", text))
        self.button.iface_invoke.Invoke.side_effect = lambda: order.append("invoke")
        self.window.set_focus.side_effect = lambda: order.append("focus")
        for action, expected in (("focus_window", "focus"), ("invoke_element", "invoke"), ("set_value", ("set_value", "Hola 日本語"))):
            with self.subTest(action=action):
                order.clear()
                self.approve.reset_mock()
                result = self.run_loop(self.planner_for(action))
                self.assertIn("Límite de 1 pasos", result)
                self.assertEqual(order, ["approve", expected])
                self.approve.assert_called_once()
                self.assertEqual(self.approve.call_args.args[0]["action"], action)
                self.assert_no_coordinate_fallback()

    def test_rejection_never_reaches_uia(self):
        self.approve.return_value = False
        self.assertIn("rechazada", self.run_loop(self.planner_for("invoke_element")))
        self.button.iface_invoke.Invoke.assert_not_called()
        self.desktop.user32.SetForegroundWindow.assert_not_called()
        self.report.assert_not_called()
        self.assert_no_coordinate_fallback()

    def test_fresh_observation_and_previous_result_reach_next_planner(self):
        contexts = []
        propose = self.planner_for("set_value")
        def planner(*args):
            contexts.append(copy.deepcopy(args[-1]))
            if len(contexts) == 1:
                return propose(*args)
            return {"action": "finish", "reason": "Revisado"}
        self.assertIn("no verificación independiente", self.run_loop(planner, max_steps=2))
        first = contexts[0][-1]["current_uia_observation"]
        second = contexts[1][-1]["current_uia_observation"]
        self.assertNotEqual(first["elements"][0]["id"], second["elements"][0]["id"])
        self.assertEqual(len(contexts[1]), 2)
        self.assertEqual(contexts[1][0]["action"]["action"], "set_value")
        self.assertIn("comprobar efecto", contexts[1][0]["result"])
        self.edit.iface_value.SetValue.assert_called_once_with("Hola 日本語")
        self.approve.assert_called_once()

    def test_old_element_id_cannot_be_reused_after_new_observation(self):
        saved = []
        propose = self.planner_for("invoke_element")
        def planner(*args):
            if not saved:
                saved.append(propose(*args))
            return dict(saved[0])
        with self.assertRaisesRegex(ValueError, "no se reintentó"):
            self.run_loop(planner, max_steps=2)
        self.assertEqual(self.approve.call_count, 2)
        self.button.iface_invoke.Invoke.assert_called_once()
        self.report.assert_called_once()
        self.assert_no_coordinate_fallback()

    def test_target_change_during_approval_fails_closed(self):
        def approve(*args):
            self.button.element_info.name = "Otro botón"
            return True
        self.approve.side_effect = approve
        with self.assertRaisesRegex(ValueError, "no se reintentó"):
            self.run_loop(self.planner_for("invoke_element"))
        self.button.iface_invoke.Invoke.assert_not_called()
        self.report.assert_not_called()
        self.assert_no_coordinate_fallback()

    def test_focus_restoration_failure_prevents_uia_and_fallback(self):
        # Observe with the original focus, then simulate an approval popup that
        # cannot restore the captured window.
        def approve(*args):
            self.desktop.user32.GetForegroundWindow.return_value = 99
            return True
        self.desktop.user32.GetForegroundWindow.return_value = 42
        self.approve.side_effect = approve
        with self.assertRaisesRegex(ValueError, "restaurar el foco"):
            self.run_loop(self.planner_for("set_value"))
        self.edit.iface_value.SetValue.assert_not_called()
        self.report.assert_not_called()
        self.assert_no_coordinate_fallback()

    def test_observe_initializes_backend_lazily_once(self):
        backend = self.desktop.uia
        self.desktop.uia = None
        self.desktop._uia_attempted = False
        with patch("windows_uia.WindowsUIA", return_value=backend) as constructor:
            first = self.desktop.observe()
            second = self.desktop.observe()
        constructor.assert_called_once_with()
        self.assertIn("elements", first)
        self.assertIn("elements", second)
        self.button.iface_invoke.Invoke.assert_not_called()
        self.window.set_focus.assert_not_called()

    def test_absent_backend_falls_back_to_coordinates_with_approval(self):
        self.desktop.uia = None
        self.desktop._uia_attempted = False
        def planner(goal, config, key, image, history):
            self.assertEqual(history[-1], {"current_uia_observation": {"available": False}})
            return {"action": "click", "reason": "Fallback aprobado", "x": 12, "y": 34}
        with patch("windows_uia.WindowsUIA", side_effect=ValueError("No instalado")) as constructor:
            self.run_loop(planner)
            self.assertEqual(self.desktop.observe(), {"available": False})
        constructor.assert_called_once()
        self.approve.assert_called_once()
        self.desktop.gui.click.assert_called_once_with()
        self.button.iface_invoke.Invoke.assert_not_called()

    def test_observation_failure_cannot_use_previous_uia_snapshot(self):
        self.desktop.uia.observation = Mock(side_effect=ValueError("Proveedor ausente"))
        self.desktop.last_observation = {"available": True}
        action = {"action": "invoke_element", "reason": "Obsoleto", "element_id": "old_id"}
        with self.assertRaisesRegex(ValueError, "UI Automation no disponible"):
            self.run_loop(Mock(return_value=action))
        self.assertIs(self.desktop.last_observation["available"], False)
        self.button.iface_invoke.Invoke.assert_not_called()
        self.report.assert_not_called()
        self.assert_no_coordinate_fallback()

    def test_each_provider_serializes_current_uia_context_and_action(self):
        for provider in control.VISION_PROVIDERS:
            with self.subTest(provider=provider):
                observation = self.desktop.observe()
                action = {"action": "set_value", "reason": "Escribir nota", "element_id": observation["elements"][1]["id"], "text": "Hola"}
                history = [{"current_uia_observation": observation}]
                transport = FakeTransport(response_for(provider, action))
                proposal = control.propose_action("Escribir", settings(provider), KEY, IMAGE, history, opener=transport)
                self.assertEqual(control.validate_action(proposal, 100, 80), action)
                body = json.loads(transport.requests[0][0].data)
                self.assertIn(action["element_id"], json.dumps(body))
                self.assertIn("current_uia_observation", json.dumps(body))
                self.assertEqual(len(transport.requests), 1)
                self.button.iface_invoke.Invoke.assert_not_called()
                self.edit.iface_value.SetValue.assert_not_called()


if __name__ == "__main__":
    unittest.main()
