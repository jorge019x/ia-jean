"""Pruebas propias, sin red, sin código externo y con reloj simulado."""
from concurrent.futures import ThreadPoolExecutor
import json
import threading
import unittest
from unittest.mock import patch

from usage_meter import MAX_IN_FLIGHT, MAX_RECORDS, UsageMeter


class FakeClock:
    def __init__(self, now=10.0):
        self.now = now

    def __call__(self):
        return self.now

    def advance(self, seconds):
        self.now += seconds


class UsageMeterTests(unittest.TestCase):
    def test_empty_and_session_isolation(self):
        meter = UsageMeter(clock=FakeClock())
        self.assertEqual(meter.snapshot(), {
            "total_calls": 0, "successes": 0, "errors": 0,
            "duration_seconds": 0.0, "in_flight": 0,
            "records": [], "dropped_records": 0,
        })
        token = meter.start("OpenAI", "model-a")
        meter.finish(token, True)
        self.assertEqual(UsageMeter(clock=FakeClock()).snapshot()["total_calls"], 0)

    def test_counts_labels_success_failure_and_monotonic_duration(self):
        clock = FakeClock()
        meter = UsageMeter(clock=clock)
        with patch("usage_meter.time.time", side_effect=AssertionError("No reloj civil")):
            first = meter.start(" OpenAI ", "model-a")
            clock.advance(1.25)
            second = meter.start("Anthropic", "model-b")
            clock.advance(0.75)
            self.assertTrue(meter.finish(first, True))
            clock.advance(0.5)
            self.assertTrue(meter.finish(second, False))
        data = meter.snapshot()
        self.assertEqual((data["total_calls"], data["successes"], data["errors"]), (2, 1, 1))
        self.assertEqual(data["duration_seconds"], 3.25)
        self.assertEqual(data["records"], [
            {"provider": "OpenAI", "model": "model-a", "success": True, "duration_seconds": 2.0},
            {"provider": "Anthropic", "model": "model-b", "success": False, "duration_seconds": 1.25},
        ])
        self.assertEqual(data["in_flight"], 0)

    def test_default_clock_is_monotonic(self):
        with patch("usage_meter.time.monotonic", side_effect=[100, 102.5]) as clock:
            meter = UsageMeter()
            meter.finish(meter.start("p", "m"), True)
        self.assertEqual(clock.call_count, 2)
        self.assertEqual(meter.snapshot()["duration_seconds"], 2.5)

    def test_finish_once_unknown_foreign_and_unhashable_tokens(self):
        meter = UsageMeter(clock=FakeClock())
        token = meter.start("p", "m")
        foreign = UsageMeter(clock=FakeClock()).start("p", "m")
        for unknown in [object(), foreign, None, [], {}]:
            self.assertFalse(meter.finish(unknown, True))
        self.assertTrue(meter.finish(token, False))
        self.assertFalse(meter.finish(token, True))
        self.assertEqual(meter.snapshot()["errors"], 1)
        self.assertEqual(meter.snapshot()["total_calls"], 1)

    def test_pending_is_not_completed(self):
        meter = UsageMeter(clock=FakeClock())
        token = meter.start("p", "m")
        self.assertEqual(meter.snapshot()["in_flight"], 1)
        self.assertEqual(meter.snapshot()["total_calls"], 0)
        self.assertNotIn("p", repr(token))
        self.assertEqual(type(token), object)

    def test_snapshot_does_not_expose_internal_state(self):
        meter = UsageMeter(clock=FakeClock())
        meter.finish(meter.start("p", "m"), True)
        data = meter.snapshot()
        data["records"][0]["model"] = "changed"
        data["records"].clear()
        data["total_calls"] = 999
        current = meter.snapshot()
        self.assertEqual(current["total_calls"], 1)
        self.assertEqual(current["records"][0]["model"], "m")
        self.assertIsInstance(json.dumps(current), str)

    def test_recent_records_bounded_without_losing_totals(self):
        clock = FakeClock()
        meter = UsageMeter(clock=clock)
        first_token = None
        for index in range(MAX_RECORDS + 27):
            token = meter.start("p", f"m-{index}")
            if index == 0:
                first_token = token
            clock.advance(0.5)
            meter.finish(token, index % 2 == 0)
        data = meter.snapshot()
        self.assertEqual(len(data["records"]), MAX_RECORDS)
        self.assertEqual(data["records"][0]["model"], "m-27")
        self.assertEqual(data["dropped_records"], 27)
        self.assertEqual(data["total_calls"], MAX_RECORDS + 27)
        self.assertEqual(data["successes"], 514)
        self.assertEqual(data["errors"], 513)
        self.assertEqual(data["duration_seconds"], (MAX_RECORDS + 27) / 2)
        self.assertFalse(meter.finish(first_token, True))

    def test_pending_limit_does_not_evict_and_frees_capacity(self):
        meter = UsageMeter(clock=FakeClock())
        tokens = [meter.start("p", "m") for _ in range(MAX_IN_FLIGHT)]
        with self.assertRaises(RuntimeError):
            meter.start("p", "m")
        self.assertEqual(meter.snapshot()["in_flight"], MAX_IN_FLIGHT)
        self.assertTrue(meter.finish(tokens[0], True))
        meter.start("p", "m")
        self.assertEqual(meter.snapshot()["in_flight"], MAX_IN_FLIGHT)

    def test_validation_has_no_effect_on_pending_or_counts(self):
        meter = UsageMeter(clock=FakeClock())
        for invalid in [None, 1, "", " ", "x" * 201, "m\nn", "m\x00n"]:
            with self.subTest(invalid=invalid):
                with self.assertRaises(ValueError):
                    meter.start(invalid, "m")
                with self.assertRaises(ValueError):
                    meter.start("p", invalid)
        token = meter.start("p", "m")
        for invalid in [None, 0, 1, "False"]:
            with self.assertRaises(ValueError):
                meter.finish(token, invalid)
        self.assertEqual(meter.snapshot()["in_flight"], 1)
        self.assertTrue(meter.finish(token, True))

    def test_invalid_clock_does_not_lose_pending_call(self):
        clock = FakeClock()
        meter = UsageMeter(clock=clock)
        token = meter.start("p", "m")
        clock.now = float("nan")
        with self.assertRaises(ValueError):
            meter.finish(token, True)
        self.assertEqual(meter.snapshot()["in_flight"], 1)
        clock.now = 12
        self.assertTrue(meter.finish(token, True))
        self.assertEqual(meter.snapshot()["duration_seconds"], 2)

    def test_threaded_finish_of_same_token_only_counts_once(self):
        meter = UsageMeter(clock=lambda: 10.0)
        token = meter.start("p", "m")
        barrier = threading.Barrier(16)

        def finish(_):
            barrier.wait(timeout=10)
            return meter.finish(token, True)

        with ThreadPoolExecutor(max_workers=16) as executor:
            results = list(executor.map(finish, range(16)))
        self.assertEqual(sum(results), 1)
        self.assertEqual(meter.snapshot()["total_calls"], 1)

    def test_concurrent_start_finish_and_snapshots(self):
        meter = UsageMeter(clock=lambda: 10.0)

        def work(index):
            for _ in range(100):
                token = meter.start("p", f"m-{index}")
                self.assertTrue(meter.finish(token, index % 2 == 0))
                data = meter.snapshot()
                self.assertEqual(data["total_calls"], data["successes"] + data["errors"])
                self.assertEqual(data["dropped_records"] + len(data["records"]), data["total_calls"])

        with ThreadPoolExecutor(max_workers=8) as executor:
            list(executor.map(work, range(8)))
        data = meter.snapshot()
        self.assertEqual((data["total_calls"], data["successes"], data["errors"], data["in_flight"]), (800, 400, 400, 0))

    def test_summary_is_spanish_and_describes_scope(self):
        meter = UsageMeter(clock=FakeClock())
        self.assertIn("Finalizadas: 0", meter.summary())
        meter.finish(meter.start("Proveedor", "modelo"), False)
        text = meter.summary()
        for expected in ["Finalizadas: 1", "Éxitos: 0", "Errores: 1", "Proveedor / modelo", "Solo memoria", "No se miden tokens ni costos", "manuales de chat"]:
            self.assertIn(expected, text)
        self.assertNotIn("$", text)


if __name__ == "__main__":
    unittest.main()
