"""Frontera Windows simulada: no prueba APIs Win32 ni instala programas."""
import unittest
from pathlib import Path
from unittest.mock import Mock, patch
from computer_control import WindowsDesktop


class DesktopBoundaryTests(unittest.TestCase):
    def desktop(self):
        desktop = WindowsDesktop.__new__(WindowsDesktop)
        desktop.gui = Mock()
        desktop.gui.size.return_value = (1920, 1080)
        desktop.user32 = Mock()
        desktop.foreground = 42
        desktop.user32.GetForegroundWindow.return_value = 42
        return desktop

    def test_click_restores_captured_window_then_moves_and_clicks(self):
        desktop = self.desktop()
        desktop.execute({'action': 'click', 'reason': 'Abrir menú', 'x': 100, 'y': 200})
        desktop.user32.SetForegroundWindow.assert_called_once_with(42)
        desktop.gui.moveTo.assert_called_once_with(100, 200, duration=0.2)
        desktop.gui.click.assert_called_once_with()

    def test_focus_failure_never_types_or_clicks(self):
        desktop = self.desktop()
        desktop.user32.GetForegroundWindow.return_value = 99
        with self.assertRaises(ValueError):
            desktop.execute({'action': 'click', 'reason': 'Prueba', 'x': 100, 'y': 200})
        desktop.gui.moveTo.assert_not_called()
        desktop.gui.click.assert_not_called()

    def test_failsafe_prevents_execution(self):
        desktop = self.desktop()
        desktop.gui.failSafeCheck.side_effect = RuntimeError('failsafe')
        with self.assertRaises(RuntimeError):
            desktop.execute({'action': 'press_key', 'reason': 'Prueba', 'key': 'enter'})
        desktop.gui.press.assert_not_called()

    def test_install_uses_fixed_winget_interactive_exact_no_shell(self):
        desktop = self.desktop()
        with patch.dict('os.environ', {'LOCALAPPDATA': 'PROFILE'}), patch.object(Path, 'is_file', return_value=True), patch('computer_control.subprocess.Popen') as popen:
            result = desktop.execute({'action': 'install_app', 'reason': 'Instalar VLC', 'package': 'VideoLAN.VLC'})
        command = popen.call_args.args[0]
        self.assertEqual(Path(command[0]), Path('PROFILE/Microsoft/WindowsApps/winget.exe'))
        self.assertEqual(command[1:], ['install', '--id', 'VideoLAN.VLC', '--exact', '--source', 'winget', '--interactive'])
        self.assertEqual(popen.call_args.kwargs, {'shell': False})
        self.assertIn('NO se ha comprobado', result)

    def test_missing_winget_does_not_start_process(self):
        desktop = self.desktop()
        with patch.object(Path, 'is_file', return_value=False), patch('computer_control.subprocess.Popen') as popen:
            with self.assertRaises(ValueError):
                desktop.execute({'action': 'install_app', 'reason': 'Instalar VLC', 'package': 'VideoLAN.VLC'})
        popen.assert_not_called()

    def test_invalid_action_rejected_at_execution_boundary(self):
        desktop = self.desktop()
        with patch('computer_control.subprocess.Popen') as popen:
            with self.assertRaises(ValueError):
                desktop.execute({'action': 'install_app', 'reason': 'Prueba', 'package': 'bad;cmd.exe'})
        popen.assert_not_called()
        desktop.gui.failSafeCheck.assert_not_called()


if __name__ == '__main__':
    unittest.main()
