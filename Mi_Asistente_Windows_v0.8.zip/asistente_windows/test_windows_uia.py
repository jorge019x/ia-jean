"""Pruebas UIA con dobles puros: nunca importan ni controlan Windows real."""
import sys
import threading
import unittest
from types import SimpleNamespace
from unittest.mock import Mock, patch

from windows_uia import UIAError, WindowsUIA


class FakeWrapper:
    def __init__(self, runtime, handle=0, name="Control", control_type="Button",
                 invoke=False, value=False, password=False):
        self.element_info = SimpleNamespace(
            runtime_id=[runtime], process_id=99, handle=handle,
            name=name, control_type=control_type, class_name="Fake",
            automation_id=str(runtime), is_password=password,
            rectangle=SimpleNamespace(left=0, top=0, right=10, bottom=10))
        self.nodes = []
        self.visible = self.enabled = True
        self.invocations = 0
        self.values = []
        self.focus_calls = 0
        self.iface_invoke = SimpleNamespace(Invoke=self.invoke) if invoke else None
        self.iface_value = (SimpleNamespace(CurrentIsReadOnly=False, SetValue=self.values.append)
                            if value else None)
        self.on_focus = None

    def invoke(self):
        self.invocations += 1

    def children(self):
        return self.nodes

    def is_visible(self):
        return self.visible

    def is_enabled(self):
        return self.enabled

    def wrapper_object(self):
        return self

    def set_focus(self):
        self.focus_calls += 1
        if self.on_focus:
            self.on_focus()


class FakeDesktop:
    def __init__(self, windows):
        self.roots = windows
        self.reads = 0

    def windows(self):
        return self.roots

    def window(self, handle):
        self.reads += 1
        return next(w for w in self.roots if w.element_info.handle == handle)


class UIATests(unittest.TestCase):
    def setUp(self):
        self.window = FakeWrapper(1, handle=101, name="Editor", control_type="Window")
        self.button = FakeWrapper(2, name="Guardar", invoke=True)
        self.edit = FakeWrapper(3, name="Texto", control_type="Edit", value=True)
        self.window.nodes = [self.button, self.edit]
        self.desktop = FakeDesktop([self.window])
        self.foreground = 101
        self.uia = WindowsUIA(_desktop=self.desktop, _foreground=lambda: self.foreground)

    def snapshot(self):
        return self.uia.observation()

    def test_optional_on_linux(self):
        with patch.object(sys, "platform", "linux"):
            with self.assertRaises(UIAError):
                WindowsUIA()

    def test_missing_pywinauto_becomes_uiaerror(self):
        with patch.object(sys, "platform", "win32"), patch.dict(sys.modules, {"pywinauto": None}):
            with self.assertRaisesRegex(UIAError, "dependencia opcional"):
                WindowsUIA()

    def test_real_backend_initializes_current_worker_com_and_balances_close(self):
        import ctypes
        com = SimpleNamespace(CoInitializeEx=Mock(), CoUninitialize=Mock())
        desktop_factory = Mock(return_value=self.desktop)
        user32 = SimpleNamespace(GetForegroundWindow=Mock(return_value=101))
        with patch.object(sys, "platform", "win32"), patch.dict(
                sys.modules, {"pywinauto": SimpleNamespace(Desktop=desktop_factory),
                              "comtypes": com}), patch.object(
                ctypes, "windll", SimpleNamespace(user32=user32), create=True):
            backend = WindowsUIA()
            com.CoInitializeEx.assert_called_once_with()
            self.assertEqual(backend.observation()["active_window"]["title"], "Editor")
            backend.close()
            backend.close()
            com.CoUninitialize.assert_called_once_with()
            with self.assertRaises(UIAError):
                backend.observation()

    def test_com_reference_released_on_desktop_initialization_failure(self):
        import ctypes
        com = SimpleNamespace(CoInitializeEx=Mock(), CoUninitialize=Mock())
        user32 = SimpleNamespace(GetForegroundWindow=Mock(return_value=101))
        with patch.object(sys, "platform", "win32"), patch.dict(
                sys.modules, {"pywinauto": SimpleNamespace(Desktop=Mock(side_effect=RuntimeError)),
                              "comtypes": com}), patch.object(
                ctypes, "windll", SimpleNamespace(user32=user32), create=True):
            with self.assertRaisesRegex(UIAError, "inicializar"):
                WindowsUIA()
            com.CoUninitialize.assert_called_once_with()

    def test_backend_cannot_cross_threads(self):
        errors = []
        def worker():
            for operation in (self.uia.observation, self.uia.close):
                try:
                    operation()
                except UIAError:
                    errors.append(True)
        thread = threading.Thread(target=worker)
        thread.start()
        thread.join()
        self.assertEqual(errors, [True, True])
        self.assertTrue(self.uia.observation()["windows"])

    def test_snapshot_read_only_and_opaque(self):
        result = self.snapshot()
        self.assertEqual(result["active_window"]["title"], "Editor")
        self.assertEqual(len(result["elements"]), 2)
        self.assertTrue(result["elements"][0]["can_invoke"])
        self.assertTrue(result["elements"][1]["can_set_value"])
        self.assertNotEqual(result["windows"][0]["id"], "101")
        self.assertNotIn("handle", result["windows"][0])
        self.assertEqual(self.button.invocations, 0)
        self.assertEqual(self.edit.values, [])
        self.assertEqual(self.window.focus_calls, 0)

    def test_refresh_wrapper_not_cached_and_single_use(self):
        result = self.snapshot()
        replacement = FakeWrapper(2, name="Guardar", invoke=True)
        self.window.nodes[0] = replacement
        self.uia.invoke(result["elements"][0]["id"])
        self.assertEqual(replacement.invocations, 1)
        self.assertEqual(self.button.invocations, 0)
        with self.assertRaises(UIAError):
            self.uia.invoke(result["elements"][0]["id"])
        self.assertGreaterEqual(self.desktop.reads, 2)

    def test_set_value_unicode_literal_no_keystrokes(self):
        result = self.snapshot()
        self.uia.set_value(result["elements"][1]["id"], "áé 😀 {ENTER} ^a")
        self.assertEqual(self.edit.values, ["áé 😀 {ENTER} ^a"])
        with self.assertRaises(UIAError):
            self.uia.invoke(result["elements"][0]["id"])

    def test_changed_foreground_rejected_and_consumed(self):
        result = self.snapshot()
        self.foreground = 202
        with self.assertRaises(UIAError):
            self.uia.invoke(result["elements"][0]["id"])
        self.foreground = 101
        with self.assertRaises(UIAError):
            self.uia.invoke(result["elements"][0]["id"])
        self.assertEqual(self.button.invocations, 0)

    def test_stale_window_or_element_rejected(self):
        for mutate in (
                lambda: setattr(self.button.element_info, "name", "Eliminar"),
                lambda: setattr(self.button.element_info, "runtime_id", [55]),
                lambda: setattr(self.window.element_info, "process_id", 42),
                lambda: setattr(self.button, "enabled", False),
                lambda: setattr(self.button.element_info.rectangle, "left", 8)):
            with self.subTest(mutate=mutate):
                self.setUp()
                result = self.snapshot()
                mutate()
                with self.assertRaises(UIAError):
                    self.uia.invoke(result["elements"][0]["id"])
                self.assertEqual(self.button.invocations, 0)

    def test_removed_and_duplicate_identity_rejected(self):
        for duplicate in (False, True):
            self.setUp()
            result = self.snapshot()
            self.window.nodes = ([self.button, self.button] if duplicate else [])
            with self.assertRaises(UIAError):
                self.uia.invoke(result["elements"][0]["id"])
            self.assertEqual(self.button.invocations, 0)

    def test_password_and_readonly_never_exposed_as_writable(self):
        self.edit.iface_value.CurrentIsReadOnly = True
        self.button.element_info.is_password = True
        result = self.snapshot()
        self.assertEqual(len(result["elements"]), 1)
        self.assertFalse(result["elements"][0]["can_set_value"])
        with self.assertRaises(UIAError):
            self.uia.set_value(result["elements"][0]["id"], "hola")
        self.assertEqual(self.edit.values, [])

    def test_password_changed_since_observation(self):
        result = self.snapshot()
        self.edit.element_info.is_password = True
        with self.assertRaises(UIAError):
            self.uia.set_value(result["elements"][1]["id"], "hola")
        self.assertEqual(self.edit.values, [])

    def test_new_observation_and_unknown_ids_invalidate(self):
        old = self.snapshot()
        self.snapshot()
        with self.assertRaises(UIAError):
            self.uia.invoke(old["elements"][0]["id"])
        with self.assertRaises(UIAError):
            self.uia.focus_window(old["windows"][0]["id"])
        with self.assertRaises(UIAError):
            self.uia.invoke("101")

    def test_limits_and_bounded_tree(self):
        self.window.nodes = [FakeWrapper(i + 10) for i in range(1000)]
        window_id = self.uia.list_windows(limit=1)[0]["id"]
        self.assertEqual(len(self.uia.list_elements(window_id, limit=200)), 200)
        self.assertLessEqual(len(list(self.uia._walk(self.window))), 499)
        for limit in (True, 0, -1, 201, 2.5):
            with self.assertRaises(UIAError):
                self.uia.list_elements(window_id, limit)
        with self.assertRaises(UIAError):
            self.uia.list_windows(101)

    def test_focus_checks_original_foreground_and_verifies_result(self):
        self.foreground = 202
        token = self.uia.list_windows()[0]["id"]
        self.window.on_focus = lambda: setattr(self, "foreground", 101)
        self.uia.focus_window(token)
        self.assertEqual(self.foreground, 101)
        self.assertEqual(self.window.focus_calls, 1)
        with self.assertRaises(UIAError):
            self.uia.focus_window(token)
        token = self.uia.list_windows()[0]["id"]
        self.foreground = 303
        with self.assertRaises(UIAError):
            self.uia.focus_window(token)
        self.assertEqual(self.window.focus_calls, 1)

    def test_focus_failure_is_not_success(self):
        self.foreground = 202
        token = self.uia.list_windows()[0]["id"]
        with self.assertRaises(UIAError):
            self.uia.focus_window(token)

    def test_list_elements_requires_active_window(self):
        token = self.uia.list_windows()[0]["id"]
        self.foreground = 202
        with self.assertRaises(UIAError):
            self.uia.list_elements(token)

    def test_missing_pattern_and_invalid_text_fail_closed(self):
        for text in ("", "a\nb", "a\tb", "a" * 501, None, "\x7f"):
            result = self.snapshot()
            with self.assertRaises(UIAError):
                self.uia.set_value(result["elements"][1]["id"], text)
        self.assertEqual(self.edit.values, [])
        result = self.snapshot()
        with self.assertRaises(UIAError):
            self.uia.invoke(result["elements"][1]["id"])

    def test_failing_provider_never_retried(self):
        result = self.snapshot()
        calls = []
        def fail():
            calls.append(1)
            raise RuntimeError("provider error")
        self.button.iface_invoke.Invoke = fail
        with self.assertRaises(UIAError):
            self.uia.invoke(result["elements"][0]["id"])
        with self.assertRaises(UIAError):
            self.uia.invoke(result["elements"][0]["id"])
        self.assertEqual(calls, [1])


if __name__ == "__main__":
    unittest.main()
