"""Métricas locales y efímeras de llamadas manuales de chat (v0.8).

Implementación propia; inspiración conceptual del panel de
zurdoar/optimizer-model-for-claude (MIT, Copyright 2026 Emanuel (Zurdo)).
Solo se leyó su README y LICENSE: no se copió ni ejecutó su código. No hay
ruteo, estimación de tokens/costos ni equivalencia con su panel. La referencia
es una copia local histórica (commit cf07ed1773de51a886903efa69893df6604ac332),
no una comprobación del proyecto actual.

El llamador delimita cada llamada; este módulo no observa red ni contenido.
No pasar prompts, claves o respuestas como etiquetas. No escribe archivos.
"""
from collections import deque
import math
import threading
import time


MAX_RECORDS = 1000
MAX_IN_FLIGHT = 1000
MAX_LABEL_LENGTH = 200


class UsageMeter:
    """Contador de una sesión, seguro entre hilos y sin persistencia.

    ``start`` no cuenta una llamada terminada. ``finish`` cuenta una sola vez
    y devuelve False si el token es desconocido, de otro contador o terminado.
    ``snapshot`` devuelve copias: totales de TODA la sesión y hasta 1000
    registros terminados recientes. Las llamadas aún abiertas no contribuyen
    a esos totales; su cantidad aparece en ``in_flight``. No se guardan tokens
    terminados para deduplicar: al finalizar se retiran de las llamadas abiertas.

    Hay como máximo 1000 llamadas abiertas; superar ese límite lanza
    RuntimeError sin descartar llamadas existentes. Las etiquetas tienen un
    máximo de 200 caracteres, para mantener acotada también su memoria.
    ``clock`` permite pruebas deterministas; en producción usa time.monotonic.
    La duración es tiempo transcurrido local, no tiempo facturado por la API.
    """

    def __init__(self, *, clock=None):
        self._clock = time.monotonic if clock is None else clock
        self._lock = threading.Lock()
        self._pending = {}
        self._records = deque(maxlen=MAX_RECORDS)
        self._total_calls = 0
        self._successes = 0
        self._errors = 0
        self._duration_seconds = 0.0

    @staticmethod
    def _label(value):
        if not isinstance(value, str):
            raise ValueError("Proveedor y modelo deben ser identificadores de texto.")
        value = value.strip()
        if not value or len(value) > MAX_LABEL_LENGTH or any(ord(c) < 32 or ord(c) == 127 for c in value):
            raise ValueError("Proveedor y modelo deben tener entre 1 y 200 caracteres sin controles.")
        return value

    def _now(self):
        value = float(self._clock())
        if not math.isfinite(value):
            raise ValueError("El reloj debe devolver un tiempo finito.")
        return value

    def start(self, provider, model):
        """Inicia una medición y devuelve un token opaco, sin datos sensibles."""
        provider, model = self._label(provider), self._label(model)
        with self._lock:
            if len(self._pending) >= MAX_IN_FLIGHT:
                raise RuntimeError("Hay 1000 llamadas pendientes; termina una antes de iniciar otra.")
            token = object()
            self._pending[token] = (provider, model, self._now())
            return token

    def finish(self, token, success):
        """Registra como máximo una vez; ``success`` debe ser bool explícito."""
        if type(success) is not bool:
            raise ValueError("El resultado debe ser True o False.")
        # Solo aceptamos los objetos opacos emitidos por start, no objetos que
        # puedan ejecutar __hash__/__eq__ arbitrarios dentro del bloqueo.
        if type(token) is not object:
            return False
        with self._lock:
            pending = self._pending.get(token)
            if pending is None:
                return False
            provider, model, started = pending
            duration = max(0.0, self._now() - started)
            del self._pending[token]
            self._records.append({
                "provider": provider,
                "model": model,
                "success": success,
                "duration_seconds": duration,
            })
            self._total_calls += 1
            self._successes += int(success)
            self._errors += int(not success)
            self._duration_seconds += duration
            return True

    def snapshot(self):
        """Copia consistente; records es una ventana, los totales no lo son."""
        with self._lock:
            return {
                "total_calls": self._total_calls,
                "successes": self._successes,
                "errors": self._errors,
                "duration_seconds": self._duration_seconds,
                "in_flight": len(self._pending),
                "records": [dict(record) for record in self._records],
                "dropped_records": self._total_calls - len(self._records),
            }

    def summary(self):
        """Resumen español; no incluye ninguna estimación de consumo o precio."""
        data = self.snapshot()
        lines = [
            "Uso de esta sesión — llamadas manuales de chat",
            f"Finalizadas: {data['total_calls']} | Éxitos: {data['successes']} | Errores: {data['errors']}",
            f"En curso: {data['in_flight']} | Duración acumulada local: {data['duration_seconds']:.2f} s",
        ]
        if data["records"]:
            latest = data["records"][-1]
            lines.append(f"Última finalizada: {latest['provider']} / {latest['model']}")
        lines.extend([
            f"Detalle reciente: {len(data['records'])} registros (máximo 1000); descartados: {data['dropped_records']}. Los totales abarcan toda la sesión.",
            "Solo memoria de esta sesión; sin prompts, claves ni respuestas. No se miden tokens ni costos.",
        ])
        return "\n".join(lines)
