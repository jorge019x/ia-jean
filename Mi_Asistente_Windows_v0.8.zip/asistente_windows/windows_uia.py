"""Backend UI Automation opcional, sin dependencias al importar en Linux.

API: WindowsUIA().list_windows(limit=20) -> [{id, title, active}];
list_elements(window_id, limit=80) -> [{id, name, control_type, can_invoke,
can_set_value}]. focus_window(window_id), invoke(element_id) y
set_value(element_id, text) ejecutan UNA acción y devuelven None.

El llamador DEBE pedir aprobación humana individual ANTES de cada acción.
Este módulo no es un sistema de autorización ni interpreta textos UI como órdenes.
Los IDs son opacos, locales a la instancia y efímeros: list_windows invalida
TODO; list_elements invalida los elementos anteriores; cualquier intento de
acción consume todos los IDs de elementos. No se aceptan handles/selectores del
modelo. Cada acción busca wrappers nuevos, comprueba identidad y foco de nuevo,
y falla cerrada si algo cambió. focus_window exige que el foco siga como al
listar ventanas (puede entonces activar la ventana seleccionada). Para actuar
sobre un elemento su ventana ya debe estar activa: no se restaura foco en secreto.

Solo patrones UIA Invoke y Value; nunca teclas, coordenadas, portapapeles ni
fallback click. Se rechazan contraseñas y valores multilínea/control. El árbol
se explora hasta 500 nodos y 8 niveles, exportando como máximo 100 ventanas o
200 elementos. UIA no ofrece una transacción atómica: una aplicación puede
cambiar entre la última validación y la llamada; esto no es aislamiento de
aplicaciones maliciosas. Una llamada a un proveedor UIA bloqueado puede tardar.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass
import secrets
import sys
import threading


class UIAError(ValueError):
    """Backend ausente, objetivo obsoleto o acción no permitida."""


@dataclass(frozen=True)
class _Window:
    handle: int
    identity: tuple
    foreground: int


@dataclass(frozen=True)
class _Element:
    window: _Window
    identity: tuple


def _limit(value, maximum):
    if type(value) is not int or not 1 <= value <= maximum:
        raise UIAError(f"Límite entero entre 1 y {maximum}")
    return value


class WindowsUIA:
    """Acceso supervisado UIA. _desktop/_foreground son seams solo para tests.

    Producción: instalar pywinauto opcionalmente en Windows y construir sin
    argumentos, dentro del hilo worker que lo usará. Inicializa COM en ese
    hilo incluso si pywinauto ya se importó en otro; llamar close() en el mismo
    hilo al terminar. No compartir instancias entre hilos. La construcción no
    cambia foco ni ejecuta acciones.
    """

    def __init__(self, *, _desktop=None, _foreground=None):
        self._thread = threading.get_ident()
        self._closed = False
        self._uninitialize = None
        if _desktop is None:
            if sys.platform != "win32":
                raise UIAError("UI Automation solo está disponible en Windows")
            try:
                from pywinauto import Desktop
                import comtypes
            except ImportError:
                raise UIAError("Instala la dependencia opcional pywinauto para UI Automation") from None
            try:
                # Importar comtypes solo inicializa el hilo del primer import.
                # Esta referencia COM explícita se equilibra siempre con close.
                comtypes.CoInitializeEx()
                self._uninitialize = comtypes.CoUninitialize
                import ctypes
                from ctypes import wintypes
                user32 = ctypes.windll.user32
                user32.GetForegroundWindow.restype = wintypes.HWND
                _desktop = Desktop(backend="uia")
                _foreground = user32.GetForegroundWindow
            except Exception:
                if self._uninitialize is not None:
                    self._uninitialize()
                    self._uninitialize = None
                raise UIAError("No se pudo inicializar UI Automation en este hilo") from None
        if _foreground is None:
            raise UIAError("Falta proveedor de ventana activa")
        self._desktop = _desktop
        self._foreground = _foreground
        self._windows = {}
        self._elements = {}

    def _check_thread(self):
        if threading.get_ident() != self._thread:
            raise UIAError("UI Automation debe usarse en su hilo constructor")
        if self._closed:
            raise UIAError("El backend UI Automation está cerrado")

    def close(self):
        """Libera la referencia COM en el hilo constructor; cierre idempotente."""
        if threading.get_ident() != self._thread:
            raise UIAError("UI Automation debe cerrarse en su hilo constructor")
        if self._closed:
            return
        self._closed = True
        self._windows.clear()
        self._elements.clear()
        if self._uninitialize is not None:
            self._uninitialize()
            self._uninitialize = None

    @staticmethod
    def _identity(wrapper):
        info = wrapper.element_info
        runtime = tuple(info.runtime_id or ())
        if not runtime:
            raise UIAError("Elemento sin identidad UIA estable")
        # No se leen valores editables; nombre y geometría permiten detectar
        # cambios entre la observación aprobada y la ejecución.
        r = info.rectangle
        return (runtime, info.process_id, info.handle, info.control_type,
                info.class_name, info.automation_id, info.name,
                (r.left, r.top, r.right, r.bottom))

    @staticmethod
    def _ready(wrapper):
        return wrapper.is_visible() and wrapper.is_enabled()

    @staticmethod
    def _capabilities(wrapper):
        invoke = value = False
        if not wrapper.element_info.is_password:
            try:
                invoke = wrapper.iface_invoke is not None
            except Exception:
                pass
            try:
                value = not bool(wrapper.iface_value.CurrentIsReadOnly)
            except Exception:
                pass
        return invoke, value

    def _active(self, window):
        if int(self._foreground() or 0) != window.handle:
            raise UIAError("La ventana destino no está activa; vuelve a observar")

    def _refresh_window(self, window):
        wrapper = self._desktop.window(handle=window.handle).wrapper_object()
        if self._identity(wrapper) != window.identity or not self._ready(wrapper):
            raise UIAError("La ventana cambió o ya no está disponible")
        return wrapper

    @staticmethod
    def _walk(root):
        # children(), a diferencia de descendants(), no recorre todo el árbol.
        queue = deque([(root, 0)])
        visited = 0
        while queue and visited < 500:
            wrapper, depth = queue.popleft()
            visited += 1
            if depth:
                yield wrapper
            if depth < 8:
                remaining = 500 - visited - len(queue)
                if remaining > 0:
                    for child in wrapper.children()[:remaining]:
                        queue.append((child, depth + 1))

    def list_windows(self, limit=20):
        """Lectura limitada; renueva todos los IDs. No activa ninguna ventana."""
        self._check_thread()
        self._windows.clear()
        self._elements.clear()
        limit = _limit(limit, 100)
        try:
            foreground = int(self._foreground() or 0)
            result = []
            for wrapper in self._desktop.windows()[:100]:
                try:
                    if not self._ready(wrapper):
                        continue
                    identity = self._identity(wrapper)
                    handle = int(wrapper.element_info.handle)
                    if not handle:
                        continue
                    token = secrets.token_urlsafe(24)
                    self._windows[token] = _Window(handle, identity, foreground)
                    result.append({"id": token, "title": str(wrapper.element_info.name)[:300],
                                   "active": handle == foreground})
                    if len(result) >= limit:
                        break
                except Exception:
                    continue
            return result
        except Exception:
            self._windows.clear()
            raise UIAError("No se pudieron listar ventanas UIA") from None

    def list_elements(self, window_id, limit=80):
        """Lista solo elementos visibles/habilitados de una ventana activa."""
        self._check_thread()
        self._elements.clear()
        limit = _limit(limit, 200)
        try:
            window = self._windows[window_id]
            self._active(window)
            root = self._refresh_window(window)
            result = []
            for wrapper in self._walk(root):
                try:
                    if not self._ready(wrapper) or wrapper.element_info.is_password:
                        continue
                    identity = self._identity(wrapper)
                    can_invoke, can_set_value = self._capabilities(wrapper)
                    token = secrets.token_urlsafe(24)
                    self._elements[token] = _Element(window, identity)
                    result.append({"id": token, "name": str(wrapper.element_info.name)[:300],
                                   "control_type": str(wrapper.element_info.control_type)[:80],
                                   "can_invoke": can_invoke, "can_set_value": can_set_value})
                    if len(result) >= limit:
                        break
                except Exception:
                    continue
            self._active(window)
            return result
        except Exception:
            self._elements.clear()
            raise UIAError("Ventana no válida, inactiva o inaccesible; vuelve a listar") from None

    def observation(self):
        """Snapshot serializable para el planificador, sin acciones ni valores.

        Conserva los IDs hasta otra lectura/acción. El coordinador puede
        restaurar explícitamente la ventana capturada tras cerrar su diálogo
        de aprobación; invoke/set_value nunca la enfocan por su cuenta.
        """
        windows = self.list_windows()
        active = next((window for window in windows if window["active"]), None)
        elements = self.list_elements(active["id"]) if active else []
        return {"windows": windows, "active_window": active, "elements": elements}

    def focus_window(self, window_id):
        """Una activación explícita. Comprobar aprobación antes de llamar."""
        self._check_thread()
        self._elements.clear()
        try:
            window = self._windows[window_id]
            if int(self._foreground() or 0) != window.foreground:
                raise UIAError("El foco cambió desde la observación")
            wrapper = self._refresh_window(window)
            if int(self._foreground() or 0) != window.foreground:
                raise UIAError("El foco cambió durante la validación")
            wrapper.set_focus()
            self._active(window)
        except Exception:
            raise UIAError("No se pudo enfocar con seguridad; vuelve a listar ventanas") from None
        finally:
            # No permite repetir una activación con una aprobación anterior.
            self._windows.clear()

    def _execute(self, element_id, operation, text=None):
        self._check_thread()
        try:
            element = self._elements[element_id]
            self._elements.clear()
            self._active(element.window)
            root = self._refresh_window(element.window)
            matches = []
            for wrapper in self._walk(root):
                if self._identity(wrapper) == element.identity:
                    matches.append(wrapper)
            if len(matches) != 1:
                raise UIAError("Elemento obsoleto o ambiguo")
            target = matches[0]
            if not self._ready(target) or target.element_info.is_password:
                raise UIAError("Elemento no disponible o protegido")
            can_invoke, can_set_value = self._capabilities(target)
            if operation == "invoke" and can_invoke:
                action = target.iface_invoke.Invoke
            elif operation == "set_value" and can_set_value:
                action = lambda: target.iface_value.SetValue(text)
            else:
                raise UIAError("El elemento no admite ese patrón UIA")
            if self._identity(target) != element.identity:
                raise UIAError("El elemento cambió durante la validación")
            self._active(element.window)
            action()
        except Exception:
            # No repetir automáticamente: el proveedor podría haber ejecutado
            # la acción antes de devolver un error.
            raise UIAError("Acción UIA cancelada o fallida; no se reintentó. Vuelve a observar") from None
        finally:
            self._elements.clear()

    def invoke(self, element_id):
        """Ejecuta solo InvokePattern; consume el snapshot, incluso al fallar."""
        self._execute(element_id, "invoke")

    def set_value(self, element_id, text):
        """Reemplaza el valor (no teclas), de una línea y hasta 500 caracteres."""
        if (not isinstance(text, str) or not 1 <= len(text) <= 500
                or any(ord(c) < 32 or ord(c) == 127 for c in text)):
            self._elements.clear()
            raise UIAError("Solo texto de una línea, entre 1 y 500 caracteres")
        self._execute(element_id, "set_value", text)
